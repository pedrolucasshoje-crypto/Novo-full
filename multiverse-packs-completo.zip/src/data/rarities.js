// Pesos base: Comum 55%, Incomum 25%, Raro 12%, Epico 6%, Lendario 1.7%, Mitico 0.3%
// As chances sao normalizadas dentro do pool de raridades existente em cada pacote.
export const RARIDADES = [
  { id: 'comum', nome: 'Comum', cor: '#9aa4b8', peso: 55, duplicado: 10, poder: 1.00 },
  { id: 'incomum', nome: 'Incomum', cor: '#4ade80', peso: 25, duplicado: 20, poder: 1.08 },
  { id: 'raro', nome: 'Raro', cor: '#38bdf8', peso: 12, duplicado: 40, poder: 1.17 },
  { id: 'epico', nome: 'Epico', cor: '#c084fc', peso: 6, duplicado: 90, poder: 1.28 },
  { id: 'lendario', nome: 'Lendario', cor: '#fbbf24', peso: 1.7, duplicado: 200, poder: 1.42 },
  { id: 'mitico', nome: 'Mitico', cor: '#fb7185', peso: 0.3, duplicado: 450, poder: 1.60 },
  { id: 'celestial', nome: 'Celestial', cor: '#e0f2fe', peso: 0, duplicado: 1000, poder: 1.85 },
];
export const raridade = (id) => RARIDADES.find((r) => r.id === id);
export const ordemRaridade = (id) => RARIDADES.findIndex((r) => r.id === id);
