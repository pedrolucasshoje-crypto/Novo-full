import { RARIDADES, ordemRaridade } from './rarities.js';

export const UNIVERSOS = {
  apocalipse: { nome: 'Avengers: Doomsday', cor: '#ef4444' },
  aurora: { nome: 'DC', cor: '#3b82f6' },
  astral: { nome: 'Dragon Ball', cor: '#f97316' },
  vigilantes: { nome: 'Marvel', cor: '#e11d48' },
  titas: { nome: 'Attack on Titan', cor: '#64748b' },
  konoha: { nome: 'Naruto', cor: '#f97316' },
  grandline: { nome: 'One Piece', cor: '#0ea5e9' },
  feiticeiros: { nome: 'Jujutsu Kaisen', cor: '#7c3aed' },
  cacadores: { nome: 'Demon Slayer', cor: '#16a34a' },
  pokemon: { nome: 'Pokémon', cor: '#eab308' },
  cybertron: { nome: 'Transformers', cor: '#64748b' },
  sonic: { nome: 'Sonic', cor: '#2563eb' },
  starwars: { nome: 'Star Wars', cor: '#a3a3a3' },
};

// Habilidades usadas pelos personagens na arena.
export const HABILIDADES = {
  disparo: { nome: 'Rajada', icone: '✴️', tipo: 'projetil', custo: 20, recarga: 2.5 },
  leque: { nome: 'Leque de Tiros', icone: '🔱', tipo: 'leque', custo: 30, recarga: 4 },
  onda: { nome: 'Onda de Choque', icone: '💥', tipo: 'area', custo: 35, recarga: 6 },
  investida: { nome: 'Investida', icone: '⚡', tipo: 'investida', custo: 25, recarga: 4 },
  escudo: { nome: 'Escudo', icone: '🛡️', tipo: 'defesa', custo: 30, recarga: 9 },
  salto: { nome: 'Teletransporte', icone: '🌀', tipo: 'teletransporte', custo: 25, recarga: 5 },
  meteoro: { nome: 'Fúria Cósmica', icone: '☄️', tipo: 'especial', custo: 60, recarga: 14 },
  cura: { nome: 'Regeneração', icone: '💚', tipo: 'cura', custo: 45, recarga: 12 },
};

// [id, nome oficial, universo, raridade inicial, lado, emoji, habilidades, descrição]
// O catálogo contém apenas personagens oficiais; as skins são geradas abaixo para todos.
const LISTA = [
  // Avengers: Doomsday — elenco anunciado oficialmente (personagens)
  ['doctor-doom', 'Doctor Doom', 'apocalipse', 'celestial', 'vilao', '🟢', ['meteoro', 'onda'], 'Victor von Doom.'],
  ['steve-rogers', 'Steve Rogers', 'apocalipse', 'lendario', 'heroi', '🛡️', ['escudo', 'investida'], 'Capitão América.'],
  ['thor-doomsday', 'Thor', 'apocalipse', 'lendario', 'heroi', '🔨', ['onda', 'investida'], 'Deus do trovão.'],
  ['sam-wilson', 'Sam Wilson', 'apocalipse', 'epico', 'heroi', '🪽', ['disparo', 'investida'], 'Capitão América.'],
  ['scott-lang', 'Scott Lang', 'apocalipse', 'raro', 'heroi', '🐜', ['salto', 'investida'], 'Ant-Man.'],
  ['reed-richards', 'Reed Richards', 'apocalipse', 'lendario', 'heroi', '🧠', ['escudo', 'disparo'], 'Mister Fantastic.'],
  ['sue-storm', 'Sue Storm', 'apocalipse', 'lendario', 'heroi', '🫥', ['escudo', 'onda'], 'Invisible Woman.'],
  ['johnny-storm', 'Johnny Storm', 'apocalipse', 'epico', 'heroi', '🔥', ['disparo', 'investida'], 'Human Torch.'],
  ['ben-grimm', 'Ben Grimm', 'apocalipse', 'epico', 'heroi', '🪨', ['investida', 'onda'], 'The Thing.'],
  ['xavier', 'Professor X', 'apocalipse', 'mitico', 'heroi', '🧠', ['onda', 'escudo'], 'Charles Xavier.'],
  ['magneto', 'Magneto', 'apocalipse', 'mitico', 'heroi', '🧲', ['onda', 'meteoro'], 'Erik Lehnsherr.'],
  ['cyclops', 'Cyclops', 'apocalipse', 'lendario', 'heroi', '🔴', ['disparo', 'leque'], 'Scott Summers.'],
  ['beast', 'Beast', 'apocalipse', 'epico', 'heroi', '🐾', ['investida', 'cura'], 'Hank McCoy.'],
  ['nightcrawler', 'Nightcrawler', 'apocalipse', 'epico', 'heroi', '🌀', ['salto', 'investida'], 'Kurt Wagner.'],
  ['mystique', 'Mystique', 'apocalipse', 'epico', 'heroi', '🔵', ['salto', 'investida'], 'Raven Darkholme.'],
  ['gambit', 'Gambit', 'apocalipse', 'epico', 'heroi', '🃏', ['leque', 'disparo'], 'Remy LeBeau.'],
  ['yelena', 'Yelena Belova', 'apocalipse', 'epico', 'heroi', '🕷️', ['investida', 'leque'], 'Integrante dos Thunderbolts.'],
  ['bucky', 'Bucky Barnes', 'apocalipse', 'lendario', 'heroi', '🦾', ['investida', 'disparo'], 'Winter Soldier.'],
  ['us-agent', 'U.S. Agent', 'apocalipse', 'epico', 'heroi', '🛡️', ['escudo', 'investida'], 'John Walker.'],
  ['red-guardian', 'Red Guardian', 'apocalipse', 'epico', 'heroi', '🟥', ['investida', 'onda'], 'Alexei Shostakov.'],
  ['ghost', 'Ghost', 'apocalipse', 'lendario', 'heroi', '👻', ['salto', 'disparo'], 'Ava Starr.'],
  ['sentry', 'Sentry', 'apocalipse', 'mitico', 'heroi', '☀️', ['meteoro', 'onda'], 'Bob Reynolds.'],
  ['shuri', 'Shuri', 'apocalipse', 'lendario', 'heroi', '🐾', ['disparo', 'escudo'], 'Pantera Negra.'],
  ['mbaku', 'M’Baku', 'apocalipse', 'epico', 'heroi', '🦍', ['investida', 'escudo'], 'Líder dos Jabari.'],
  ['namor', 'Namor', 'apocalipse', 'lendario', 'heroi', '🌊', ['onda', 'investida'], 'Rei de Talokan.'],
  ['namora', 'Namora', 'apocalipse', 'epico', 'heroi', '🌊', ['investida', 'leque'], 'Guerreira de Talokan.'],
  ['loki-doomsday', 'Loki', 'apocalipse', 'mitico', 'heroi', '🐍', ['salto', 'onda'], 'Deus da trapaça.'],
  ['shang-chi', 'Shang-Chi', 'apocalipse', 'lendario', 'heroi', '🐉', ['leque', 'investida'], 'Mestre dos Dez Anéis.'],
  ['peggy-carter', 'Peggy Carter', 'apocalipse', 'lendario', 'heroi', '🛡️', ['escudo', 'investida'], 'Capitã Carter.'],
  ['joaquin-torres', 'Joaquin Torres', 'apocalipse', 'raro', 'heroi', '🪽', ['investida', 'disparo'], 'Falcon.'],
  ['cassie-lang', 'Cassie Lang', 'apocalipse', 'comum', 'heroi', '🐜', ['salto', 'investida'], 'Cassie Lang.'],
  ['india-love', 'Love', 'apocalipse', 'incomum', 'heroi', '💫', ['disparo', 'escudo'], 'Love.'],
  ['bruce-banner', 'Bruce Banner', 'apocalipse', 'lendario', 'heroi', '💚', ['cura', 'onda'], 'Cientista e Hulk.'],
  ['kate-bishop', 'Kate Bishop', 'apocalipse', 'epico', 'heroi', '🏹', ['disparo', 'investida'], 'Arqueira e integrante dos Jovens Vingadores.'],
  ['wanda-maximoff', 'Wanda Maximoff', 'apocalipse', 'mitico', 'heroi', '🔴', ['onda', 'meteoro'], 'A Feiticeira Escarlate.'],

  // DC
  ['superman', 'Superman', 'aurora', 'lendario', 'heroi', '🦸', ['disparo', 'investida'], 'O Homem de Aço.'],
  ['batman', 'Batman', 'aurora', 'epico', 'heroi', '🦇', ['salto', 'escudo'], 'O Cavaleiro das Trevas.'],
  ['wonder-woman', 'Wonder Woman', 'aurora', 'lendario', 'heroi', '⚔️', ['investida', 'escudo'], 'A guerreira amazona.'],
  ['flash', 'Flash', 'aurora', 'epico', 'heroi', '⚡', ['investida', 'salto'], 'O velocista escarlate.'],
  ['green-lantern', 'Green Lantern', 'aurora', 'incomum', 'heroi', '💚', ['escudo', 'disparo'], 'Portador do anel.'],
  ['aquaman', 'Aquaman', 'aurora', 'comum', 'heroi', '🌊', ['onda', 'investida'], 'Rei dos mares.'],
  ['joker', 'Joker', 'aurora', 'epico', 'vilao', '🃏', ['leque', 'onda'], 'O palhaço do crime.'],
  ['harley', 'Harley Quinn', 'aurora', 'raro', 'vilao', '🃏', ['investida', 'leque'], 'Caos imprevisível.'],
  ['lex', 'Lex Luthor', 'aurora', 'raro', 'vilao', '🧠', ['disparo', 'escudo'], 'Gênio e rival do Superman.'],

  // Dragon Ball
  ['goku', 'Goku', 'astral', 'lendario', 'heroi', '🐉', ['disparo', 'investida'], 'Saiyajin defensor da Terra.'],
  ['vegeta', 'Vegeta', 'astral', 'lendario', 'heroi', '👑', ['leque', 'investida'], 'Príncipe dos Saiyajins.'],
  ['gohan', 'Gohan', 'astral', 'epico', 'heroi', '📚', ['disparo', 'onda'], 'Filho de Goku.'],
  ['piccolo', 'Piccolo', 'astral', 'comum', 'heroi', '🟢', ['disparo', 'escudo'], 'Guerreiro namekuseijin.'],
  ['broly', 'Broly', 'astral', 'mitico', 'heroi', '💥', ['investida', 'onda'], 'Saiyajin de enorme poder.'],
  ['frieza', 'Frieza', 'astral', 'lendario', 'vilao', '👾', ['leque', 'meteoro'], 'Tirano galáctico.'],
  ['cell', 'Cell', 'astral', 'raro', 'vilao', '🧬', ['onda', 'cura'], 'Bioandroide.'],
  ['majin-buu', 'Majin Buu', 'astral', 'epico', 'vilao', '🍬', ['cura', 'onda'], 'Criatura mágica.'],
  ['beerus', 'Beerus', 'astral', 'mitico', 'vilao', '🐈', ['meteoro', 'salto'], 'Deus da destruição.'],
  ['whis', 'Whis', 'astral', 'celestial', 'heroi', '🌀', ['salto', 'escudo'], 'Anjo e mentor.'],
  ['trunks', 'Trunks', 'astral', 'incomum', 'heroi', '🗡️', ['investida', 'disparo'], 'Guerreiro do futuro.'],
  ['gogeta', 'Gogeta', 'astral', 'mitico', 'heroi', '✨', ['meteoro', 'investida'], 'Fusão de Goku e Vegeta.'],
  ['vegito', 'Vegito', 'astral', 'mitico', 'heroi', '✨', ['meteoro', 'leque'], 'Fusão pela Potara.'],

  // Attack on Titan
  ['eren', 'Eren Yeager', 'titas', 'mitico', 'heroi', '⚔️', ['investida', 'onda'], 'O protagonista da história.'],
  ['mikasa', 'Mikasa Ackerman', 'titas', 'lendario', 'heroi', '🧣', ['investida', 'escudo'], 'Uma combatente habilidosa.'],
  ['armin', 'Armin Arlert', 'titas', 'raro', 'heroi', '🧠', ['disparo', 'onda'], 'Estrategista.'],
  ['levi', 'Levi Ackerman', 'titas', 'mitico', 'heroi', '🗡️', ['investida', 'leque'], 'Capitão Levi.'],
  ['erwin', 'Erwin Smith', 'titas', 'lendario', 'heroi', '🫡', ['disparo', 'onda'], 'Comandante da Tropa de Exploração.'],
  ['hange', 'Hange Zoe', 'titas', 'epico', 'heroi', '🔬', ['disparo', 'escudo'], 'Pesquisadora de titãs.'],
  ['reiner', 'Reiner Braun', 'titas', 'lendario', 'heroi', '🛡️', ['escudo', 'investida'], 'Titã Blindado.'],
  ['annie', 'Annie Leonhart', 'titas', 'lendario', 'heroi', '💠', ['investida', 'salto'], 'Titã Fêmea.'],
  ['jean', 'Jean Kirstein', 'titas', 'comum', 'heroi', '🐴', ['investida', 'disparo'], 'Soldado da Tropa de Exploração.'],
  ['sasha', 'Sasha Blouse', 'titas', 'incomum', 'heroi', '🥔', ['disparo', 'investida'], 'A arqueira.'],
  ['historia', 'Historia Reiss', 'titas', 'epico', 'heroi', '👑', ['escudo', 'cura'], 'Rainha de Paradis.'],
  ['zeke', 'Zeke Yeager', 'titas', 'mitico', 'vilao', '🐒', ['leque', 'onda'], 'Titã Bestial.'],
  ['bertholdt', 'Bertholdt Hoover', 'titas', 'lendario', 'vilao', '💥', ['onda', 'meteoro'], 'Titã Colossal.'],

  // Naruto
  ['naruto', 'Naruto Uzumaki', 'konoha', 'lendario', 'heroi', '🍥', ['onda', 'investida'], 'Ninja da Vila da Folha.'],
  ['sasuke', 'Sasuke Uchiha', 'konoha', 'lendario', 'heroi', '⚡', ['salto', 'disparo'], 'Último sobrevivente do seu clã.'],
  ['sakura', 'Sakura Haruno', 'konoha', 'raro', 'heroi', '🌸', ['cura', 'onda'], 'Ninja médica.'],
  ['kakashi', 'Kakashi Hatake', 'konoha', 'lendario', 'heroi', '👁️', ['salto', 'disparo'], 'O Ninja Copiador.'],
  ['itachi', 'Itachi Uchiha', 'konoha', 'mitico', 'heroi', '🐦‍⬛', ['salto', 'onda'], 'Prodígio do clã Uchiha.'],
  ['madara', 'Madara Uchiha', 'konoha', 'mitico', 'vilao', '🔥', ['meteoro', 'onda'], 'Lendário líder Uchiha.'],
  ['hinata', 'Hinata Hyuga', 'konoha', 'comum', 'heroi', '💜', ['investida', 'escudo'], 'Usuária do Byakugan.'],
  ['gaara', 'Gaara', 'konoha', 'incomum', 'heroi', '🏜️', ['escudo', 'onda'], 'Kazekage da Areia.'],
  ['jiraiya', 'Jiraiya', 'konoha', 'lendario', 'heroi', '🐸', ['onda', 'cura'], 'Um dos Três Sannin.'],
  ['orochimaru', 'Orochimaru', 'konoha', 'mitico', 'vilao', '🐍', ['cura', 'disparo'], 'Ninja lendário e pesquisador.'],
  // One Piece
  ['luffy', 'Monkey D. Luffy', 'grandline', 'lendario', 'heroi', '🏴‍☠️', ['investida', 'onda'], 'Capitão dos Chapéus de Palha.'],
  ['zoro', 'Roronoa Zoro', 'grandline', 'lendario', 'heroi', '⚔️', ['investida', 'leque'], 'Espadachim dos Chapéus de Palha.'],
  ['nami', 'Nami', 'grandline', 'raro', 'heroi', '🧭', ['disparo', 'onda'], 'Navegadora da tripulação.'],
  ['sanji', 'Sanji', 'grandline', 'epico', 'heroi', '🍳', ['investida', 'leque'], 'Cozinheiro e lutador.'],
  ['ussop', 'Usopp', 'grandline', 'incomum', 'heroi', '🎯', ['disparo', 'leque'], 'Atirador da tripulação.'],
  ['chopper', 'Tony Tony Chopper', 'grandline', 'comum', 'heroi', '🦌', ['cura', 'investida'], 'Médico rena.'],
  ['robin', 'Nico Robin', 'grandline', 'epico', 'heroi', '🌺', ['onda', 'escudo'], 'Arqueóloga.'],
  ['ace', 'Portgas D. Ace', 'grandline', 'mitico', 'heroi', '🔥', ['meteoro', 'disparo'], 'Usuário do poder da chama.'],
  ['shanks', 'Shanks', 'grandline', 'mitico', 'heroi', '🟥', ['onda', 'investida'], 'Imperador do mar.'],
  ['blackbeard', 'Marshall D. Teach', 'grandline', 'mitico', 'vilao', '🌑', ['onda', 'meteoro'], 'Barba Negra.'],
  // Jujutsu Kaisen
  ['yuji', 'Yuji Itadori', 'feiticeiros', 'epico', 'heroi', '👊', ['investida', 'onda'], 'Estudante de feiticeiro jujutsu.'],
  ['megumi', 'Megumi Fushiguro', 'feiticeiros', 'incomum', 'heroi', '🐺', ['disparo', 'salto'], 'Usuário das Dez Sombras.'],
  ['nobara', 'Nobara Kugisaki', 'feiticeiros', 'raro', 'heroi', '🔨', ['disparo', 'onda'], 'Feiticeira de Tóquio.'],
  ['gojo', 'Satoru Gojo', 'feiticeiros', 'mitico', 'heroi', '🌀', ['salto', 'meteoro'], 'O feiticeiro mais forte.'],
  ['sukuna', 'Ryomen Sukuna', 'feiticeiros', 'mitico', 'vilao', '👹', ['onda', 'meteoro'], 'Rei das Maldições.'],
  ['maki', 'Maki Zenin', 'feiticeiros', 'lendario', 'heroi', '🥽', ['investida', 'leque'], 'Combatente excepcional.'],
  ['yuta', 'Yuta Okkotsu', 'feiticeiros', 'mitico', 'heroi', '🗡️', ['onda', 'cura'], 'Feiticeiro de grau especial.'],
  ['todo', 'Aoi Todo', 'feiticeiros', 'comum', 'heroi', '💪', ['investida', 'salto'], 'Feiticeiro de Kyoto.'],
  // Demon Slayer
  ['tanjiro', 'Tanjiro Kamado', 'cacadores', 'lendario', 'heroi', '🌊', ['onda', 'investida'], 'Caçador de onis.'],
  ['nezuko', 'Nezuko Kamado', 'cacadores', 'lendario', 'heroi', '🎋', ['investida', 'cura'], 'Demônio que protege humanos.'],
  ['zenitsu', 'Zenitsu Agatsuma', 'cacadores', 'incomum', 'heroi', '⚡', ['investida', 'salto'], 'Espadachim do Trovão.'],
  ['inosuke', 'Inosuke Hashibira', 'cacadores', 'comum', 'heroi', '🐗', ['leque', 'investida'], 'Caçador das Duas Lâminas.'],
  ['rengoku', 'Kyojuro Rengoku', 'cacadores', 'mitico', 'heroi', '🔥', ['meteoro', 'investida'], 'Hashira das Chamas.'],
  ['giyu', 'Giyu Tomioka', 'cacadores', 'raro', 'heroi', '🌊', ['escudo', 'investida'], 'Hashira da Água.'],
  ['shinobu', 'Shinobu Kocho', 'cacadores', 'lendario', 'heroi', '🦋', ['disparo', 'cura'], 'Hashira dos Insetos.'],
  ['muzan', 'Muzan Kibutsuji', 'cacadores', 'mitico', 'vilao', '🩸', ['cura', 'onda'], 'Origem dos demônios.'],
  // Pokémon
  ['pikachu', 'Pikachu', 'pokemon', 'epico', 'heroi', '⚡', ['disparo', 'onda'], 'Pokémon elétrico.'],
  ['charizard', 'Charizard', 'pokemon', 'lendario', 'heroi', '🐉', ['meteoro', 'disparo'], 'Pokémon de fogo e voo.'],
  ['mewtwo', 'Mewtwo', 'pokemon', 'mitico', 'heroi', '🧬', ['salto', 'meteoro'], 'Pokémon criado por engenharia genética.'],
  ['eevee', 'Eevee', 'pokemon', 'comum', 'heroi', '🦊', ['salto', 'cura'], 'Pokémon com várias evoluções.'],
  ['lucario', 'Lucario', 'pokemon', 'epico', 'heroi', '🥊', ['onda', 'investida'], 'Pokémon que sente a aura.'],
  ['greninja', 'Greninja', 'pokemon', 'lendario', 'heroi', '🐸', ['salto', 'disparo'], 'Pokémon ninja.'],
  ['gengar', 'Gengar', 'pokemon', 'raro', 'vilao', '👻', ['salto', 'onda'], 'Pokémon fantasma.'],
  ['snorlax', 'Snorlax', 'pokemon', 'incomum', 'heroi', '💤', ['escudo', 'onda'], 'Pokémon de grande resistência.'],
  // Transformers
  ['optimus', 'Optimus Prime', 'cybertron', 'mitico', 'heroi', '🚛', ['escudo', 'investida'], 'Líder dos Autobots.'],
  ['bumblebee', 'Bumblebee', 'cybertron', 'raro', 'heroi', '🐝', ['investida', 'disparo'], 'Autobot ágil.'],
  ['ratchet', 'Ratchet', 'cybertron', 'comum', 'heroi', '🚑', ['cura', 'disparo'], 'Médico Autobot.'],
  ['megatron', 'Megatron', 'cybertron', 'mitico', 'vilao', '🤖', ['meteoro', 'disparo'], 'Líder dos Decepticons.'],
  ['starscream', 'Starscream', 'cybertron', 'lendario', 'vilao', '✈️', ['leque', 'salto'], 'Comandante aéreo Decepticon.'],
  ['soundwave', 'Soundwave', 'cybertron', 'lendario', 'vilao', '📡', ['disparo', 'escudo'], 'Especialista em comunicações.'],
  ['arcee', 'Arcee', 'cybertron', 'incomum', 'heroi', '🏍️', ['investida', 'salto'], 'Autobot combatente.'],
  ['grimlock', 'Grimlock', 'cybertron', 'mitico', 'heroi', '🦖', ['onda', 'investida'], 'Líder dos Dinobots.'],
  // Sonic
  ['sonic', 'Sonic', 'sonic', 'lendario', 'heroi', '🦔', ['investida', 'salto'], 'O ouriço mais rápido.'],
  ['tails', 'Tails', 'sonic', 'incomum', 'heroi', '🦊', ['salto', 'disparo'], 'Inventor e parceiro de Sonic.'],
  ['knuckles', 'Knuckles', 'sonic', 'epico', 'heroi', '🥊', ['investida', 'onda'], 'Guardião da Master Emerald.'],
  ['shadow', 'Shadow', 'sonic', 'mitico', 'heroi', '🖤', ['salto', 'meteoro'], 'O ouriço supremo.'],
  ['amy', 'Amy Rose', 'sonic', 'comum', 'heroi', '🔨', ['investida', 'onda'], 'Amiga de Sonic.'],
  ['eggman', 'Dr. Eggman', 'sonic', 'raro', 'vilao', '🥚', ['disparo', 'onda'], 'Cientista rival de Sonic.'],
  ['metal-sonic', 'Metal Sonic', 'sonic', 'lendario', 'vilao', '🤖', ['investida', 'disparo'], 'Robô criado para superar Sonic.'],
  ['silver', 'Silver', 'sonic', 'epico', 'heroi', '✨', ['salto', 'onda'], 'O ouriço com poderes psíquicos.'],
  // Star Wars
  ['luke', 'Luke Skywalker', 'starwars', 'lendario', 'heroi', '⚔️', ['salto', 'onda'], 'Cavaleiro Jedi.'],
  ['leia', 'Leia Organa', 'starwars', 'incomum', 'heroi', '👑', ['disparo', 'escudo'], 'Líder da Aliança Rebelde.'],
  ['han', 'Han Solo', 'starwars', 'comum', 'heroi', '🚀', ['disparo', 'investida'], 'Contrabandista e piloto.'],
  ['vader', 'Darth Vader', 'starwars', 'mitico', 'vilao', '🖤', ['onda', 'meteoro'], 'Lorde Sith.'],
  ['yoda', 'Yoda', 'starwars', 'mitico', 'heroi', '🟢', ['salto', 'meteoro'], 'Mestre Jedi.'],
  ['obiwan', 'Obi-Wan Kenobi', 'starwars', 'lendario', 'heroi', '🧔', ['escudo', 'onda'], 'Mestre Jedi.'],
  ['mandalorian', 'Din Djarin', 'starwars', 'raro', 'heroi', '🛡️', ['disparo', 'escudo'], 'O Mandaloriano.'],
  ['palpatine', 'Darth Sidious', 'starwars', 'mitico', 'vilao', '⚡', ['disparo', 'meteoro'], 'Imperador Sith.'],

  // Marvel
  ['iron-man', 'Iron Man', 'vigilantes', 'epico', 'heroi', '🤖', ['disparo', 'escudo'], 'Armadura tecnológica.'],
  ['spider-man', 'Spider-Man', 'vigilantes', 'epico', 'heroi', '🕷️', ['salto', 'investida'], 'Herói com sentido aranha.'],
  ['thor', 'Thor', 'vigilantes', 'lendario', 'heroi', '🔨', ['onda', 'investida'], 'Deus do trovão.'],
  ['hulk', 'Hulk', 'vigilantes', 'raro', 'heroi', '💚', ['investida', 'onda'], 'Força extraordinária.'],
  ['captain-america', 'Captain America', 'vigilantes', 'comum', 'heroi', '🛡️', ['escudo', 'investida'], 'Herói com escudo.'],
  ['thanos', 'Thanos', 'vigilantes', 'mitico', 'vilao', '💠', ['meteoro', 'onda'], 'Titã poderoso.'],
  ['loki', 'Loki', 'vigilantes', 'epico', 'vilao', '🐍', ['salto', 'leque'], 'Mestre da ilusão.'],
  ['doctor-strange', 'Doctor Strange', 'vigilantes', 'lendario', 'heroi', '🔮', ['salto', 'onda'], 'Mestre das artes místicas.'],
  ['wolverine', 'Wolverine', 'vigilantes', 'epico', 'heroi', '🐺', ['investida', 'cura'], 'Mutante com fator de cura.'],
  ['deadpool', 'Deadpool', 'vigilantes', 'incomum', 'heroi', '🟥', ['investida', 'cura'], 'Mercenário irreverente.'],
  ['venom', 'Venom', 'vigilantes', 'lendario', 'vilao', '🕸️', ['onda', 'cura'], 'Simbionte.'],
  ['scarlet-witch', 'Scarlet Witch', 'vigilantes', 'mitico', 'heroi', '🔴', ['onda', 'meteoro'], 'Poderes místicos.'],
];

// As três skins são mantidas para cada personagem, com IDs próprios.
export const SKINS = [
  { id: 'base', nome: 'Original', bonus: 0 },
  { id: 'neon', nome: 'Neon', bonus: 1 },
  { id: 'sombra', nome: 'Sombria', bonus: 2 },
];

export const PERSONAGENS = LISTA.map(([id, nome, universo, raridade, lado, emoji, habilidades, descricao]) =>
  ({ id, nome, universo, raridade, lado, emoji, habilidades, descricao }));

export const VARIANTES = PERSONAGENS.flatMap((p) => SKINS.map((s) => {
  const r = RARIDADES[Math.min(ordemRaridade(p.raridade) + s.bonus, RARIDADES.length - 1)];
  return {
    ...p,
    id: `${p.id}:${s.id}`,
    personagem: p.id,
    skin: s.id,
    skinNome: s.nome,
    raridade: r.id,
    stats: {
      vida: Math.round(100 * r.poder),
      ataque: Math.round(14 * r.poder),
      velocidade: Math.round(190 + 25 * (r.poder - 1)),
    },
  };
}));

const MAPA = new Map(VARIANTES.map((v) => [v.id, v]));
export const variante = (id) => MAPA.get(id);
