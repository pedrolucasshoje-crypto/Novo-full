import { VARIANTES } from './characters.js';
// metrica = contador acompanhado | meta = objetivo | moedas/xp = recompensa
const m = (id, texto, metrica, meta, moedas, xp) => ({ id, texto, metrica, meta, moedas, xp });
export const MISSOES = {
  diarias: [
    m('d1', 'Abra 1 pacotinho', 'pacotes', 1, 60, 20),
    m('d2', 'Derrote 20 inimigos', 'abates', 20, 90, 30),
    m('d3', 'Complete 3 ondas', 'ondas', 3, 100, 40),
  ],
  semanais: [
    m('s1', 'Abra 10 pacotinhos', 'pacotes', 10, 350, 120),
    m('s2', 'Derrote 150 inimigos', 'abates', 150, 400, 150),
    m('s3', 'Vença 3 chefes', 'chefes', 3, 450, 180),
    m('s4', 'Consiga 3 cartas raras ou melhores', 'raros', 3, 300, 100),
  ],
  conquistas: [
    m('c1', 'Primeiro pacote', 'pacotes', 1, 100, 30),
    m('c2', 'Consiga um personagem raro', 'raros', 1, 100, 40),
    m('c3', 'Colecione 10 variantes', 'colecao', 10, 200, 80),
    m('c4', 'Colecione 40 variantes', 'colecao', 40, 600, 200),
    m('c5', 'Colecione todas as variantes', 'colecao', VARIANTES.length, 5000, 1000),
    m('c6', 'Complete a coleção de um universo', 'universos', 1, 1500, 400),
    m('c7', 'Derrote 500 inimigos', 'abates', 500, 800, 300),
    m('c8', 'Chegue à onda 10', 'melhorOnda', 10, 700, 250),
  ],
};
