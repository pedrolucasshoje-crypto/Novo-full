// Tipos de inimigos e composição das ondas
export const INIMIGOS = {
  rastejante: { emoji: '👾', vida: 30,  dano: 8,  vel: 85,  raio: 16, moedas: 1 },
  atirador:   { emoji: '🛸', vida: 24,  dano: 7,  vel: 60,  raio: 16, moedas: 2, tiro: 2.4 },
  bruto:      { emoji: '👹', vida: 80,  dano: 14, vel: 55,  raio: 23, moedas: 3 },
  mini:       { emoji: '🦂', vida: 320, dano: 16, vel: 70,  raio: 34, moedas: 20, tiro: 2.2, leque: 5, nome: 'Mini-chefe' },
  chefe:      { emoji: '🐲', vida: 700, dano: 20, vel: 58,  raio: 48, moedas: 60, tiro: 1.8, leque: 12, nome: 'CHEFE', chefe: true },
};
export const ULTIMA_ONDA = 10;
export function montarOnda(n) {
  const lista = [];
  for (let i = 0; i < 3 + n * 2; i++) {
    lista.push(n >= 4 && i % 5 === 4 ? 'bruto' : n >= 2 && i % 4 === 3 ? 'atirador' : 'rastejante');
  }
  if (n === 3 || n === 7) lista.push('mini');
  if (n === 5 || n === 10) lista.push('chefe');
  return lista;
}
export const forca = (onda) => 1 + (onda - 1) * 0.13;
