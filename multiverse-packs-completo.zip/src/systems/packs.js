// Sorteio e abertura de pacotes
import { CONFIG } from '../config.js';
import { RARIDADES, ordemRaridade } from '../data/rarities.js';
import { VARIANTES } from '../data/characters.js';
import { estado, salvar } from './state.js';
import { gastar } from './economy.js';
import { atualizarPeriodos } from './missions.js';

// chances reais do pacote: só entram raridades que existem nele
export function chances(pacote) {
  const pool = VARIANTES.filter(pacote.filtro);
  const lista = RARIDADES.map((r, i) => ({ r, cartas: pool.filter((v) => v.raridade === r.id), peso: r.peso * (i >= 2 ? pacote.bonus : 1) }))
    .filter((x) => x.cartas.length);
  const total = lista.reduce((s, x) => s + x.peso, 0);
  return lista.map((x) => ({ ...x, chance: x.peso / total }));
}
function sortear(tabela) {
  let n = Math.random();
  const grupo = tabela.find((x) => (n -= x.chance) < 0) ?? tabela.at(-1);
  return grupo.cartas[Math.floor(Math.random() * grupo.cartas.length)];
}
export function abrirPacote(pacote) {
  atualizarPeriodos();
  if (!gastar(pacote.preco)) return null;
  const tabela = chances(pacote);
  const resultado = Array.from({ length: CONFIG.cartasPorPacote }, () => {
    const v = sortear(tabela);
    const duplicado = Boolean(estado.cartas[v.id]);
    if (duplicado) { estado.cartas[v.id].duplicados++; estado.totais.duplicados++; }
    else estado.cartas[v.id] = { nivel: 1, xp: 0, duplicados: 0 };
    if (ordemRaridade(v.raridade) >= 2) estado.totais.raros++;
    return { v, duplicado };
  });
  estado.totais.pacotes++;
  salvar();
  return resultado;
}
