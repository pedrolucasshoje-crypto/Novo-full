import { PACOTES } from '../../data/packs.js';
import { raridade, ordemRaridade } from '../../data/rarities.js';
import { abrirPacote, chances } from '../../systems/packs.js';
import { estado } from '../../systems/state.js';
import { pacoteEvento } from '../../systems/events.js';
import { carta, modal, avisar } from '../dom.js';
import { vibrar } from '../feedback.js';

export const cartaoPacote = (p) => `<div class="painel pacote" style="--c:${p.cor}">
  <div class="icone">${p.icone}</div><b>${p.nome}</b>
  <button class="btn" data-abrir="${p.id}" ${estado.moedas < p.preco ? 'disabled' : ''}>🪙 ${p.preco}</button>
  <button class="suave" data-chances="${p.id}">Ver chances</button></div>`;

export function ligarPacotes(app, lista, redesenhar) {
  app.querySelectorAll('[data-chances]').forEach((b) => b.onclick = () => {
    const p = lista.find((x) => x.id === b.dataset.chances);
    const m = modal(`<div class="painel"><h2>${p.icone} ${p.nome}</h2><p class="suave">Chance de cada carta</p>
      ${chances(p).map((x) => `<p class="linha"><span style="color:${x.r.cor}">${x.r.nome}</span><b>${(x.chance * 100).toFixed(2)}%</b></p>`).join('')}
      <button class="btn">Fechar</button></div>`);
    m.querySelector('button').onclick = () => m.remove();
  });
  app.querySelectorAll('[data-abrir]').forEach((b) => b.onclick = () => {
    const p = lista.find((x) => x.id === b.dataset.abrir);
    animar(p, redesenhar);
  });
}
function animar(pacote, redesenhar) {
  if (document.querySelector('.modal')) return; // evita compra dupla
  const cartas = abrirPacote(pacote); // o resultado já fica salvo antes da animação
  if (!cartas) return avisar('Coins insuficientes');
  const m = modal(`<div class="estourando">${pacote.icone}</div>`);
  setTimeout(() => {
    if (!m.isConnected) return;
    m.firstChild.innerHTML = `<h2>Toque nas cartas</h2><div class="revela">${cartas.map(() => '<button aria-label="Revelar carta">❓</button>').join('')}</div>
      <button class="btn sec" id="todas">Revelar todas</button> <button class="btn" id="ok" hidden>Continuar</button>`;
    const botoes = [...m.querySelectorAll('.revela button')];
    const virar = (i) => {
      const b = botoes[i]; if (b.disabled) return;
      const { v, duplicado } = cartas[i];
      b.disabled = true; b.classList.add('virada');
      b.innerHTML = carta(v, `<span class="selo">${duplicado ? 'Repetida' : 'NOVA!'}</span>`);
      vibrar(ordemRaridade(v.raridade) >= 3 ? 120 : 25);
      if (ordemRaridade(v.raridade) >= 4) avisar(`✨ ${raridade(v.raridade).nome}!`);
      if (botoes.every((x) => x.disabled)) { m.querySelector('#ok').hidden = false; m.querySelector('#todas').hidden = true; }
    };
    botoes.forEach((b, i) => b.onclick = () => virar(i));
    m.querySelector('#todas').onclick = () => botoes.forEach((_, i) => virar(i));
    m.querySelector('#ok').onclick = () => { m.remove(); redesenhar(); };
  }, 1100);
}
export function pacotes(app) {
  const lista = [...PACOTES, pacoteEvento()];
  app.innerHTML = `<h2>🎴 Pacotinhos</h2><p class="suave">Cada pacote traz 3 cartas. Repetidas podem virar Coins na Coleção.</p><br>
    <div class="grade">${lista.map(cartaoPacote).join('')}</div>`;
  ligarPacotes(app, lista, () => pacotes(app));
}
