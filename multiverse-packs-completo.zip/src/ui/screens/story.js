import { FASES, ILHAS } from '../../data/story.js';
import { PERSONAGENS, variante } from '../../data/characters.js';
import { estado, salvar } from '../../systems/state.js';
import { atributos } from '../../systems/collection.js';
import { ganhar } from '../../systems/economy.js';
import { faseLiberada, faseConcluida, concluirFase, progressoHistoria } from '../../systems/story.js';
import { avisar } from '../dom.js';

let batalha = null;
const nomeInimigo = (id) => PERSONAGENS.find((p) => p.id === id)?.nome || id;
const idBase = (id) => id?.split(':')[0];
function desenhar(app) {
  if (batalha) return telaBatalha(app);
  const total = FASES.length, feitos = progressoHistoria();
  const meus = Object.keys(estado.cartas).filter((id) => variante(id));
  const selecionado = variante(estado.selecionado) || variante(meus[0]);
  app.innerHTML = `<h2>🗺️ Modo História</h2>
    <div class="painel"><b>Campanha: ${feitos}/${total} fases</b><div class="barra"><i style="width:${feitos / total * 100}%"></i></div><p class="suave">3 ilhas · 15 fases · chefes e recompensas. O progresso fica salvo no aparelho.</p></div>
    <div class="painel"><b>Personagem escolhido</b><p>${selecionado ? `${selecionado.emoji} ${selecionado.nome} — ${selecionado.skinNome}` : 'Nenhuma carta disponível'}</p>
    <label for="hist-personagem" class="suave">Escolher personagem da coleção</label><select id="hist-personagem" class="campo">${meus.map((id) => { const v = variante(id); return `<option value="${id}" ${id === selecionado?.id ? 'selected' : ''}>${v.emoji} ${v.nome} (${v.skinNome})</option>`; }).join('')}</select></div>
    ${ILHAS.map((ilha, ix) => { const lista = FASES.filter((f) => f.ilha === ix); const concluidas = lista.filter(faseConcluida).length; return `<section class="painel"><h3>${ilha.emoji} ${ilha.nome}</h3><p class="suave">${ilha.descricao} · ${concluidas}/5 concluídas</p><div class="grade fases">${lista.map((f) => { const liberada = faseLiberada(f), feita = faseConcluida(f); return `<button class="fase-card ${liberada ? '' : 'bloqueada'}" data-fase="${f.numero}" ${liberada ? '' : 'disabled'}><b>${feita ? '✅' : liberada ? (f.chefe ? '👑' : '⚔️') : '🔒'} Fase ${f.numero}</b><span>${f.nome}</span><small>${f.chefe ? 'CHEFE' : 'DESAFIO'} · ${f.moedas} 🪙</small></button>`; }).join('')}</div></section>`; }).join('')}`;
  app.querySelector('#hist-personagem').onchange = (e) => { estado.selecionado = e.target.value; salvar(); desenhar(app); };
  app.querySelectorAll('[data-fase]').forEach((b) => b.onclick = () => { const f = FASES.find((x) => x.numero === Number(b.dataset.fase)); iniciarBatalha(f, selecionado?.id); desenhar(app); });
}
function iniciarBatalha(fase, personagemId) {
  const v = variante(personagemId); if (!v) { avisar('Escolha uma carta da coleção primeiro.'); return; }
  const a = atributos(v.id);
  batalha = { fase, personagemId: v.id, hp: a.vida, maxHp: a.vida, ataque: a.ataque, energia: 0, inimigoHp: fase.vida, inimigoMax: fase.vida, defendendo: false, curaUsada: false, log: `${fase.historia} Sua vez!`, fim: false, venceu: false };
}
function telaBatalha(app) {
  const b = batalha, v = variante(b.personagemId), f = b.fase;
  app.innerHTML = `<h2>${f.chefe ? '👑 Chefe: ' : '⚔️ '}${f.nome}</h2><p class="suave">${f.historia}</p>
    <div class="painel batalha-card"><div class="combatente"><div class="avatar">${v.emoji}</div><b>${v.nome}</b><small>❤️ ${b.hp}/${b.maxHp}</small><div class="barra"><i style="width:${Math.max(0,b.hp/b.maxHp*100)}%"></i></div></div>
    <div class="versus">VS</div><div class="combatente"><div class="avatar">${PERSONAGENS.find(p => p.id === f.inimigo)?.emoji || '👾'}</div><b>${nomeInimigo(f.inimigo)}</b><small>❤️ ${b.inimigoHp}/${b.inimigoMax}</small><div class="barra inimigo"><i style="width:${Math.max(0,b.inimigoHp/b.inimigoMax*100)}%"></i></div></div></div>
    <div class="painel"><b>⚡ Energia: ${b.energia}/100</b><div class="barra energia-story"><i style="width:${b.energia}%"></i></div><p>${b.log}</p></div>
    ${b.fim ? `<div class="painel centro"><h3>${b.venceu ? '🏆 Vitória!' : '💫 Fim da tentativa'}</h3><p>${b.venceu ? `Recompensa: ${f.moedas} Coins e ${f.xp} XP${faseConcluida(f) ? ' (fase já concluída; sem recompensa extra)' : ''}.` : 'A fase continua disponível. Tente novamente com um personagem mais forte.'}</p><button class="btn" id="voltar">Voltar ao mapa</button></div>` : `<div class="grade acoes-historia"><button class="btn" id="atacar">👊 Ataque</button><button class="btn" id="especial" ${b.energia < 40 ? 'disabled' : ''}>✨ Especial (40)</button><button class="btn sec" id="curar" ${b.energia < 60 || b.curaUsada ? 'disabled' : ''}>💚 Curar (60)</button><button class="btn sec" id="defender">🛡️ Defender</button></div><p class="suave">Ataques aumentam energia. Especial causa dano maior. Curar pode ser usado uma vez por batalha. Defender reduz o próximo ataque recebido.</p>`}`;
  if (b.fim) { app.querySelector('#voltar').onclick = () => { batalha = null; desenhar(app); }; return; }
  app.querySelector('#atacar').onclick = () => turno(app, 'ataque');
  app.querySelector('#especial').onclick = () => turno(app, 'especial');
  app.querySelector('#curar').onclick = () => turno(app, 'curar');
  app.querySelector('#defender').onclick = () => turno(app, 'defender');
}
function turno(app, acao) {
  const b = batalha; if (!b || b.fim) return;
  let texto = '';
  if (acao === 'ataque') { const dano = Math.round(b.ataque * (0.9 + Math.random() * 0.25)); b.inimigoHp = Math.max(0, b.inimigoHp - dano); b.energia = Math.min(100, b.energia + 25); texto = `Você causou ${dano} de dano.`; }
  else if (acao === 'especial' && b.energia >= 40) { const dano = Math.round(b.ataque * 2.1); b.inimigoHp = Math.max(0, b.inimigoHp - dano); b.energia -= 40; texto = `Especial! ${dano} de dano.`; }
  else if (acao === 'curar' && b.energia >= 60 && !b.curaUsada) { const cura = Math.round(b.maxHp * 0.28); b.hp = Math.min(b.maxHp, b.hp + cura); b.energia -= 60; b.curaUsada = true; texto = `Você recuperou ${cura} de energia vital.`; }
  else if (acao === 'defender') { b.defendendo = true; b.energia = Math.min(100, b.energia + 15); texto = 'Você se preparou para reduzir o próximo golpe.'; }
  if (b.inimigoHp <= 0) { b.fim = true; b.venceu = true; const primeira = concluirFase(b.fase); b.log = `${texto} ${primeira ? 'Fase concluída! Recompensas recebidas.' : 'Fase vencida novamente.'}`; desenhar(app); return; }
  const danoInimigo = Math.max(1, Math.round(b.fase.ataque * (0.88 + Math.random() * 0.24) * (b.defendendo ? 0.45 : 1)));
  b.hp = Math.max(0, b.hp - danoInimigo); b.defendendo = false;
  if (b.hp <= 0) { b.fim = true; b.venceu = false; }
  b.log = `${texto} ${nomeInimigo(b.fase.inimigo)} causou ${danoInimigo} de dano.`;
  desenhar(app);
}
export function historia(app) { batalha = null; desenhar(app); return () => { batalha = null; }; }
