// Modo História side-scroller (módulo isolado para não alterar coleção/economia/arena).
import { PERSONAGENS, variante } from '../../data/characters.js';
import { estado, salvar } from '../../systems/state.js';
import { atributos } from '../../systems/collection.js';
import { iniciarBatalha2D } from '../../arena/battle2d.js';
import { urlArte } from '../art.js';
import { avisar } from '../dom.js';

const REGIOES=[
 {name:'Vale da Aurora',sky:['#71c8e8','#e7f4ff'],ground:'#36744a',boss:'thanos',bossName:'Thanos', mobs:[['joker',440],['frieza',840],['megatron',1240]],npc:'Lira',quest:'A ruptura está crescendo. Encontre os três guardiões e volte para o portal. O primeiro desafio aguarda.',width:1900},
 {name:'Terras Sombrias',sky:['#2b315b','#9a83bd'],ground:'#574b70',boss:'black-superman',bossName:'Superman Black',mobs:[['sukuna',470],['muzan',930],['shadow',1390]],npc:'Nara',quest:'As sombras corromperam os caminhos. Enfrente os guardiões para abrir a passagem.',width:2100},
 {name:'Nexus',sky:['#090d25','#473f7c'],ground:'#41415f',boss:'beerus',bossName:'Bills',mobs:[['palpatine',520],['broly',1060],['doctor-doom',1550]],npc:'Íon',quest:'O núcleo do multiverso está instável. Reúna forças e atravesse os últimos guardiões.',width:2300}
];
const FLOOR=440, HERO_W=44,HERO_H=64;
let cleanup=null;
function data(){estado.historia.mundo2d??={region:0,x:90,y:FLOOR-HERO_H,derrotados:[],quest:[],chefes:[],balls:0,whis:false};const d=estado.historia.mundo2d;d.derrotados??=[];d.quest??=[];d.chefes??=[];return d;}
function clamp(v,a,b){return Math.max(a,Math.min(b,v));}
function personagem(){return variante('liberty:base')||variante(estado.selecionado)||variante(Object.keys(estado.cartas).find(x=>variante(x)));}
function launchBattle(enemy, boss, region, app){const p=personagem();if(!p){avisar('Liberty não foi encontrado no catálogo.');return;}const id=`r${region}-${boss?'boss':enemy}`;const d=data();
 iniciarBatalha2D({jogadorId:p.id,inimigoId:enemy,modo:boss?'boss':'story-mob',boss:boss?REGIOES[region].boss:'',recompensa:boss?120:35,xp:boss?100:30,aoTerminar:(won)=>{if(won&&!d.derrotados.includes(id)){d.derrotados.push(id);if(boss)d.chefes.push(region);if(!boss)d.quest.push(id);salvar();}draw(app);}});
}
export function historia(app){cleanup?.();cleanup=null;draw(app);return()=>{cleanup?.();cleanup=null;};}
function draw(app){cleanup?.();cleanup=null;const d=data(),r=REGIOES[d.region],p=personagem();if(!p){app.innerHTML='<div class="painel">Liberty indisponível.</div>';return;}
 app.innerHTML=`<section class="story-world"><header class="story-hud"><div><b>Multiverse Packs · Campanha</b><small>${r.name} · Região ${d.region+1}/3</small></div><div><span>❤️ Liberty</span><span>⚡ Rajada</span></div></header><canvas class="story-canvas" aria-label="Mundo explorável"></canvas><div class="story-controls"><div class="story-pad"><button data-key="left">◀</button><button data-key="jump">▲</button><button data-key="right">▶</button></div><div class="story-actions"><button data-key="blast">✦ Rajada</button><button data-key="talk">💬</button><button data-key="pause">Ⅱ</button></div></div><div class="story-caption">${r.quest}</div><div class="story-regions">${REGIOES.map((x,i)=>`<button data-region="${i}" ${i>d.region&&!d.chefes.includes(i-1)?'disabled':''}>${i+1} · ${x.name}</button>`).join('')}</div></section>`;
 const canvas=app.querySelector('canvas'),ctx=canvas.getContext('2d');let width=0,height=0,dpr=1,floorY=FLOOR,raf=0,last=0,paused=false,keys={left:false,right:false,jump:false},shots=[],enemies=r.mobs.map(([id,x],i)=>({id,x,y:FLOOR-55,alive:!d.derrotados.includes(`r${d.region}-${id}`),phase:i})),hero={x:d.x||90,y:FLOOR-HERO_H,vx:0,vy:0,onGround:true,face:1,energy:100,hp:100,attack:0};const im=new Image();im.src=urlArte('liberty','base');const enemyImgs=new Map();r.mobs.forEach(([id])=>{const img=new Image();img.src=urlArte(id,'base');enemyImgs.set(id,img);});
 const resize=()=>{const rect=canvas.getBoundingClientRect();dpr=Math.min(devicePixelRatio||1,2);width=rect.width;height=rect.height;canvas.width=width*dpr;canvas.height=height*dpr;ctx.setTransform(dpr,0,0,dpr,0,0);floorY=Math.max(180,height*.78);hero.y=floorY-HERO_H;enemies.forEach(e=>e.y=floorY-55);};resize();const observer=new ResizeObserver(resize);observer.observe(canvas);
 function ground(x){return floorY;}
 function fire(){if(hero.energy<12)return;hero.energy-=12;shots.push({x:hero.x+hero.face*25,y:hero.y+30,v:hero.face*560,t:1.6});hero.attack=.22;}
 function talk(){const npcX=200;if(Math.abs(hero.x-npcX)<110){if(!d.quest.includes(`npc${d.region}`)){d.quest.push(`npc${d.region}`);avisar(`${r.npc}: ${r.quest}`);salvar();}else avisar('O portal se abre após os guardiões serem derrotados.');}else{const bossX=r.width-180;if(Math.abs(hero.x-bossX)<140){if(enemies.some(e=>e.alive)){avisar('O caminho do chefe está bloqueado pelos guardiões.');return;}if(!d.chefes.includes(d.region))launchBattle(r.boss,true,d.region,app);else avisar('Chefe desta região derrotado.');}}}
 function drawHero(cam){const x=hero.x-cam,y=hero.y;if(im.complete&&im.naturalWidth)ctx.drawImage(im,x-22,y,44,64);else{ctx.fillStyle='#2563eb';ctx.fillRect(x-17,y+18,34,46);ctx.fillStyle='#f0c9a8';ctx.beginPath();ctx.arc(x,y+12,18,0,Math.PI*2);ctx.fill();}if(hero.attack>0){ctx.fillStyle='#7de4ff';ctx.shadowBlur=16;ctx.shadowColor='#60a5fa';ctx.fillRect(x+hero.face*15,y+25,hero.face*16,8);ctx.shadowBlur=0;}}
 function render(){const cam=clamp(hero.x-width*.42,0,r.width-width);ctx.clearRect(0,0,width,height);const grad=ctx.createLinearGradient(0,0,0,height);grad.addColorStop(0,r.sky[0]);grad.addColorStop(1,r.sky[1]);ctx.fillStyle=grad;ctx.fillRect(0,0,width,height); // distant layers
 ctx.fillStyle='#ffffff20';for(let i=0;i<8;i++){const bx=(i*260-cam*.22)% (width+260);ctx.beginPath();ctx.arc(bx,150+(i%3)*35,60+i%2*25,0,Math.PI*2);ctx.fill();}
 ctx.fillStyle=r.ground;ctx.fillRect(0,floorY,width,height-floorY);ctx.fillStyle='#83c46a';ctx.fillRect(0,floorY,width,14);for(let x=0;x<r.width;x+=120){const sx=x-cam;if(sx<-40||sx>width+40)continue;ctx.fillStyle='#173d30';ctx.fillRect(sx,floorY-85,22,85);ctx.fillStyle='#2f8052';ctx.beginPath();ctx.arc(sx+11,floorY-100,38,0,Math.PI*2);ctx.fill();}
 // plataforma visual / portal / NPC
 ctx.fillStyle='#80634a';ctx.fillRect(320-cam,floorY-100,150,16);ctx.fillRect(710-cam,floorY-150,170,16);ctx.fillRect(1120-cam,floorY-90,160,16);ctx.fillStyle='#fbbf24';ctx.fillRect(180-cam,floorY-70,22,40);ctx.fillStyle='#ffe8a8';ctx.font='bold 16px sans-serif';ctx.fillText(r.npc,205-cam,floorY-82);ctx.strokeStyle='#b9a5ff';ctx.lineWidth=10;ctx.beginPath();ctx.ellipse(r.width-180-cam,floorY-70,44,70,0,0,Math.PI*2);ctx.stroke();ctx.fillStyle='#f5d0fe';ctx.font='bold 16px sans-serif';ctx.fillText('PORTAL',r.width-220-cam,floorY-160);
 enemies.forEach(e=>{if(!e.alive)return;const sx=e.x-cam;ctx.fillStyle='#9f1239';ctx.fillRect(sx-18,e.y-38,36,52);ctx.fillStyle='#f3c7a5';ctx.beginPath();ctx.arc(sx,e.y-42,19,0,Math.PI*2);ctx.fill();const img=enemyImgs.get(e.id);if(img?.complete&&img.naturalWidth){ctx.drawImage(img,sx-24,e.y-72,48,62);}ctx.fillStyle='#111';ctx.fillRect(sx-24,e.y-80,48,6);ctx.fillStyle='#f87171';ctx.fillRect(sx-24,e.y-80,48,6);ctx.fillStyle='#fff';ctx.font='12px sans-serif';ctx.fillText(PERSONAGENS.find(z=>z.id===e.id)?.nome||e.id,sx-35,e.y-88);});
 shots.forEach(s=>{ctx.fillStyle='#60a5fa';ctx.shadowBlur=14;ctx.shadowColor='#93c5fd';ctx.beginPath();ctx.ellipse(s.x-cam,s.y,16,7,0,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0;});drawHero(cam);ctx.fillStyle='#111a';ctx.fillRect(10,10,150,54);ctx.fillStyle='#fff';ctx.font='bold 14px sans-serif';ctx.fillText('LIBERTY',20,30);ctx.fillStyle='#7f1d1d';ctx.fillRect(20,38,120,8);ctx.fillStyle='#ef4444';ctx.fillRect(20,38,hero.hp*1.2,8);ctx.fillStyle='#075985';ctx.fillRect(20,50,120,6);ctx.fillStyle='#38bdf8';ctx.fillRect(20,50,hero.energy*1.2,6);}
 function update(dt){if(paused)return;hero.vx=(keys.left?-1:0)+(keys.right?1:0);hero.vx*=220; if(hero.vx)hero.face=Math.sign(hero.vx);hero.x=clamp(hero.x+hero.vx*dt,30,r.width-30);d.x=hero.x;hero.vy+=900*dt;hero.y+=hero.vy*dt;if(hero.y>=floorY-HERO_H){hero.y=floorY-HERO_H;hero.vy=0;hero.onGround=true;}if(keys.jump&&hero.onGround){hero.vy=-390;hero.onGround=false;keys.jump=false;}hero.energy=Math.min(100,hero.energy+8*dt);hero.attack=Math.max(0,hero.attack-dt);shots.forEach(s=>{s.x+=s.v*dt;s.t-=dt;enemies.forEach(e=>{if(e.alive&&Math.abs(s.x-e.x)<38&&Math.abs(s.y-e.y)<55){e.alive=false;d.derrotados.push(`r${d.region}-${e.id}`);s.t=0;salvar();}});});shots=shots.filter(s=>s.t>0&&s.x>0&&s.x<r.width);}
 function loop(ts){if(cleanup)return;const dt=Math.min(.04,(ts-last)/1000||0);last=ts;update(dt);render();raf=requestAnimationFrame(loop);}raf=requestAnimationFrame(loop);
 const listeners=[];function bind(el,fn,type='click'){el.addEventListener(type,fn);listeners.push(()=>el.removeEventListener(type,fn));}
 app.querySelectorAll('[data-key]').forEach(b=>{
   const k=b.dataset.key;
   if(k==='blast') bind(b,fire);
   else if(k==='talk') bind(b,talk);
   else if(k==='pause') bind(b,()=>{paused=!paused;b.textContent=paused?'▶':'Ⅱ';});
   else {bind(b,e=>{keys[k]=true;try{b.setPointerCapture(e.pointerId);}catch{};},'pointerdown');bind(b,()=>{keys[k]=false;},'pointerup');bind(b,()=>{keys[k]=false;},'pointercancel');bind(b,()=>{keys[k]=false;},'lostpointercapture');bind(b,()=>{keys[k]=false;},'pointerleave');}
 });
 app.querySelectorAll('[data-region]').forEach(b=>bind(b,()=>{const i=Number(b.dataset.region);if((i>d.region||i>0)&&!d.chefes.includes(i-1)){avisar('Conclua o chefe da região anterior para avançar.');return;}d.region=i;d.x=90;d.y=FLOOR-HERO_H;salvar();draw(app);}));
 bind(canvas,()=>talk(),'dblclick');
 const keydown=e=>{if(['ArrowLeft','ArrowRight','ArrowUp',' '].includes(e.key)){e.preventDefault();if(e.key==='ArrowLeft')keys.left=true;if(e.key==='ArrowRight')keys.right=true;if(e.key==='ArrowUp'||e.key===' ')keys.jump=true;}if(e.key.toLowerCase()==='f')fire();if(e.key.toLowerCase()==='e')talk();};const keyup=e=>{if(e.key==='ArrowLeft')keys.left=false;if(e.key==='ArrowRight')keys.right=false;};window.addEventListener('keydown',keydown);window.addEventListener('keyup',keyup);listeners.push(()=>window.removeEventListener('keydown',keydown),()=>window.removeEventListener('keyup',keyup));
 cleanup=()=>{cancelAnimationFrame(raf);observer.disconnect();listeners.forEach(f=>f());};
}
