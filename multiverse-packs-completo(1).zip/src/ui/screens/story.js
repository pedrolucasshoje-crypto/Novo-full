import { FASES, ILHAS } from '../../data/story.js';
import { PERSONAGENS, variante } from '../../data/characters.js';
import { estado, salvar } from '../../systems/state.js';
import { atributos } from '../../systems/collection.js';
import { ganhar } from '../../systems/economy.js';
import { concluirFase } from '../../systems/story.js';
import { avisar } from '../dom.js';

let batalha = null;
const WIDTH = 13, HEIGHT = 9;
const MUNDOS = [
  { npc: { x: 2, y: 2, nome: 'Aldeã Lira', fala: 'Bem-vindo à Ilha da Aurora! Derrote os guardiões menores e siga até o portal. Posso orientar sua jornada.' },
    mobs: [{id:'aurora-mob-1',x:5,y:6,inimigo:'joker',nome:'Capanga do Portal'},{id:'aurora-mob-2',x:8,y:4,inimigo:'frieza',nome:'Sentinela Gelado'},{id:'aurora-mob-3',x:10,y:6,inimigo:'thanos',nome:'Brutamontes Roxo'}], boss:{x:11,y:2,fase:4} },
  { npc: { x: 2, y: 2, nome: 'Viajante Nara', fala: 'O Arquipélago está corrompido. Os monstros guardam a trilha até o Senhor das Sombras.' },
    mobs: [{id:'sombras-mob-1',x:4,y:6,inimigo:'sukuna',nome:'Maldição Errante'},{id:'sombras-mob-2',x:8,y:4,inimigo:'muzan',nome:'Demônio da Névoa'},{id:'sombras-mob-3',x:10,y:6,inimigo:'megatron',nome:'Autômato Sombrio'}], boss:{x:11,y:2,fase:9} },
  { npc: { x: 2, y: 2, nome: 'Guardião Íon', fala: 'Você chegou ao Núcleo! Derrote os últimos defensores e enfrente a origem da ruptura.' },
    mobs: [{id:'nexus-mob-1',x:4,y:6,inimigo:'shadow',nome:'Eco Veloz'},{id:'nexus-mob-2',x:8,y:4,inimigo:'palpatine',nome:'Sentinela Sith'},{id:'nexus-mob-3',x:10,y:6,inimigo:'broly',nome:'Titã Berserker'}], boss:{x:11,y:2,fase:14} },
];
const PAREDES = [[3,4],[3,5],[6,2],[6,3],[6,4],[6,5],[9,2],[9,3],[9,4]];
const idChefe = (i) => `ilha-${i}-chefe`;
function dadosMapa() {
  if (!estado.historia.mapa) estado.historia.mapa = { ilha: 0, x: 1, y: 7, derrotados: [] };
  const m = estado.historia.mapa;
  if (!Array.isArray(m.derrotados)) m.derrotados = [];
  return m;
}
function ilhaLiberada(i) { return i === 0 || estado.historia.mapa?.derrotados?.includes(idChefe(i - 1)); }
function mapaConcluido(i) { return dadosMapa().derrotados.includes(idChefe(i)); }
function nomeInimigo(id) { return PERSONAGENS.find((p) => p.id === id)?.nome || id; }
function iniciarBatalha(encontro, personagemId) {
  const v = variante(personagemId);
  if (!v) { avisar('Escolha um personagem da coleção primeiro.'); return; }
  const a = atributos(v.id);
  batalha = { encontro, personagemId: v.id, hp: a.vida, maxHp: a.vida, ataque: a.ataque, energia: 0, inimigoHp: encontro.vida, inimigoMax: encontro.vida, defendendo: false, curaUsada: false, log: `${encontro.historia} Sua vez!`, fim: false, venceu: false };
}
function iniciarEncontro(inimigo, chefe = false, fase = null, mobId = '') {
  const nivel = dadosMapa().ilha;
  const base = fase || { vida: 65 + nivel * 45, ataque: 8 + nivel * 5, moedas: 25 + nivel * 20, xp: 15 + nivel * 10, inimigo };
  const encontro = { ...base, inimigo, chefe, mobId, historia: chefe ? 'O chefe protege o caminho. Vença para libertar esta ilha.' : 'Um inimigo bloqueia a trilha. Derrote-o para continuar.', nome: chefe ? nomeInimigo(inimigo) : (MUNDOS[dadosMapa().ilha].mobs.find(x=>x.id===mobId)?.nome || nomeInimigo(inimigo)) };
  const cartaAtual = variante(estado.selecionado) || variante(Object.keys(estado.cartas).find(id => variante(id)));
  iniciarBatalha(encontro, cartaAtual?.id);
}
function bloqueado(x,y) { return x < 0 || y < 0 || x >= WIDTH || y >= HEIGHT || PAREDES.some(([a,b]) => a===x && b===y); }
function mover(dx,dy,app) {
  if (batalha) return;
  const m = dadosMapa(), mundo = MUNDOS[m.ilha];
  const x=m.x+dx, y=m.y+dy;
  if (bloqueado(x,y)) return;
  const mob = mundo.mobs.find(e => e.x===x && e.y===y && !m.derrotados.includes(e.id));
  if (mob) { iniciarEncontro(mob.inimigo,false,null,mob.id); desenhar(app); return; }
  const chefeId=idChefe(m.ilha), chefeLiberado=mundo.mobs.every(e=>m.derrotados.includes(e.id));
  if (x===mundo.boss.x && y===mundo.boss.y && !m.derrotados.includes(chefeId)) {
    if (!chefeLiberado) { avisar('Derrote os três inimigos menores antes do chefe!'); return; }
    const f=FASES[mundo.boss.fase]; iniciarEncontro(f.inimigo,true,f,chefeId); desenhar(app); return;
  }
  m.x=x; m.y=y; salvar(); desenhar(app);
}
function interagir(app) {
  const m=dadosMapa(), npc=MUNDOS[m.ilha].npc;
  if (Math.abs(m.x-npc.x)+Math.abs(m.y-npc.y)<=1) avisar(`${npc.nome}: ${npc.fala}`);
  else avisar('Chegue perto de um aldeão para conversar.');
}
function desenhar(app) {
  if (batalha) return telaBatalha(app);
  const m=dadosMapa(), mundo=MUNDOS[m.ilha], ilha=ILHAS[m.ilha];
  const meus=Object.keys(estado.cartas).filter(id=>variante(id));
  const selecionado=variante(estado.selecionado)||variante(meus[0]);
  const mobsRestantes=mundo.mobs.filter(e=>!m.derrotados.includes(e.id)).length;
  const npc=mundo.npc, chefeId=idChefe(m.ilha), chefeFeito=m.derrotados.includes(chefeId), chefeLiberado=mobsRestantes===0;
  const tiles=[];
  for(let y=0;y<HEIGHT;y++) for(let x=0;x<WIDTH;x++) {
    let icon='', cls='grama', label='';
    if ((x===0||y===0||x===WIDTH-1||y===HEIGHT-1) && !(x===1&&y===7)) { cls='agua'; icon='🌊'; }
    if(PAREDES.some(([a,b])=>a===x&&b===y)){cls='arvore';icon='🌳';}
    if(x===1&&y===1){cls='casa';icon='🏠';}
    if(x===2&&y===2){cls='aldeao';icon='🧑‍🌾';label=npc.nome;}
    const mob=mundo.mobs.find(e=>e.x===x&&e.y===y&&!m.derrotados.includes(e.id));
    if(mob){cls='monstro';icon='👾';label=mob.nome;}
    if(x===mundo.boss.x&&y===mundo.boss.y&&!chefeFeito){cls=chefeLiberado?'chefe':'bloqueio';icon=chefeLiberado?'👑':'🔒';label=chefeLiberado?'Chefe':'Derrote os monstros';}
    if(m.x===x&&m.y===y){cls='jogador';icon=selecionado?.emoji||'🧍';label='Você';}
    tiles.push(`<div class="tile ${cls}" title="${label}">${icon}</div>`);
  }
  app.innerHTML=`<h2>🗺️ Modo História — Exploração</h2>
    <div class="painel"><div class="linha"><b>${ilha.emoji} ${ilha.nome}</b><b>${3-mobsRestantes}/3 inimigos</b></div><p class="suave">Explore o mapa, visite o vilarejo e derrote os inimigos para abrir o caminho do chefe.</p>
    <div class="barra"><i style="width:${(3-mobsRestantes+(chefeFeito?1:0))/4*100}%"></i></div></div>
    <div class="painel"><div class="linha"><b>🧭 Mapa da região</b><span class="suave">Posição: ${m.x+1}, ${m.y+1}</span></div><div class="mapa-aventura">${tiles.join('')}</div>
    <div class="legenda"><span>🧑‍🌾 Aldeão</span><span>👾 Inimigo</span><span>👑 Chefe</span><span>🌳 Obstáculo</span></div>
    <div class="controles-mapa"><button class="btn sec" data-move="0,-1">⬆️</button><div><button class="btn sec" data-move="-1,0">⬅️</button><button class="btn sec" data-move="0,1">⬇️</button><button class="btn sec" data-move="1,0">➡️</button></div><button class="btn" id="interagir">💬 Conversar</button></div>
    <p class="suave centro">Toque nas setas para andar. O personagem encontra inimigos ao encostar neles.</p></div>
    <div class="painel"><b>Personagem da jornada</b><p>${selecionado?`${selecionado.emoji} ${selecionado.nome} — ${selecionado.skinNome}`:'Nenhum personagem disponível'}</p><select id="hist-personagem" class="campo">${meus.map(id=>{const v=variante(id);return `<option value="${id}" ${id===selecionado?.id?'selected':''}>${v.emoji} ${v.nome} (${v.skinNome})</option>`}).join('')}</select></div>
    <div class="painel"><b>Regiões</b><div class="abas">${ILHAS.map((it,i)=>`<button class="${i===m.ilha?'ativo':''}" data-ilha="${i}" ${ilhaLiberada(i)?'':'disabled'}>${it.emoji} Ilha ${i+1}</button>`).join('')}</div><p class="suave">${chefeFeito?'Região libertada!':chefeLiberado?'O chefe está esperando no portal.':`Faltam ${mobsRestantes} inimigos antes do chefe.`}</p></div>`;
  app.querySelectorAll('[data-move]').forEach(b=>b.onclick=()=>{const [dx,dy]=b.dataset.move.split(',').map(Number);mover(dx,dy,app)});
  app.querySelector('#interagir').onclick=()=>interagir(app);
  app.querySelector('#hist-personagem').onchange=e=>{estado.selecionado=e.target.value;salvar();desenhar(app)};
  app.querySelectorAll('[data-ilha]').forEach(b=>b.onclick=()=>{const i=Number(b.dataset.ilha);if(!ilhaLiberada(i))return;m.ilha=i;m.x=1;m.y=7;salvar();desenhar(app)});
}
function telaBatalha(app) {
  const b=batalha,v=variante(b.personagemId),e=b.encontro;
  app.innerHTML=`<h2>${e.chefe?'👑 Chefe: ':'⚔️ Inimigo: '}${e.nome}</h2><p class="suave">${e.historia}</p>
    <div class="painel batalha-card"><div class="combatente"><div class="avatar">${v.emoji}</div><b>${v.nome}</b><small>❤️ ${b.hp}/${b.maxHp}</small><div class="barra"><i style="width:${Math.max(0,b.hp/b.maxHp*100)}%"></i></div></div><div class="versus">VS</div><div class="combatente"><div class="avatar">${PERSONAGENS.find(p=>p.id===e.inimigo)?.emoji||'👾'}</div><b>${nomeInimigo(e.inimigo)}</b><small>❤️ ${b.inimigoHp}/${b.inimigoMax}</small><div class="barra inimigo"><i style="width:${Math.max(0,b.inimigoHp/b.inimigoMax*100)}%"></i></div></div></div>
    <div class="painel"><b>⚡ Energia: ${b.energia}/100</b><div class="barra energia-story"><i style="width:${b.energia}%"></i></div><p>${b.log}</p></div>
    ${b.fim?`<div class="painel centro"><h3>${b.venceu?'🏆 Vitória!':'💫 Fim da tentativa'}</h3><p>${b.venceu?`Recompensa: ${e.moedas} Coins e ${e.xp} XP.`:'O inimigo venceu. Volte ao mapa e tente novamente.'}</p><button class="btn" id="voltar">Voltar à exploração</button></div>`:`<div class="grade acoes-historia"><button class="btn" id="atacar">👊 Ataque</button><button class="btn" id="especial" ${b.energia<40?'disabled':''}>✨ Especial (40)</button><button class="btn sec" id="curar" ${b.energia<60||b.curaUsada?'disabled':''}>💚 Curar (60)</button><button class="btn sec" id="defender">🛡️ Defender</button></div>`}`;
  if(b.fim){app.querySelector('#voltar').onclick=()=>{batalha=null;desenhar(app)};return;}
  app.querySelector('#atacar').onclick=()=>turno(app,'ataque');app.querySelector('#especial').onclick=()=>turno(app,'especial');app.querySelector('#curar').onclick=()=>turno(app,'curar');app.querySelector('#defender').onclick=()=>turno(app,'defender');
}
function turno(app,acao){
  const b=batalha;if(!b||b.fim)return;let texto='';
  if(acao==='ataque'){const d=Math.round(b.ataque*(.9+Math.random()*.25));b.inimigoHp=Math.max(0,b.inimigoHp-d);b.energia=Math.min(100,b.energia+25);texto=`Você causou ${d} de dano.`;}
  else if(acao==='especial'&&b.energia>=40){const d=Math.round(b.ataque*2.1);b.inimigoHp=Math.max(0,b.inimigoHp-d);b.energia-=40;texto=`Especial! ${d} de dano.`;}
  else if(acao==='curar'&&b.energia>=60&&!b.curaUsada){const c=Math.round(b.maxHp*.28);b.hp=Math.min(b.maxHp,b.hp+c);b.energia-=60;b.curaUsada=true;texto=`Você recuperou ${c} de vida.`;}
  else if(acao==='defender'){b.defendendo=true;b.energia=Math.min(100,b.energia+15);texto='Você se preparou para reduzir o próximo golpe.';}
  if(b.inimigoHp<=0){b.fim=true;b.venceu=true;const m=dadosMapa();if(b.encontro.chefe){m.derrotados.push(idChefe(m.ilha));const inicio=m.ilha*5;for(let i=0;i<4;i++){const id=`fase-${inicio+i+1}`;if(!estado.historia.concluidas.includes(id))estado.historia.concluidas.push(id);}const fase=FASES[m.ilha*5+4];concluirFase(fase);salvar();}else{m.derrotados.push(b.encontro.mobId);ganhar(b.encontro.moedas,b.encontro.xp);salvar();}b.log=`${texto} Vitória! O caminho foi liberado.`;desenhar(app);return;}
  const d=Math.max(1,Math.round(b.encontro.ataque*(.88+Math.random()*.24)*(b.defendendo?.45:1)));b.hp=Math.max(0,b.hp-d);b.defendendo=false;if(b.hp<=0){b.fim=true;b.venceu=false;}b.log=`${texto} ${nomeInimigo(b.encontro.inimigo)} causou ${d} de dano.`;desenhar(app);
}
export function historia(app){batalha=null;desenhar(app);return()=>{batalha=null};}
