// Configurações gerais: mude os valores aqui para ajustar o jogo
export const CONFIG = {
  versao: '1.4.0',
  moedasIniciais: 600,
  cartasPorPacote: 1,
  loginDiario: [100, 120, 140, 160, 180, 220, 350], // recompensa por dia seguido
  xpJogador: (nivel) => nivel * 100,    // XP para passar de nível
  xpPersonagem: (nivel) => nivel * 60,
  nivelMaximoPersonagem: 30,
};
