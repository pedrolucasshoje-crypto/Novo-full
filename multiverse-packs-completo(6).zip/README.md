# Multiverse Packs — edição completa

Jogo de coleção com pacotinhos, coleção, skins, missões, eventos, arena 2D e Modo História.

## Conteúdo
- 13 universos: Avengers: Doomsday, DC, Dragon Ball, Marvel, Attack on Titan, Naruto, One Piece, Jujutsu Kaisen, Demon Slayer, Pokémon, Transformers, Sonic e Star Wars.
- 223 personagens catalogados e 3 variantes visuais por personagem (Original, Neon e Sombria).
- 16 pacotes, missões, eventos, coleção, arena de sobrevivência e duelos 2D 1v1/2v2.
- Modo História: 3 ilhas, exploração, NPCs, enigmas obrigatórios e batalhas 2D contra Thanos, Superman Black e Bills (Beerus).
- Raridades: Comum 55%, Incomum 25%, Raro 12%, Épico 6%, Lendário 1,7%, Mítico 0,3%. Celestial é uma raridade visual de 0% na tabela base.

Cada universo possui cartas em todas as faixas de raridade com peso diferente de zero, para que os percentuais base não sejam artificialmente inflados pela ausência de uma categoria. Skins podem elevar a raridade visual da variante; o botão “Ver chances” mostra a distribuição efetiva do pacote.

## Rodar localmente
Na pasta do projeto: `python -m http.server 8000` e abra `http://localhost:8000`.

## Gerar APK no GitHub
Envie o conteúdo deste ZIP para a raiz do repositório (não coloque dentro de outra pasta). O workflow `.github/workflows/apk.yml` compila o APK e publica o arquivo em Actions → Artifacts.

O APK gerado é de debug/teste.


## Atualização 1.4.0
- Cada abertura de pacote entrega exatamente 1 personagem.
- Modo História com exploração por movimento, vilarejos, NPCs, inimigos menores e chefes em três ilhas.
- Catálogo ampliado para 202 personagens e 606 variantes de skins.
- Visual do Doctor Doom ajustado para armadura e capuz verdes com máscara metálica.
- As variantes não usam mais a raridade Celestial sem chance de obtenção; o topo da progressão é Mítico.


## Atualização 1.4.1 — Economia rebalanceada
- Saldo inicial reduzido para 250 Coins (apenas novos saves; saves existentes são preservados).
- Login diário, presente semanal, missões, recompensas de arena e bônus de nível reduzidos.
- Conversão de duplicados vale menos para evitar inflação de moedas.
- Pacotes priorizam variantes ainda não coletadas dentro da raridade sorteada; a raridade continua sendo sorteada normalmente.
- Cada pacote continua entregando exatamente 1 personagem.


## Atualização 1.5.0
- Catálogo expandido para 223 personagens e 669 variantes (Original, Neon e Sombria), sem IDs duplicados.
- Dragon Ball recebeu Yamcha, Chiaotzu, Goten, Videl, Goku Black, Android 17/18 e Goku/Vegeta Blue; fusões continuam em raridades altas.
- Duelos 2D: 1v1 (15 Coins por vitória) e 2v2 (25 Coins por vitória), com adversários sorteados entre todos os universos. Derrota concede 3 Coins.
- Chefes da campanha migrados para batalhas 2D: Thanos (teleporte, meteoros, laser e criaturas), Superman Black (laser, avanço rápido, gelo e criptonita) e Bills/Beerus (área roxa, cópias, segunda fase e projéteis).
- Após Bills, reúna as sete esferas e escolha poupá-lo ou derrotá-lo; poupá-lo adiciona Beerus à coleção.
- Enigmas de NPC são obrigatórios para abrir cada chefe.
- Economia mais difícil: pacotes e pacote de evento mais caros e login diário reduzido. Cada abertura continua entregando exatamente 1 personagem.
- Flow do GitHub Actions atualizado para procurar `multiverse-packs-completo(4).zip` na raiz do repositório.

**Controles dos duelos e chefes:** setas/WASD para mover, Espaço para atacar, Q para especial. No celular, use os botões na tela.

**Observação:** os personagens usam ilustrações vetoriais estilizadas próprias do projeto, não artes oficiais copiadas. O APK não foi compilado neste ambiente porque a instalação das dependências externas expirou; o workflow do GitHub fará a compilação.

## Atualização 1.5.1
- História e Duelos agora usam combate top-down compartilhado com a Arena: joystick virtual, ataque e poderes na tela.
- Inimigos e chefes se movimentam pela arena e usam projéteis e áreas de perigo.
