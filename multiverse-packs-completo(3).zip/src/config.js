// Configurações gerais: mude os valores aqui para ajustar o jogo
export const CONFIG = {
  versao: '1.4.2',
  moedasIniciais: 250,
  cartasPorPacote: 1,
  loginDiario: [25, 30, 35, 40, 45, 50, 60], // bônus modesto por sequência diária
  xpJogador: (nivel) => nivel * 100,    // XP para passar de nível
  xpPersonagem: (nivel) => nivel * 60,
  nivelMaximoPersonagem: 30,
};
