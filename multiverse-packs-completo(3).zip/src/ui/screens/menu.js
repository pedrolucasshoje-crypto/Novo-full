import { estado } from '../../systems/state.js';
import { statusLogin, coletarLogin } from '../../systems/economy.js';
import { quantidade } from '../../systems/collection.js';
import { eventoAtual, multiplicadorArena } from '../../systems/events.js';
import { VARIANTES } from '../../data/characters.js';
import { seguro, avisar } from '../dom.js';

export function menu(app) {
  const login = statusLogin(), e = eventoAtual();
  app.innerHTML = `<h1>MULTIVERSE<br>PACKS</h1>
    <p class="centro suave">Olá, ${seguro(estado.nome)}! ${quantidade()}/${VARIANTES.length} variantes coletadas.</p>
    <div class="painel linha"><div><b>🎁 Login diário</b><p class="suave">Dia ${login.dia} de 7 · ${login.valor} Coins</p></div>
      <button class="btn" id="login" ${login.disponivel ? '' : 'disabled'}>${login.disponivel ? 'Coletar' : 'Coletado'}</button></div>
    <div class="grade menu">
      ${[['pacotes','🎴','Pacotinhos'],['colecao','📚','Coleção'],['arena','⚔️','Arena 2D'],['historia','🗺️','Modo História'],['missoes','🎯','Missões'],['eventos',e.icone,'Eventos'],['perfil','👤','Perfil']]
        .map(([r, i, n]) => `<a class="painel" href="#${r}"><b>${i}</b>${n}</a>`).join('')}
    </div>
    ${multiplicadorArena() > 1 ? '<p class="centro">🔥 Fim de semana: recompensas da arena em dobro!</p>' : ''}`;
  app.querySelector('#login').onclick = () => {
    const r = coletarLogin();
    if (r) { avisar(`+${r.valor} Coins!`); menu(app); }
  };
}
