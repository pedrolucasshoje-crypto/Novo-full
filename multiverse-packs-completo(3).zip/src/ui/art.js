// Bonecos desenhados em SVG (arte própria). Cada personagem é uma combinação de peças.
// pele, cabelo [estilo, cor], roupa [cor, detalhe], olhos, boca, topo (cabeça), costas, item
const P = (pele, cabelo, roupa, extra = {}) => ({ pele, cabelo, roupa, olhos: 'normal', boca: 'sorriso', ...extra });
export const VISUAL = {
  doom:       P('#c8c7c2', ['careca','#111827'], ['#14532d','#9ca3af'], { topo: ['capuz','#166534'], olhos: 'brilho:#fbbf24', boca: 'grade', costas: ['capa','#064e3b'], emblema: 'nucleo' }),
  cinza:      P('#d9a684', ['curto','#6b6b70'], ['#57534e','#a8a29e'], { topo: ['oculos','#f59e0b'], costas: ['mochila','#78716c'], item: ['bastao','#a16207'], boca: 'serio' }),
  sucata:     P('#a86f4c', ['coque','#f97316'], ['#0f766e','#fbbf24'], { topo: ['oculos','#22d3ee'], item: ['chave','#cbd5e1'] }),
  praga:      P('#b7d7a8', ['careca','#000'], ['#e7e5e4','#65a30d'], { topo: ['mascara','#3f6212'], item: ['pocao','#a3e635'], olhos: 'brilho:#bef264', boca: 'nada' }),
  colosso:    P('#b91c1c', ['careca','#000'], ['#450a0a','#f87171'], { topo: ['chifres','#fde68a'], olhos: 'bravo', boca: 'presas', grande: true }),
  ceifador:   P('#e7e5e4', ['careca','#000'], ['#18181b','#52525b'], { topo: ['capuz','#27272a'], olhos: 'cova:#ef4444', boca: 'caveira', item: ['foice','#cbd5e1'] }),
  ruina:      P('#3f2a26', ['chamas','#f97316'], ['#292524','#ef4444'], { topo: ['chifres','#f97316'], olhos: 'brilho:#fde047', boca: 'presas', costas: ['aura','#ef4444'] }),
  eon:        P('#c7d2fe', ['longo','#f8fafc'], ['#312e81','#facc15'], { topo: ['aureola','#facc15'], olhos: 'brilho:#67e8f9', item: ['ampulheta','#facc15'], costas: ['aura','#818cf8'] }),

  cadete:     P('#f1c7a3', ['curto','#7c4a21'], ['#2563eb','#fde047'], { topo: ['quepe','#1d4ed8'], item: ['lanterna','#fde047'] }),
  falcao:     P('#c98d66', ['curto','#111827'], ['#1e293b','#f59e0b'], { topo: ['capacete','#334155'], costas: ['asas','#475569'], boca: 'serio' }),
  mare:       P('#8fd3c8', ['longo','#0e7490'], ['#155e75','#fbbf24'], { topo: ['coroa','#fbbf24'], item: ['tridente','#fbbf24'] }),
  relampago:  P('#8d5a3b', ['espetado','#fde047'], ['#dc2626','#fde047'], { topo: ['viseira','#fde047'], costas: ['aura','#facc15'], emblema: 'raio' }),
  trapaca:    P('#f5f5f4', ['dois','#16a34a'], ['#6d28d9','#22c55e'], { topo: ['bobo','#a855f7'], boca: 'largo', item: ['carta','#fff'] }),
  sentinela:  P('#7c4a2d', ['curto','#1c1917'], ['#ea580c','#fde047'], { costas: ['capa','#facc15'], olhos: 'brilho:#fef08a', emblema: 'sol' }),
  aurora:     P('#fbd5c0', ['longo','#f472b6'], ['#e0f2fe','#a78bfa'], { topo: ['aureola','#a5f3fc'], costas: ['asas','#c4b5fd'], item: ['joia','#67e8f9'] }),

  aprendiz:   P('#eab08a', ['espetado','#1f2937'], ['#f8fafc','#111827'], { topo: ['bandana','#dc2626'] }),
  mestra:     P('#f3c9a5', ['coque','#e5e7eb'], ['#ea580c','#7c2d12'], { olhos: 'feliz', item: ['bastao','#92400e'] }),
  brutus:     P('#8a5a44', ['moicano','#111827'], ['#365314','#a3e635'], { olhos: 'bravo', boca: 'presas', grande: true, topo: ['orelhas','#8a5a44'] }),
  principe:   P('#f0c4a0', ['chamas','#312e81'], ['#1e3a8a','#f8fafc'], { topo: ['coroa','#fbbf24'], costas: ['capa','#7f1d1d'], olhos: 'bravo', boca: 'serio' }),
  kaiou:      P('#eab08a', ['espetado','#fbbf24'], ['#c2410c','#1d4ed8'], { olhos: 'brilho:#22d3ee', costas: ['aura','#fbbf24'], boca: 'serio' }),
  tirano:     P('#c4b5fd', ['careca','#000'], ['#581c87','#f5f3ff'], { topo: ['antenas','#a855f7'], olhos: 'bravo', boca: 'largo', costas: ['capa','#3b0764'] }),
  divino:     P('#fde7d3', ['espetado','#e0f2fe'], ['#f8fafc','#38bdf8'], { topo: ['aureola','#e0f2fe'], olhos: 'brilho:#7dd3fc', costas: ['aura','#bae6fd'], emblema: 'estrela' }),

  entregador: P('#b97a56', ['curto','#292524'], ['#16a34a','#fef08a'], { topo: ['capacete','#ef4444'], costas: ['mochila','#f59e0b'] }),
  teia:       P('#f0bd9e', ['rabo','#111827'], ['#be123c','#e5e7eb'], { topo: ['mascara_olhos','#111827'], emblema: 'teia' }),
  bastiao:    P('#6f4330', ['curto','#111827'], ['#1d4ed8','#e5e7eb'], { topo: ['capacete','#1e40af'], item: ['escudo','#cbd5e1'], boca: 'serio' }),
  engenho:    P('#94a3b8', ['careca','#000'], ['#b91c1c','#fbbf24'], { topo: ['robo','#dc2626'], olhos: 'brilho:#67e8f9', boca: 'grade', emblema: 'nucleo' }),
  simbionte:  P('#0f0f14', ['careca','#000'], ['#09090b','#6366f1'], { olhos: 'branco', boca: 'presas', costas: ['tentaculos','#27272a'] }),
  titan:      P('#7e6a9e', ['careca','#000'], ['#854d0e','#fbbf24'], { topo: ['elmo','#ca8a04'], olhos: 'bravo', boca: 'serio', grande: true, item: ['joia','#f43f5e'] }),
  vigia:      P('#dbeafe', ['careca','#000'], ['#1e1b4b','#93c5fd'], { olhos: 'unico', boca: 'nada', costas: ['capa','#1e3a8a'], topo: ['aureola','#93c5fd'] }),

  estudante:  P('#f8d0b4', ['dois','#7c2d12'], ['#1e3a8a','#f43f5e'], { costas: ['mochila','#f472b6'], olhos: 'grande:#92400e' }),
  ninja:      P('#e9b996', ['rabo','#334155'], ['#1f2937','#64748b'], { topo: ['pano','#111827'], boca: 'nada', item: ['adaga','#cbd5e1'] }),
  idol:       P('#fbd3bd', ['dois','#22d3ee'], ['#db2777','#fde047'], { topo: ['fones','#f9a8d4'], item: ['microfone','#e5e7eb'], olhos: 'grande:#0891b2' }),
  espada:     P('#f2c3a2', ['longo','#dc2626'], ['#f8fafc','#1d4ed8'], { item: ['espada','#e2e8f0'], olhos: 'grande:#1d4ed8', boca: 'serio' }),
  oni:        P('#ef4444', ['longo','#1c1917'], ['#292524','#fbbf24'], { topo: ['chifres','#fef3c7'], olhos: 'brilho:#fde047', boca: 'presas', item: ['bastao','#57534e'] }),
  kitsune:    P('#fde4cf', ['longo','#fb923c'], ['#f8fafc','#dc2626'], { topo: ['raposa','#fb923c'], costas: ['caudas','#fb923c'], olhos: 'grande:#ca8a04' }),
  sonho:      P('#fbdcd0', ['longo','#c4b5fd'], ['#f9a8d4','#a78bfa'], { topo: ['flor','#f472b6'], olhos: 'feliz', costas: ['aura','#f0abfc'], item: ['cajado','#f0abfc'] }),

  aldeao:     P('#d49a73', ['curto','#a16207'], ['#4d7c0f','#a16207'], { topo: ['palha','#eab308'], item: ['forcado','#94a3b8'] }),
  arqueira:   P('#c58b63', ['rabo','#166534'], ['#14532d','#a3e635'], { topo: ['elfo','#c58b63'], item: ['arco','#a16207'] }),
  mago:       P('#efc3a1', ['longo','#e2e8f0'], ['#1d4ed8','#fde047'], { topo: ['mago','#1e3a8a'], barba: '#e2e8f0', item: ['cajado','#38bdf8'] }),
  bruxa:      P('#a3c98f', ['longo','#4c1d95'], ['#3b0764','#84cc16'], { topo: ['mago','#18181b'], item: ['vassoura','#ca8a04'], boca: 'largo' }),
  dragao:     P('#15803d', ['careca','#000'], ['#166534','#fde68a'], { topo: ['dragao','#fde68a'], costas: ['asas','#14532d'], olhos: 'brilho:#fbbf24', boca: 'focinho' }),
  fenix:      P('#fdba74', ['chamas','#ef4444'], ['#c2410c','#fde047'], { costas: ['asas','#f97316'], olhos: 'brilho:#fef9c3', boca: 'bico' }),
  serafim:    P('#fce0c8', ['curto','#fde68a'], ['#f8fafc','#fbbf24'], { topo: ['aureola','#fde047'], costas: ['asas','#f8fafc'], olhos: 'grande:#0ea5e9', item: ['espada','#fde68a'] }),

  recruta: P('#c98d66', ['curto','#292524'], ['#e2e8f0','#f97316'], { topo: ['bolha','#93c5fd'], item: ['pistola','#94a3b8'] }),
  mecanica: P('#8d5a3b', ['coque','#7c2d12'], ['#ca8a04','#1e293b'], { topo: ['fones','#f97316'], item: ['chave','#cbd5e1'] }),
  xeno: P('#5eead4', ['careca','#000'], ['#4c1d95','#f0abfc'], { topo: ['antenas','#14b8a6'], olhos: 'unico', boca: 'largo' }),
  cacadora: P('#c4b5fd', ['rabo','#be185d'], ['#3f3f46','#fb7185'], { topo: ['viseira','#fb7185'], item: ['pistola','#475569'], boca: 'serio' }),
  androide: P('#e2e8f0', ['careca','#000'], ['#334155','#22d3ee'], { topo: ['robo','#cbd5e1'], olhos: 'brilho:#22d3ee', boca: 'grade', emblema: 'nucleo' }),
  almirante: P('#94a3b8', ['curto','#e2e8f0'], ['#172554','#fbbf24'], { topo: ['quepe','#1e1b4b'], costas: ['capa','#312e81'], olhos: 'bravo', boca: 'serio' }),
  nebulosa: P('#a78bfa', ['chamas','#38bdf8'], ['#1e1b4b','#f0abfc'], { olhos: 'brilho:#e0f2fe', costas: ['aura','#818cf8'], emblema: 'estrela' }),

  vigiaesc: P('#e0ac86', ['curto','#44403c'], ['#334155','#fde047'], { topo: ['quepe','#1e293b'], item: ['lanterna','#fde047'], boca: 'serio' }),
  fantasma: P('#f8fafc', ['careca','#000'], ['#e2e8f0','#a5b4fc'], { olhos: 'cova:#93c5fd', costas: ['aura','#e0e7ff'] }),
  abobora: P('#f97316', ['careca','#000'], ['#3f2d1d','#84cc16'], { topo: ['talo','#4d7c0f'], olhos: 'brilho:#fde047', boca: 'presas' }),
  mumia: P('#e7dcc0', ['careca','#000'], ['#d6c7a1','#78716c'], { topo: ['faixas','#d6c7a1'], olhos: 'brilho:#4ade80', boca: 'serio' }),
  vampira: P('#ede9fe', ['longo','#1c1917'], ['#7f1d1d','#f43f5e'], { costas: ['asas','#450a0a'], olhos: 'grande:#dc2626', boca: 'presas' }),
  lobo: P('#78716c', ['espetado','#44403c'], ['#1e3a5f','#a8a29e'], { topo: ['raposa','#57534e'], olhos: 'brilho:#fbbf24', boca: 'presas', grande: true }),
  guardia: P('#f6d5bd', ['longo','#f8fafc'], ['#4c1d95','#fde047'], { topo: ['aureola','#fdba74'], item: ['cajado','#fb923c'], costas: ['aura','#fdba74'], olhos: 'feliz' }),

  grumete: P('#b97a56', ['espetado','#78350f'], ['#f1f5f9','#0369a1'], { topo: ['bandana','#0284c7'], item: ['bastao','#a16207'] }),
  cozinheiro: P('#e2a982', ['curto','#1c1917'], ['#f8fafc','#dc2626'], { topo: ['chef','#f8fafc'], barba: '#292524', grande: true }),
  canhoneira: P('#7c4a2d', ['rabo','#111827'], ['#9a3412','#fde68a'], { topo: ['tapa','#111827'], item: ['pistola','#57534e'], boca: 'largo' }),
  sereia: P('#f4c2a8', ['longo','#fb7185'], ['#0d9488','#99f6e4'], { topo: ['flor','#fdba74'], olhos: 'grande:#0d9488', item: ['tridente','#5eead4'] }),
  corsario: P('#c68863', ['longo','#991b1b'], ['#18181b','#fbbf24'], { topo: ['tricornio','#27272a'], item: ['espada','#e2e8f0'], costas: ['capa','#7f1d1d'], olhos: 'bravo' }),
  kraken: P('#5f9ea0', ['careca','#000'], ['#134e4a','#a3e635'], { topo: ['tricornio','#042f2e'], costas: ['tentaculos','#0f766e'], olhos: 'brilho:#bef264', boca: 'presas' }),
  farol: P('#cffafe', ['longo','#67e8f9'], ['#155e75','#fef08a'], { topo: ['aureola','#fef08a'], item: ['lanterna','#fef9c3'], costas: ['aura','#67e8f9'], olhos: 'brilho:#fde047' }),

  vaqueiro: P('#c98a62', ['curto','#78350f'], ['#92400e','#fde68a'], { topo: ['cowboy','#a16207'] }),
  xerife: P('#8d5a3b', ['rabo','#1c1917'], ['#1e40af','#fbbf24'], { topo: ['cowboy','#44403c'], emblema: 'estrela', item: ['pistola','#64748b'], boca: 'serio' }),
  mineiro: P('#d99f77', ['curto','#a8a29e'], ['#57534e','#f59e0b'], { topo: ['capacete','#eab308'], barba: '#d6d3d1', item: ['joia','#fde047'] }),
  bandida: P('#e5ae86', ['longo','#3f6212'], ['#3f2d20','#84cc16'], { topo: ['pano','#4d7c0f'], boca: 'nada', item: ['pistola','#334155'], olhos: 'bravo' }),
  pistoleiro: P('#b8896a', ['longo','#27272a'], ['#18181b','#a1a1aa'], { topo: ['cowboy','#18181b'], costas: ['capa','#27272a'], olhos: 'brilho:#fca5a5', boca: 'serio' }),
  bufalo: P('#57534e', ['moicano','#292524'], ['#44403c','#ea580c'], { topo: ['chifres','#e7e5e4'], olhos: 'brilho:#fb923c', boca: 'focinhoc', grande: true }),
  solnascente: P('#e8a87c', ['longo','#f97316'], ['#9d174d','#fde047'], { topo: ['cowboy','#fbbf24'], costas: ['aura','#fb923c'], olhos: 'grande:#ea580c' }),

  motoboy: P('#d6a27e', ['moicano','#2dd4bf'], ['#27272a','#2dd4bf'], { topo: ['fones','#facc15'], costas: ['mochila','#14b8a6'] }),
  hacker: P('#8a5a44', ['dois','#a3e635'], ['#18181b','#a3e635'], { topo: ['oculos','#a3e635'], olhos: 'feliz' }),
  dj: P('#f0c2a0', ['espetado','#e879f9'], ['#1e1b4b','#22d3ee'], { topo: ['fones','#22d3ee'], item: ['microfone','#e879f9'], boca: 'largo' }),
  lutadora: P('#c98d66', ['curto','#ec4899'], ['#334155','#f472b6'], { topo: ['bandana','#db2777'], olhos: 'bravo', grande: true }),
  drone: P('#3f3f46', ['careca','#000'], ['#18181b','#facc15'], { topo: ['antenas','#facc15'], costas: ['asas','#a1a1aa'], olhos: 'unico', boca: 'grade' }),
  magnata: P('#e7c3a8', ['curto','#d4d4d8'], ['#09090b','#14b8a6'], { topo: ['cartola','#18181b'], item: ['joia','#2dd4bf'], olhos: 'bravo', boca: 'largo' }),
  nucleo: P('#99f6e4', ['longo','#f0fdfa'], ['#0f172a','#2dd4bf'], { topo: ['aureola','#2dd4bf'], olhos: 'brilho:#f0fdfa', costas: ['aura','#2dd4bf'], emblema: 'nucleo' }),
};

// Pintura com volume: cada cor vira um degradê (luz em cima, sombra embaixo)
let tintas = new Map();
const mistura = (hex, alvo, q) => {
  const n = (h) => { h = h.slice(1); if (h.length === 3) h = [...h].map((c) => c + c).join(''); return [0, 2, 4].map((i) => parseInt(h.slice(i, i + 2), 16)); };
  const a = n(hex), b = n(alvo);
  return '#' + a.map((c, i) => Math.round(c + (b[i] - c) * q).toString(16).padStart(2, '0')).join('');
};
function tinta(cor) {
  if (!/^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(cor)) return cor;
  if (!tintas.has(cor)) tintas.set(cor, `t${tintas.size}`);
  return `url(#${tintas.get(cor)})`;
}
const degrades = () => [...tintas].map(([c, id]) => `<radialGradient id="${id}" cx=".36" cy=".28" r=".85"><stop offset="0" stop-color="${mistura(c, '#ffffff', 0.38)}"/><stop offset=".48" stop-color="${mistura(c, '#ffffff', 0)}"/><stop offset="1" stop-color="${mistura(c, '#0b0820', 0.48)}"/></radialGradient>`).join('');

const O = '#17102b'; // cor do contorno
const forma = (d, cor, extra = '') => `<path d="${d}" fill="${tinta(cor)}" stroke="${O}" stroke-width="1.5" stroke-linejoin="round" ${extra}/>`;
const bola = (x, y, rx, cor, ry = rx) => `<ellipse cx="${x}" cy="${y}" rx="${rx}" ry="${ry}" fill="${tinta(cor)}" stroke="${O}" stroke-width="1.5"/>`;
const ponto = (x, y, r, cor) => `<circle cx="${x}" cy="${y}" r="${r}" fill="${cor}"/>`;
const traco = (d, cor, w = 3) => `<path d="${d}" fill="none" stroke="${cor}" stroke-width="${w}" stroke-linecap="round" stroke-linejoin="round"/>`;
const haste = (d, cor, w = 4) => traco(d, O, w + 2.5) + traco(d, cor, w) + `<g transform="translate(-1 -.6)" opacity=".35">${traco(d, '#ffffff', w * 0.25)}</g>`;
const espelho = (s) => s + `<g transform="matrix(-1 0 0 1 120 0)">${s}</g>`;

const COSTAS = {
  capa: (c) => forma('M38 88 Q20 120 22 138 Q60 126 98 138 Q100 120 82 88Z', c),
  asas: (c) => espelho(forma('M42 96 Q4 52 4 82 Q8 90 14 90 Q6 100 18 104 Q14 114 28 114 Q34 112 44 108Z', c)),
  mochila: (c) => forma('M28 90 h18 v34 h-18 q-6 -17 0 -34Z', c),
  aura: (c) => `<ellipse cx="60" cy="70" rx="57" ry="66" fill="${c}" opacity=".16"/><ellipse cx="60" cy="72" rx="46" ry="56" fill="${c}" opacity=".18"/>`,
  caudas: (c) => [-80, -55, -30, 30, 55, 80].map((a) => `<g transform="rotate(${a} 60 116)">${forma('M60 116 Q42 84 60 48 Q78 84 60 116Z', c)}${forma('M52 66 Q60 40 68 66 Q60 60 52 66Z', '#fff')}</g>`).join(''),
  tentaculos: (c) => espelho(haste('M44 104 Q8 108 10 78 Q12 62 24 68', c, 6) + haste('M44 112 Q18 134 6 116', c, 5)),
};
const ITENS = {
  pistola: (c) => forma('M94 98 h24 v11 h-13 l-3 13 h-10Z', c) + ponto(118, 103.5, 3.5, '#67e8f9'),
  bastao: (c) => haste('M96 134 L106 76', c, 6),
  chave: (c) => haste('M98 128 L102 92', c, 5) + haste('M94 78 Q90 92 103 92 Q114 90 110 78', c, 5),
  pocao: (c) => forma('M96 94 h10 v10 q12 8 6 20 q-11 8 -22 0 q-6 -12 6 -20Z', c),
  foice: (c) => haste('M98 136 L106 46', '#78350f') + forma('M108 46 Q82 34 70 56 Q88 48 107 58Z', c),
  ampulheta: (c) => forma('M92 90 h22 l-9 15 9 15 h-22 l9 -15Z', c),
  lanterna: (c) => forma('M92 104 h12 v20 h-12Z', '#64748b') + forma('M88 104 L80 78 L112 76 L108 104Z', c, 'opacity=".85"'),
  tridente: (c) => haste('M100 136 L102 56', c) + haste('M90 44 Q88 64 102 62 Q116 62 114 42 M102 62 V40', c),
  joia: (c) => forma('M102 88 L116 104 L102 122 L88 104Z', c) + ponto(98, 100, 3, '#fff'),
  carta: (c) => `<g transform="rotate(16 102 104)">${forma('M92 88 h22 v32 h-22Z', c)}${forma('M103 95 l6 9 -6 9 -6 -9Z', '#dc2626')}</g>`,
  escudo: (c) => forma('M84 90 Q100 82 116 90 Q116 122 100 134 Q84 122 84 90Z', c) + ponto(100, 106, 7, '#1d4ed8'),
  adaga: (c) => forma('M98 108 L106 72 L112 108Z', c) + haste('M94 109 h22 M105 110 v12', '#78350f'),
  microfone: (c) => haste('M92 120 L102 96', '#334155', 6) + bola(104, 90, 10, c),
  espada: (c) => forma('M100 104 L102 40 L108 30 L114 42 L110 104Z', c) + haste('M92 106 h26 M105 108 v18', '#a16207', 5),
  cajado: (c) => haste('M98 136 L104 62', '#92400e', 5) + bola(105, 52, 11, c) + ponto(101, 48, 3, '#fff'),
  forcado: (c) => haste('M98 136 L104 70', '#92400e') + haste('M92 50 V68 Q104 76 116 68 V50 M104 50 V72', c, 3),
  arco: (c) => haste('M96 58 Q126 96 96 134', c, 5) + traco('M96 58 L96 134', '#e5e7eb', 1.5) + haste('M82 96 H114', '#e5e7eb', 2),
  vassoura: (c) => haste('M92 134 L110 50', '#78350f') + forma('M104 58 L96 28 Q112 18 120 34 L114 62Z', c),
};
const CABELO_TRAS = {
  longo: (c) => forma('M20 52 Q14 6 60 10 Q106 6 100 52 L108 104 Q90 96 86 82 H34 Q30 96 12 104Z', c),
  rabo: (c) => forma('M88 28 Q120 30 108 92 Q104 66 88 60Z', c),
  dois: (c) => espelho(forma('M26 36 Q-2 40 10 96 Q16 72 30 64Z', c)),
  chamas: (c) => forma('M20 62 Q2 36 22 30 Q14 8 40 14 Q46 -6 62 8 Q82 -6 84 16 Q112 8 98 34 Q118 44 100 64Z', c),
};
const FRANJA = 'M21 52 Q18 14 60 13 Q102 14 99 52 Q88 34 76 36 Q70 26 62 34 Q46 24 40 38 Q28 34 21 52Z';
const CABELO_FRENTE = {
  curto: (c) => forma(FRANJA, c), longo: (c) => forma(FRANJA, c), rabo: (c) => forma(FRANJA, c), dois: (c) => forma(FRANJA, c), chamas: (c) => forma(FRANJA, c),
  espetado: (c) => forma('M20 54 L10 30 L28 30 L24 6 L46 17 L58 -2 L72 16 L96 4 L92 28 L112 30 L100 54 L86 34 L76 42 L64 28 L52 42 L40 30 L32 44Z', c),
  coque: (c) => bola(60, 12, 14, c) + forma(FRANJA, c),
  moicano: (c) => forma('M48 34 Q36 -2 62 0 Q88 -2 72 34 Q60 26 48 34Z', c),
  careca: () => `<ellipse cx="40" cy="28" rx="11" ry="6" fill="#fff" opacity=".18" transform="rotate(-25 40 28)"/>`,
};
const TOPO = {
  bolha: (c) => `<circle cx="60" cy="49" r="52" fill="${c}" fill-opacity=".14" stroke="${c}" stroke-width="3"/>` + traco('M20 36 Q28 14 48 6', '#ffffffaa', 5),
  talo: (c) => traco('M38 18 Q30 50 40 80 M82 18 Q90 50 80 80', '#7c2d1266', 3) + forma('M54 16 Q52 -2 66 -6 L70 2 Q62 4 66 16Z', c),
  faixas: (c) => haste('M22 38 Q60 20 99 32', c, 7) + haste('M26 25 Q62 40 96 44', c, 6) + haste('M24 78 Q60 94 96 74', c, 7),
  tapa: (c) => traco('M23 36 L96 66', c, 3) + bola(77, 55, 11, c, 12),
  chef: (c) => bola(42, 6, 15, c) + bola(78, 6, 15, c) + bola(60, 0, 18, c) + forma('M36 10 h48 v20 Q60 22 36 30Z', c),
  tricornio: (c) => forma('M8 28 Q22 22 30 6 Q60 -14 90 6 Q98 22 112 28 Q60 44 8 28Z', c) + bola(60, 12, 6, '#f8fafc'),
  cowboy: (c) => forma('M4 24 Q20 40 60 30 Q100 40 116 24 Q108 46 60 40 Q12 46 4 24Z', c) + forma('M34 32 Q28 -6 48 0 Q60 8 72 0 Q92 -6 86 32 Q60 24 34 32Z', c) + traco('M35 25 Q60 18 85 25', '#fbbf24', 4),
  cartola: (c) => forma('M36 24 L34 -8 Q60 -14 86 -8 L84 24Z', c) + bola(60, 25, 40, c, 7) + traco('M37 15 Q60 11 83 15', '#14b8a6', 5),
  oculos: (c) => haste('M22 33 Q60 22 98 33', '#44403c') + espelho(bola(44, 29, 11, c) + ponto(40, 25, 3, '#fff')),
  mascara: (c) => forma('M36 62 Q60 52 84 62 Q82 86 60 88 Q38 86 36 62Z', c) + espelho(bola(43, 74, 7, '#a3a3a3')),
  mascara_olhos: (c) => forma('M22 45 Q60 36 98 45 Q96 68 76 66 Q66 60 60 54 Q54 60 44 66 Q24 68 22 45Z', c),
  pano: (c) => forma('M23 62 Q60 56 97 62 Q92 86 60 88 Q28 86 23 62Z', c) + forma('M21 38 Q60 26 99 38 L99 30 Q60 6 21 30Z', c),
  chifres: (c) => espelho(forma('M30 28 Q8 18 14 0 Q22 14 42 18Z', c)),
  capuz: (c) => forma('M14 74 Q2 2 60 2 Q118 2 106 74 L98 70 Q106 22 60 22 Q14 22 22 70Z', c),
  aureola: (c) => `<ellipse cx="60" cy="6" rx="24" ry="6" fill="none" stroke="${c}" stroke-width="5"/>`,
  quepe: (c) => forma('M24 30 Q26 2 60 4 Q94 2 96 30 Q60 20 24 30Z', c) + forma('M30 29 Q60 18 90 29 Q60 40 30 29Z', '#0f172a') + ponto(60, 14, 5, '#fde047'),
  capacete: (c) => forma('M17 50 Q12 4 60 4 Q108 4 103 50 Q82 30 60 32 Q38 30 17 50Z', c) + traco('M60 8 V30', '#ffffff88', 5),
  coroa: (c) => forma('M36 22 L34 0 L48 11 L60 -3 L72 11 L86 0 L84 22 Q60 14 36 22Z', c) + ponto(60, 12, 3, '#ef4444'),
  viseira: (c) => forma('M22 44 Q60 36 98 44 L95 60 Q60 52 25 60Z', c, 'opacity=".72"') + espelho(forma('M20 40 L2 22 L24 28Z', c)),
  bobo: (c) => espelho(forma('M26 32 Q-2 22 8 2 Q30 4 52 18Z', c) + bola(8, 4, 6, '#fde047')),
  bandana: (c) => forma('M21 34 Q60 20 99 34 L98 43 Q60 31 22 43Z', c) + forma('M97 36 L116 30 L106 42 L118 52 L98 44Z', c),
  orelhas: (c) => espelho(bola(18, 52, 9, c, 12)),
  antenas: (c) => espelho(haste('M42 20 Q34 4 20 4', c) + bola(18, 4, 6, '#f0abfc')),
  robo: (c) => forma('M18 56 Q12 6 60 8 Q108 6 102 56 L90 40 H30Z', c) + espelho(forma('M14 46 h10 v24 h-10Z', '#fbbf24')),
  elmo: (c) => forma('M18 46 Q18 6 60 6 Q102 6 102 46 L90 36 L70 34 L60 46 L50 34 L30 36Z', c) + forma('M55 8 L60 -4 L65 8Z', c),
  fones: (c) => traco('M19 52 Q18 6 60 8 Q102 6 101 52', c, 6) + espelho(bola(20, 54, 10, c, 14)),
  flor: (c) => [0, 72, 144, 216, 288].map((a) => `<g transform="rotate(${a} 88 24)">${bola(88, 15, 6, c, 9)}</g>`).join('') + bola(88, 24, 5, '#fde047'),
  raposa: (c) => espelho(forma('M24 36 L18 -2 L52 18Z', c) + forma('M27 24 L25 9 L40 19Z', '#fff')),
  palha: (c) => bola(60, 26, 52, c, 9) + forma('M36 26 Q36 0 60 0 Q84 0 84 26 Q60 34 36 26Z', c),
  elfo: (c) => espelho(forma('M24 46 L2 32 L22 68Z', c)),
  mago: (c) => bola(60, 28, 48, c, 9) + forma('M34 28 Q50 14 54 -2 Q70 -6 84 4 Q72 6 74 10 L86 28 Q60 36 34 28Z', c) + ponto(62, 14, 4, '#fde047'),
  dragao: (c) => espelho(forma('M32 24 Q20 0 6 2 Q16 14 22 34Z', c)) + forma('M52 15 L60 0 L68 15Z', c),
};
function olhos(tipo, iris) {
  const [t, cor] = tipo.split(':');
  const cilios = (y) => espelho(traco(`M31 ${y + 3} Q42 ${y - 5} 53 ${y + 1} M32 ${y + 2} l-4 -2`, O, 3));
  const vivo = (c, ry = 12) => espelho(bola(42, 56, 10, '#ffffff', ry) + `<ellipse cx="43" cy="57" rx="7.6" ry="${ry - 2.5}" fill="${tinta(c)}"/>`
    + `<ellipse cx="43.5" cy="58" rx="4" ry="${ry / 2}" fill="${O}"/>` + ponto(46.5, 51.5, 3.2, '#fff') + ponto(40, 62, 1.6, '#fff'));
  if (t === 'grande') return vivo(cor, 13) + cilios(44);
  if (t === 'bravo') return vivo(iris, 9) + espelho(forma('M28 37 L55 47 L53 52 L29 44Z', O));
  if (t === 'brilho') return espelho(`<ellipse cx="43" cy="56" rx="14" ry="13" fill="${cor}" opacity=".32"/>` + bola(43, 56, 8, cor, 8.5) + ponto(43, 57, 3, '#ffffffcc') + ponto(46.5, 52, 2.4, '#fff'));
  if (t === 'cova') return espelho(bola(43, 55, 11, O, 12) + `<circle cx="43" cy="56" r="7" fill="${cor}" opacity=".35"/>` + ponto(43, 56, 3.8, cor) + ponto(44.5, 54.5, 1.2, '#fff'));
  if (t === 'branco') return espelho(forma('M27 40 Q51 42 55 63 Q31 70 27 40Z', '#ffffff'));
  if (t === 'unico') return bola(60, 54, 20, '#ffffff') + ponto(60, 55, 13, tinta('#2563eb')) + ponto(60, 55, 6.5, O) + ponto(66, 48, 4.5, '#fff') + ponto(55, 62, 2, '#fff');
  if (t === 'feliz') return espelho(traco('M33 58 Q43 45 53 58', O, 4) + traco('M33 58 l-4 -1', O, 2.5));
  return vivo(iris) + cilios(45);
}
const BOCAS = {
  focinhoc: () => bola(60, 73, 21, '#a8a29e', 12) + ponto(52, 72, 3, O) + ponto(68, 72, 3, O) + traco('M50 80 Q60 86 70 80', '#fbbf24', 3),
  sorriso: () => traco('M51 70 Q60 78 69 70', O),
  serio: () => traco('M53 73 H67', O),
  largo: () => forma('M40 68 Q60 74 80 68 Q60 92 40 68Z', '#7f1d1d') + traco('M45 71 Q60 76 75 71', '#fff', 3),
  presas: () => forma('M43 69 Q60 66 77 69 Q60 86 43 69Z', '#450a0a') + forma('M47 69 l4 9 4 -9Z M65 69 l4 9 4 -9Z', '#fff'),
  caveira: () => forma('M56 66 l4 -7 4 7Z', O) + traco('M46 75 H74 M50 71 V79 M57 71 V79 M64 71 V79 M71 71 V79', O, 2),
  grade: () => forma('M46 68 h28 l-4 12 h-20Z', '#1e293b') + traco('M51 72 H69 M53 76 H67', '#94a3b8', 1.5),
  focinho: () => bola(60, 72, 20, '#4ade80', 12) + ponto(53, 69, 2.5, O) + ponto(67, 69, 2.5, O) + traco('M48 77 Q60 82 72 77', O, 2),
  bico: () => forma('M50 66 Q60 62 70 66 L60 82Z', '#facc15'),
  nada: () => '',
};
const EMBLEMAS = {
  raio: () => forma('M63 94 L52 110 H60 L56 124 L70 104 H61Z', '#fde047'),
  sol: () => bola(60, 108, 8, '#fde047') + traco('M60 94 V97 M60 119 V122 M46 108 H49 M71 108 H74', '#fde047'),
  estrela: () => forma('M60 96 l4 9 10 1 -7 7 2 10 -9 -5 -9 5 2 -10 -7 -7 10 -1Z', '#38bdf8'),
  teia: () => traco('M60 94 V124 M46 100 L74 118 M74 100 L46 118 M52 103 Q60 99 68 103 M52 115 Q60 119 68 115', '#e5e7eb', 1.5),
  nucleo: () => bola(60, 108, 8, '#a5f3fc') + ponto(60, 108, 3.5, '#fff'),
};

// Cada personagem oficial usa uma base visual existente do projeto.
// As skins continuam sendo aplicadas sobre essa base.
const VISUAL_OFICIAL = {
  'doctor-doom': 'doom',
  doomsday: 'colosso', darkseid: 'ruina',
  superman: 'sentinela', batman: 'ceifador', 'wonder-woman': 'aurora',
  flash: 'relampago', 'green-lantern': 'vigia', aquaman: 'mare',
  joker: 'trapaca', harley: 'ninja', lex: 'engenho',
  goku: 'aprendiz', vegeta: 'principe', gohan: 'estudante', piccolo: 'mestra',
  broly: 'brutus', frieza: 'tirano', cell: 'xeno', 'majin-buu': 'praga',
  beerus: 'divino', whis: 'serafim', trunks: 'espada', gogeta: 'kaiou', vegito: 'kaiou',
  'iron-man': 'engenho', 'spider-man': 'teia', thor: 'bastiao', hulk: 'brutus',
  'captain-america': 'vigiaesc', thanos: 'titan', loki: 'trapaca',
  'doctor-strange': 'mago', wolverine: 'lobo', deadpool: 'cacadora',
  venom: 'simbionte', 'scarlet-witch': 'bruxa',
  // Attack on Titan
  eren: 'colosso', mikasa: 'ninja', armin: 'estudante', levi: 'espada', erwin: 'cadete', hange: 'cinza', reiner: 'brutus', annie: 'espada', jean: 'cadete', sasha: 'entregador', historia: 'aurora', zeke: 'tirano', bertholdt: 'colosso',
  // Naruto
  naruto: 'aprendiz', sasuke: 'ninja', sakura: 'mestra', kakashi: 'cadete', itachi: 'ninja', madara: 'principe', hinata: 'sonho', gaara: 'tirano', jiraiya: 'mago', orochimaru: 'bruxa', temari: 'arqueira', shikamaru: 'cinza', 'rock-lee': 'brutus', tsunade: 'mestra',
  // One Piece
  luffy: 'aprendiz', zoro: 'espada', nami: 'sonho', sanji: 'falcao', ussop: 'cadete', chopper: 'brutus', robin: 'aurora', ace: 'fenix', shanks: 'principe', blackbeard: 'ruina', franky: 'engenho', brook: 'ceifador', jinbe: 'mare', 'trafalgar-law': 'ninja',
  // Jujutsu Kaisen
  yuji: 'aprendiz', megumi: 'ninja', nobara: 'estudante', gojo: 'divino', sukuna: 'oni', maki: 'espada', yuta: 'estudante', todo: 'brutus', panda: 'brutus', 'kento-nanami': 'cadete', 'toji-fushiguro': 'ninja', mahito: 'praga',
  // Demon Slayer
  tanjiro: 'espada', nezuko: 'kitsune', zenitsu: 'relampago', inosuke: 'brutus', rengoku: 'fenix', giyu: 'mare', shinobu: 'sonho', muzan: 'tirano', mitsuri: 'aurora', obanai: 'ninja', gyomei: 'brutus', daki: 'sonho',
  // Star Wars
  luke: 'aprendiz', leia: 'cadete', han: 'entregador', vader: 'ceifador', yoda: 'mago', obiwan: 'mago', mandalorian: 'recruta', palpatine: 'ruina', ahsoka: 'espada', rey: 'aurora', 'kylo-ren': 'principe', 'boba-fett': 'recruta',
  // Sonic and Transformers
  sonic: 'relampago', tails: 'mecanica', knuckles: 'brutus', shadow: 'ceifador', amy: 'sonho', eggman: 'cinza', 'metal-sonic': 'androide', silver: 'eon', optimus: 'engenho', bumblebee: 'recruta', ratchet: 'mecanica', megatron: 'colosso', starscream: 'falcao', soundwave: 'androide', arcee: 'cacadora', grimlock: 'dragao',
  // Pokémon
  pikachu: 'relampago', charizard: 'dragao', mewtwo: 'vigia', eevee: 'kitsune', lucario: 'ninja', greninja: 'ninja', gengar: 'fantasma', snorlax: 'brutus', bulbasaur: 'xeno', squirtle: 'mare', mew: 'eon', jigglypuff: 'sonho',
  // Additional Marvel and DC
  'green-arrow': 'arqueira', cyborg: 'androide', supergirl: 'sentinela', 'android-18': 'cacadora', krillin: 'aprendiz', 'master-roshi': 'mago', 'android-17': 'cacadora', 'ant-man': 'recruta', 'black-panther': 'simbionte', hawkeye: 'arqueira', storm: 'eon', 'captain-marvel': 'sentinela', ultron: 'androide', daredevil: 'ninja', 'moon-knight': 'ceifador'
};

export function svg(personagem, skin = 'base') {
  const chaveVisual = VISUAL_OFICIAL[personagem] || personagem;
  const v = VISUAL[chaveVisual] || VISUAL.cinza;
  let [roupa, detalhe] = v.roupa;
  let [estilo, corCabelo] = v.cabelo;
  let olho = v.olhos, aura = '';
  if (skin === 'neon') { roupa = '#16133a'; detalhe = '#22d3ee'; corCabelo = '#f472b6'; aura = COSTAS.aura('#22d3ee'); }
  if (skin === 'sombra') { roupa = '#1f1b2e'; detalhe = '#a855f7'; corCabelo = '#4c1d95'; olho = olho === 'unico' || olho === 'branco' ? olho : 'brilho:#f43f5e'; aura = COSTAS.aura('#7e22ce'); }
  const [tc, cc] = v.costas ?? [], [tt, ct] = v.topo ?? [], [ti, ci] = v.item ?? [];
  tintas = new Map();
  const larg = v.grande ? 10 : 0;
  const bota = mistura(roupa, '#0b0820', 0.55), sombraRoupa = mistura(roupa, '#0b0820', 0.4);
  const corpo = [
    haste('M50 118 V130 M70 118 V130', sombraRoupa, 10),
    espelho(forma('M40 130 Q50 123 57 129 L58 137 Q47 141 37 137Q37 133 40 130Z', bota) + traco('M41 136 Q48 138 55 136', detalhe, 2)),
    forma(`M${41 - larg} 91 Q60 80 ${79 + larg} 91 L${83 + larg / 2} 123 Q60 132 ${37 - larg / 2} 123Z`, roupa),
    traco(`M${45 - larg} 94 Q${41 - larg / 2} 108 ${42 - larg / 2} 120`, '#ffffff33', 3), traco('M60 100 V114', sombraRoupa, 1.5),
    haste(`M${40 - larg / 2} 115 Q60 122 ${80 + larg / 2} 115`, detalhe, 4.5), forma('M54 114 h12 v9 h-12Z', '#fbbf24'), ponto(60, 118.5, 2, O),
    haste(`M${41 - larg} 95 L${29 - larg} 111`, roupa, 9 + larg / 2), haste(`M${79 + larg} 95 L${92 + larg / 2} 108`, roupa, 9 + larg / 2),
    haste(`M${33 - larg} 105 l-3 4`, detalhe, 9 + larg / 2), haste(`M${88 + larg / 2} 104 l3 3`, detalhe, 9 + larg / 2),
    bola(28 - larg, 115, 7 + larg / 3, v.pele),
    v.emblema ? EMBLEMAS[v.emblema]() : forma('M48 87 L60 103 L72 87 Q60 83 48 87Z', detalhe) + ponto(60, 107, 2.2, detalhe),
    `<ellipse cx="60" cy="88" rx="27" ry="6" fill="${O}" opacity=".28"/>`,
  ].join('');
  const cabeca = [
    bola(60, 50, 39, v.pele, 37),
    espelho(`<ellipse cx="30" cy="69" rx="7" ry="4" fill="#fb7185" opacity=".45"/>`),
    `<ellipse cx="37" cy="29" rx="9" ry="5" fill="#fff" opacity=".3" transform="rotate(-30 37 29)"/>`,
    traco('M95 58 Q91 76 76 83', '#ffffff55', 2),
    olhos(olho, v.iris ?? mistura(v.roupa[0], '#7c4a21', v.roupa[0] === '#f8fafc' ? 1 : 0.35)),
    traco('M58 63 q2 2.5 4 0', mistura(v.pele, '#3b1d10', 0.4), 1.6), BOCAS[v.boca](),
    v.barba ? forma('M30 66 Q60 82 90 66 Q86 100 60 108 Q34 100 30 66Z', v.barba) + traco('M50 77 Q60 82 70 77', O, 2) : '',
    CABELO_FRENTE[estilo](corCabelo),
    estilo === 'careca' ? '' : traco('M33 26 Q42 17 55 17 M63 18 l5 .5', mistura(corCabelo, '#ffffff', 0.65), 3.5),
    tt ? TOPO[tt](skin === 'base' || ['elfo', 'orelhas'].includes(tt) ? ct : detalhe) : '',
  ].join('');
  const mao = bola(ti ? 95 : 93 + larg / 2, 111, 7 + larg / 3, v.pele);
  const figura = `${tc ? COSTAS[tc](skin === 'base' ? cc : detalhe) : ''}${CABELO_TRAS[estilo]?.(corCabelo) ?? ''}${corpo}${cabeca}${ti ? ITENS[ti](ci) : ''}${mao}`;
  const base = `<ellipse cx="60" cy="143" rx="46" ry="9" fill="#000" opacity=".35"/>`
    + forma('M18 136 V141 Q60 158 102 141 V136Z', mistura(detalhe, '#0b0820', 0.5)) + bola(60, 136, 42, mistura(detalhe, '#17102b', 0.25), 8)
    + `<ellipse cx="60" cy="136" rx="30" ry="4.5" fill="#000" opacity=".3"/>`;
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="-4 -10 128 164" width="256" height="328"><defs>${degrades()}</defs>
    ${aura}${base}${figura}</svg>`;
}
// imagem pronta (com cache) para as cartas e para o canvas da arena
const cache = new Map();
export function urlArte(personagem, skin) {
  const k = `${personagem}:${skin}`;
  if (!cache.has(k)) cache.set(k, `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg(personagem, skin))}`);
  return cache.get(k);
}
