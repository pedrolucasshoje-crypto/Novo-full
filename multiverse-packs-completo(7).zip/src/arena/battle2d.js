// Combate top-down compartilhado por História e Duelos: mesmo joystick e botões da Arena.
import { variante, PERSONAGENS, HABILIDADES } from '../data/characters.js';
import { urlArte } from '../ui/art.js';
import { estado, salvar } from '../systems/state.js';
import { ganhar } from '../systems/economy.js';
import { atributos, xpCarta } from '../systems/collection.js';
import { criarControles } from './input.js';
import { PODERES } from './abilities.js';

const aleatorio = (lista) => lista[Math.floor(Math.random() * lista.length)];

export function iniciarBatalha2D({ jogadorId, inimigoId, modo='boss', boss='', aliados=0, recompensa=0, xp=0, aoTerminar=()=>{} }) {
  const jogador = variante(jogadorId);
  const inimigo = PERSONAGENS.find(p => p.id === inimigoId) || PERSONAGENS.find(p => p.id === 'thanos');
  if (!jogador || !inimigo) { aoTerminar(false, true); return; }

  const pool = PERSONAGENS.filter(p => p.id !== inimigo.id && p.id !== jogador.personagem);
  const aliado = aliados ? aleatorio(pool) : null;
  const rival2 = aliados ? aleatorio(pool.filter(p => p.id !== aliado?.id)) : null;
  const poderes = jogador.habilidades.map(h => HABILIDADES[h]).filter(Boolean).slice(0, 2);
  const atributosJogador = atributos(jogadorId);
  const raiz = document.createElement('section');
  raiz.className = 'arena duelo2d';
  raiz.innerHTML = `<canvas></canvas><div class="zona"></div><div class="joy" style="pointer-events:none"><i></i></div>
    <div class="hud"><div class="barras">SUA VIDA<div class="barra vida"><i id="vida-p"></i></div>ENERGIA<div class="barra energia"><i id="energia-p"></i></div></div>
      <div class="info" id="duelo-info"></div><button class="pilula" id="sair-duelo" aria-label="Sair">✕</button></div>
    <div class="anuncio" id="duelo-msg"></div>
    <div class="acoes"><button class="atq" aria-label="Atacar">👊</button>${poderes.map((p,i)=>`<button class="p${i+1}" data-poder="${i}" aria-label="${p.nome}">${p.icone}<span></span></button>`).join('')}</div>`;
  document.body.append(raiz);
  const $ = s => raiz.querySelector(s);
  const canvas = $('canvas'), ctx = canvas.getContext('2d');
  let L=0,A=0,escala=1,quadro=0,ultimo=performance.now(),fim=false,tempoMsg=0,t=0,tremor=0;
  function ajustar(){const dpr=Math.min(devicePixelRatio||1,2);canvas.width=innerWidth*dpr;canvas.height=innerHeight*dpr;const e=Math.min(innerWidth,innerHeight)/480;escala=e*dpr;L=innerWidth/e;A=innerHeight/e;}
  ajustar(); addEventListener('resize',ajustar);
  const imagem=(id,skin='base')=>{const im=new Image();im.src=urlArte(id,skin);return im;};
  const spriteJogador=imagem(jogador.personagem,jogador.skin);
  const player={x:L*.28,y:A*.55,raio:18,vida:atributosJogador.vida,vidaMax:atributosJogador.vida,ataque:atributosJogador.ataque,vel:atributosJogador.velocidade,energia:100,recarga:[0,0],atq:0,inv:0,escudo:0,freeze:0,olhar:{x:1,y:0}};
  function criarInimigo(personagem,x,y,chefe=false,skin='base'){
    const img=imagem(personagem.id,skin);const escalaP=chefe?1.22:1;
    const hp=chefe?Math.max(2200,player.vidaMax*7):Math.max(180,player.vidaMax*1.65)*(modo==='duelo'?1.65:1);return {id:personagem.id,nome:personagem.nome,img,x,y,raio:chefe?25:18,vida:hp,vidaMax:hp,dano:chefe?32: (modo==='duelo'?21:16),vel:chefe?76:82,recarga:1.3,piscar:0,chefe,escalaP,phase:1,clones:0,clone:false};
  }
  const inimigos=[criarInimigo(inimigo,L*.72,A*.48,modo==='boss')];
  if(rival2) inimigos.push(criarInimigo(rival2,L*.82,A*.68));
  const companheiros=aliado?[{...criarInimigo(aliado,L*.18,A*.72),time:'player',vida:player.vidaMax*.65,vidaMax:player.vidaMax*.65,vel:85}]:[];
  const tiros=[],efeitos=[],perigos=[],itens=[];
  let cript=0,clonesFeitos=false,teleporteCd=2,dashCd=1.5,clonesMortos=0,invocacaoCd=3,esferasBills=0,esferaCd=4,estaloCd=13,estaloAviso=0,estaloAtivo=0,whisUsado=false,ouroTempo=0,ouroCd=9;
  const controles=criarControles(raiz,()=>{});
  const msg=s=>{ $('#duelo-msg').textContent=s;tempoMsg=2.2; };
  const limitar=o=>{o.x=Math.max(o.raio+8,Math.min(L-o.raio-8,o.x));o.y=Math.max(o.raio+75,Math.min(A-o.raio-12,o.y));};
  const alvoMaisProximo=(x,y,lista=inimigos)=>lista.filter(e=>e.vida>0).sort((a,b)=>Math.hypot(a.x-x,a.y-y)-Math.hypot(b.x-x,b.y-y))[0];
  function tiro(x,y,ang,dano,time='player',cor='#fbbf24',vel=360,raio=7){tiros.push({x,y,vx:Math.cos(ang)*vel,vy:Math.sin(ang)*vel,dano,time,cor,raio,vida:2});}
  function anel(x,y,r,cor='#fbbf24'){efeitos.push({x,y,r,cor,t:.45});}
  function ferir(e,dano){if(!e||e.vida<=0)return;e.vida-=dano;e.piscar=.12;anel(e.x,e.y,16,'#ffffff');if(e.vida<=0){e.vida=0;anel(e.x,e.y,35,'#fb7185');}}
  function danoPlayer(dano){if(player.inv>0||fim)return;if(player.escudo>0)dano*=.25;player.vida-=dano;player.inv=.55;tremor=.2;if(player.vida<=0){player.vida=0;terminar(false);}}
  function terminar(venceu,sair=false){if(fim)return;fim=true;controles.zerar();if(!sair){if(venceu){if(modo==='duelo'){const premio=aliados?25:15;ganhar(premio,25);msg(`VITÓRIA! +${premio} Coins`);}else{ganhar(recompensa,xp);xpCarta(jogadorId,xp);msg(`${modo==='boss'?'CHEFE':'INIMIGO'} DERROTADO! +${recompensa} Coins`);}}else if(modo==='duelo'){ganhar(3,5);msg('DERROTA · +3 Coins');}else msg('Você foi derrotado. Tente novamente.');}salvar();cancelAnimationFrame(quadro);setTimeout(()=>{limpar();aoTerminar(venceu,sair);},sair?0:1100);}
  function limpar(){controles.destruir();removeEventListener('resize',ajustar);raiz.remove();}
  $('#sair-duelo').onclick=()=>terminar(false,true);

  function habilidade(i){const h=poderes[i];if(!h||player.recarga[i]>0||player.energia<h.custo)return;player.energia-=h.custo;player.recarga[i]=h.recarga;
    const alvo=alvoMaisProximo(player.x,player.y);const ang=alvo?Math.atan2(alvo.y-player.y,alvo.x-player.x):Math.atan2(player.olhar.y,player.olhar.x);
    if(h.tipo==='projetil')tiro(player.x,player.y,ang,player.ataque*3,'player','#fbbf24',500,12);
    else if(h.tipo==='leque'){for(let k=-2;k<=2;k++)tiro(player.x,player.y,ang+k*.2,player.ataque*1.35,'player','#67e8f9',450,8);}
    else if(h.tipo==='area'){anel(player.x,player.y,130,'#c084fc');inimigos.forEach(e=>{if(Math.hypot(e.x-player.x,e.y-player.y)<130+e.raio)ferir(e,player.ataque*2.5);});}
    else if(h.tipo==='investida'){const dx=Math.cos(ang),dy=Math.sin(ang);player.x+=dx*125;player.y+=dy*125;limitar(player);player.inv=.5;inimigos.forEach(e=>{if(Math.hypot(e.x-player.x,e.y-player.y)<75)ferir(e,player.ataque*3);});anel(player.x,player.y,65,'#fbbf24');}
    else if(h.tipo==='defesa'){player.escudo=4;anel(player.x,player.y,48,'#67e8f9');}
    else if(h.tipo==='teletransporte'){player.x+=Math.cos(ang)*145;player.y+=Math.sin(ang)*145;limitar(player);player.inv=.7;anel(player.x,player.y,55,'#22d3ee');}
    else if(h.tipo==='especial'){inimigos.forEach(e=>ferir(e,player.ataque*4));anel(player.x,player.y,180,'#f97316');}
    else if(h.tipo==='cura'){player.vida=Math.min(player.vidaMax,player.vida+player.vidaMax*.3);anel(player.x,player.y,60,'#4ade80');}
  }
  function bossAI(dt,e){
    if(boss==='thanos'){
      if(estaloAviso>0){estaloAviso-=dt;if(estaloAviso<=0){estaloAtivo=0;danoPlayer(player.vidaMax*.5);msg('O estalo de Thanos apagou metade da sua vida!');}}else if((estaloCd-=dt)<=0){estaloCd=19;estaloAviso=2.4;estaloAtivo=1;msg('⚠️ THANOS PREPARA O ESTALO! FUJA!');}
      if((teleporteCd-=dt)<=0){e.x=L*(Math.random()<.5?.72:.88);e.y=A*(.25+Math.random()*.5);teleporteCd=4.2;msg('Thanos usou a Joia do Espaço!');}
      if(Math.random()<dt*.34){for(let i=0;i<3;i++){const x=60+Math.random()*(L-120),y=100+Math.random()*(A-150);perigos.push({x,y,r:38,t:1.35,kind:'meteor'});}msg('Meteoros chegando! Afaste-se das áreas marcadas!');}
      if(Math.random()<dt*.12){const x=aleatorio([70,L-70]),y=80+Math.random()*(A-160);perigos.push({x,y,r:25,t:1.1,kind:'laser'});}
      if((invocacaoCd-=dt)<=0&&inimigos.length<4){invocacaoCd=8;const extra=criarInimigo(PERSONAGENS.find(p=>p.id==='aldeao')||inimigo,L*.85,100+Math.random()*(A-180));extra.vida=extra.vidaMax=45;extra.nome='Criatura alienígena';inimigos.push(extra);msg('Thanos invocou criaturas alienígenas!');}
    }else if(boss==='superman-black'){
      if((teleporteCd-=dt)<=0){perigos.push({x:e.x,y:e.y,ang:Math.atan2(player.y-e.y,player.x-e.x),len:Math.max(L,A),t:1.15,kind:'beam'});teleporteCd=3.1;msg('Superman Black disparou o laser! Saia da linha!');}
      if((dashCd-=dt)<=0){const ang=Math.atan2(player.y-e.y,player.x-e.x);e.x+=Math.cos(ang)*130;e.y+=Math.sin(ang)*130;limitar(e);dashCd=2.8;msg('Superman Black avançou em alta velocidade!');}
      if((ouroCd-=dt)<=0&&!ouroTempo){ouroTempo=5.5;ouroCd=14;msg('⚠️ SUPERMAN BLACK ENTROU NO MODO DOURADO!');}
      if(ouroTempo>0){ouroTempo=Math.max(0,ouroTempo-dt);if(Math.random()<dt*.55){const x=player.x+(Math.random()-.5)*130,y=player.y+(Math.random()-.5)*130;perigos.push({x,y,r:42,t:1.05,kind:'gold'});}if(Math.random()<dt*.4){const ang=Math.atan2(player.y-e.y,player.x-e.x);tiro(e.x,e.y,ang,player.vidaMax*.28,'enemy','#facc15',330,11);}}
      if(Math.random()<dt*.11)perigos.push({x:60+Math.random()*(L-120),y:90+Math.random()*(A-180),r:48,t:1.5,kind:'ice'});
      if(!cript&&Math.random()<dt*.035)itens.push({x:70+Math.random()*(L-140),y:100+Math.random()*(A-190),t:12,kind:'kryptonite'});
    }else if(boss==='beerus'){
      if(esferasBills>=7&&e.phase===1&&e.vida<e.vidaMax*.5){e.phase=2;e.vida=e.vidaMax*.5;msg('Bills voltou com aura roxa! Segunda fase!');}
      if(Math.random()<dt*.12)perigos.push({x:player.x,y:player.y,r:105,t:3,kind:'purple'});
      if(esferasBills<7&&(esferaCd-=dt)<=0){esferaCd=6.5;itens.push({x:70+Math.random()*(L-140),y:100+Math.random()*(A-190),t:18,kind:'dragonball'});msg(`Esfera do Dragão apareceu! ${esferasBills}/7`);}
      if(e.phase===1&&!clonesFeitos&&Math.random()<dt*.04){clonesFeitos=true;e.clones=3;msg('Bills se dividiu em quatro! Acerte as cópias para quebrar a ilusão!');}
      if(e.phase===2&&Math.random()<dt*.16){const ang=Math.atan2(player.y-e.y,player.x-e.x);for(let k=-1;k<=1;k++)tiro(e.x,e.y,ang+k*.18,player.vidaMax*.24,'enemy','#a855f7',260,10);}
    }
  }
  function atualizar(dt){t+=dt;player.energia=Math.min(100,player.energia+12*dt);player.atq-=dt;player.inv-=dt;player.escudo-=dt;player.freeze=Math.max(0,player.freeze-dt);player.recarga=player.recarga.map(x=>Math.max(0,x-dt));tremor-=dt;
    const c=controles.ler();if(c.x||c.y){const d=Math.hypot(c.x,c.y);player.olhar={x:c.x/d,y:c.y/d};}
    if(player.freeze<=0){player.x+=c.x*player.vel*dt;player.y+=c.y*player.vel*dt;}limitar(player);
    if(c.atacar&&player.atq<=0){player.atq=.28;const e=alvoMaisProximo(player.x,player.y);const ang=e?Math.atan2(e.y-player.y,e.x-player.x):Math.atan2(player.olhar.y,player.olhar.x);tiro(player.x,player.y,ang,player.ataque,'player','#fbbf24',470,7);}
    c.poderes.forEach(habilidade);
    if(modo==='boss')inimigos.filter(e=>e.chefe).forEach(e=>bossAI(dt,e));
    for(const e of inimigos){if(e.vida<=0)continue;const dx=player.x-e.x,dy=player.y-e.y,d=Math.hypot(dx,dy)||1;const manterDistancia=e.id==='black-superman'?Math.max(0,d-105):Math.max(0,d-35);const velocidade=e.vel*(e.phase===2?1.45:1)*(boss==='superman-black'&&ouroTempo>0?2.15:1);e.x+=dx/d*velocidade*dt*(manterDistancia?1:0);e.y+=dy/d*velocidade*dt*(manterDistancia?1:0);limitar(e);e.piscar-=dt;
      if(d<e.raio+player.raio+3&&player.inv<=0)danoPlayer(e.dano);
      if((e.recarga-=dt)<=0&&d<Math.max(L,A)*.85){e.recarga=e.chefe?1.55:2.1;const ang=Math.atan2(dy,dx);tiro(e.x,e.y,ang,e.dano*.8,'enemy',e.chefe?'#fb7185':'#f97316',e.chefe?235:190,7);}
    }
    for(const a of companheiros){if(a.vida<=0)continue;const e=alvoMaisProximo(a.x,a.y);if(e){const dx=e.x-a.x,dy=e.y-a.y,d=Math.hypot(dx,dy)||1;a.x+=dx/d*a.vel*dt;a.y+=dy/d*a.vel*dt;if(Math.random()<dt*.8)tiro(a.x,a.y,Math.atan2(dy,dx),9,'player','#34d399',330,6);}}
    for(const h of perigos){h.t-=dt;if(h.kind==='purple'&&h.t<.8)msg('PERIGO ROXO! FUJA AGORA!');if(h.kind==='gold'&&h.t<.5)msg('Rajada dourada vai explodir!');if(h.t<=0){if(h.kind==='meteor'||h.kind==='ice'||h.kind==='laser'){if(Math.hypot(player.x-h.x,player.y-h.y)<h.r+player.raio){if(h.kind==='ice'){player.freeze=2;msg('Congelado por 2 segundos!');}else danoPlayer(h.kind==='meteor'?24:30);}}else if(h.kind==='beam'){const px=player.x-h.x,py=player.y-h.y;const dist=Math.abs(px*Math.sin(h.ang)-py*Math.cos(h.ang));if(dist<24)danoPlayer(32);}else if(h.kind==='purple'&&Math.hypot(player.x-h.x,player.y-h.y)<h.r+player.raio)danoPlayer(player.vidaMax*2);else if(h.kind==='gold'&&Math.hypot(player.x-h.x,player.y-h.y)<h.r+player.raio)danoPlayer(40);}}
    for(const it of itens){it.t-=dt;if(Math.hypot(player.x-it.x,player.y-it.y)<player.raio+20&&it.kind==='kryptonite'){it.t=0;cript=1;msg('Criptonita coletada! Agora seus ataques podem ferir Superman Black!');}else if(Math.hypot(player.x-it.x,player.y-it.y)<player.raio+20&&it.kind==='dragonball'){it.t=0;esferasBills++;msg(`Esfera coletada! ${esferasBills}/7`);if(boss==='beerus'&&esferasBills===3&&!whisUsado){whisUsado=true;esferasBills=0;esferaCd=1.2;msg('✨ WHIS APARECE! O TEMPO VOLTA — você perdeu as 3 esferas!');efeitos.push({x:L*.7,y:A*.5,r:220,cor:'#67e8f9',t:1.5});}}}
    for(const s of tiros){s.x+=s.vx*dt;s.y+=s.vy*dt;s.vida-=dt;if(s.time==='player'){for(const e of inimigos){if(e.vida>0&&Math.hypot(e.x-s.x,e.y-s.y)<e.raio+s.raio){if(boss==='beerus'&&e.chefe&&e.clones>0){e.clones--;clonesMortos++;if(e.clones===0){ferir(e,player.ataque*3);msg('Cópias derrotadas! Bills está vulnerável!');}}else if(boss==='superman-black'&&e.chefe){if(cript){ferir(e,s.dano*(ouroTempo>0?18:12));cript=0;msg('Ataque energizado pela criptonita!');}else msg('Superman Black é invulnerável! Pegue a criptonita para causar dano!');}else if(boss==='beerus'&&e.chefe&&esferasBills<7){msg(`Bills protegido pelas esferas! ${esferasBills}/7 coletadas.`);}else ferir(e,s.dano);s.vida=0;break;}}}else if(Math.hypot(player.x-s.x,player.y-s.y)<player.raio+s.raio){danoPlayer(s.dano);s.vida=0;}}
    for(let i=perigos.length-1;i>=0;i--)if(perigos[i].t<=0)perigos.splice(i,1);
    for(let i=itens.length-1;i>=0;i--)if(itens[i].t<=0)itens.splice(i,1);
    for(let i=tiros.length-1;i>=0;i--)if(tiros[i].vida<=0||tiros[i].x<0||tiros[i].y<0||tiros[i].x>L||tiros[i].y>A)tiros.splice(i,1);
    for(let i=efeitos.length-1;i>=0;i--){efeitos[i].t-=dt;if(efeitos[i].t<=0)efeitos.splice(i,1);}
    if(inimigos.every(e=>e.vida<=0))terminar(true);
    if(tempoMsg>0){tempoMsg-=dt;if(tempoMsg<=0)$('#duelo-msg').textContent='';}
  }
  function circulo(x,y,r,cor,linha=0){ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);if(linha){ctx.strokeStyle=cor;ctx.lineWidth=linha;ctx.stroke();}else{ctx.fillStyle=cor;ctx.fill();}}
  function desenharPersonagem(img,o,cor='#fff',alpha=1){ctx.save();ctx.globalAlpha=alpha;if(o.piscar>0)ctx.globalAlpha=.45;ctx.beginPath();ctx.ellipse(o.x,o.y+15,24,9,0,0,Math.PI*2);ctx.fillStyle=cor+'55';ctx.fill();ctx.strokeStyle=cor;ctx.lineWidth=2;ctx.stroke();if(img?.complete&&img.naturalWidth)ctx.drawImage(img,o.x-31,o.y-54,62,72);else{ctx.fillStyle=cor;ctx.fillRect(o.x-15,o.y-25,30,40);}ctx.restore();}
  function desenhar(){ctx.setTransform(escala,0,0,escala,0,0);ctx.clearRect(0,0,L,A);
    if(boss==='thanos'){ctx.fillStyle='#1b1028';ctx.fillRect(0,0,L,A);for(let i=0;i<36;i++){ctx.fillStyle='#c084fc55';ctx.fillRect((i*83+t*8)%L,(i*47)%A,2,2);}ctx.fillStyle='#653b76';ctx.beginPath();ctx.arc(L*.78,A*.25,Math.min(L,A)*.17,0,Math.PI*2);ctx.fill();ctx.fillStyle='#3d294e';ctx.fillRect(0,A*.72,L,A*.28);}
    else if(boss==='superman-black'){ctx.fillStyle='#182235';ctx.fillRect(0,0,L,A);ctx.fillStyle='#26344b';for(let i=0;i<10;i++){const x=i*L/9;ctx.fillRect(x,A*.25, L/12,A*.5);ctx.fillStyle='#e0b35a33';for(let j=0;j<4;j++)ctx.fillRect(x+8,A*.3+j*35,8,15);ctx.fillStyle='#26344b';}if(ouroTempo>0){ctx.fillStyle='#facc1530';ctx.fillRect(0,0,L,A);}}
    else if(boss==='beerus'){ctx.fillStyle='#09051c';ctx.fillRect(0,0,L,A);ctx.fillStyle='#ddd5ff';for(let i=0;i<45;i++)ctx.fillRect((i*73)%L,(i*41)%A,2,2);ctx.fillStyle='#d8d8ee';ctx.beginPath();ctx.arc(L*.22,A*.23,Math.min(L,A)*.1,0,Math.PI*2);ctx.fill();ctx.fillStyle='#43346b';ctx.beginPath();ctx.arc(L*.78,A*.3,Math.min(L,A)*.16,0,Math.PI*2);ctx.fill();}
    else {ctx.fillStyle='#090d20';ctx.fillRect(0,0,L,A);}ctx.strokeStyle='#1b2248';ctx.lineWidth=1;ctx.beginPath();for(let x=0;x<L;x+=48){ctx.moveTo(x,0);ctx.lineTo(x,A);}for(let y=0;y<A;y+=48){ctx.moveTo(0,y);ctx.lineTo(L,y);}ctx.stroke();
    for(const h of perigos){ctx.globalAlpha=.25+Math.sin(t*12)*.08;ctx.fillStyle=h.kind==='purple'?'#a855f7':h.kind==='gold'?'#facc15':h.kind==='ice'?'#67e8f9':h.kind==='beam'?'#ef4444':'#f97316';if(h.kind==='beam'){ctx.save();ctx.translate(h.x,h.y);ctx.rotate(h.ang);ctx.fillRect(0,-13,Math.max(L,A),26);ctx.restore();}else circulo(h.x,h.y,h.r,h.kind==='purple'?'#a855f7':ctx.fillStyle,3);if(h.kind==='gold'){ctx.globalAlpha=.4;circulo(h.x,h.y,h.r,'#facc15',5);ctx.globalAlpha=1;}ctx.globalAlpha=1;}
    for(const it of itens){ctx.fillStyle=it.kind==='dragonball'?'#f59e0b':'#84cc16';ctx.shadowColor=ctx.fillStyle;ctx.shadowBlur=18;ctx.beginPath();ctx.arc(it.x,it.y,12,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0;ctx.fillStyle='#fff';ctx.font='11px system-ui';ctx.fillText(it.kind==='dragonball'?'★':'K',it.x-4,it.y+4);}
    inimigos.forEach(e=>{if(e.vida<=0)return;const im=e.id===inimigo.id?imagemCache.get(e.id):imagemCache.get(e.id);desenharPersonagem(im||e.img,e,e.chefe?'#fb7185':'#f97316');ctx.fillStyle='#000b';ctx.fillRect(e.x-e.raio,e.y-e.raio-12,e.raio*2,5);ctx.fillStyle='#ef4444';ctx.fillRect(e.x-e.raio,e.y-e.raio-12,e.raio*2*Math.max(0,e.vida/e.vidaMax),5);if(e.clones>0){for(let k=0;k<e.clones;k++){const ang=k*Math.PI*2/Math.max(1,e.clones);const cx=e.x+Math.cos(ang)*85,cy=e.y+Math.sin(ang)*65;desenharPersonagem(e.img,{x:cx,y:cy,piscar:0},'#a855f7',.55);}}});
    companheiros.forEach(a=>{if(a.vida>0)desenharPersonagem(a.img,a,'#34d399',.85);});
    ctx.globalAlpha=player.inv>0&&Math.floor(player.inv*16)%2?.4:1;desenharPersonagem(spriteJogador,player,'#67e8f9');ctx.globalAlpha=1;if(player.escudo>0)circulo(player.x,player.y,player.raio+22,'#67e8f9',4);
    tiros.forEach(s=>circulo(s.x,s.y,s.raio,s.cor));efeitos.forEach(f=>{ctx.globalAlpha=f.t/.45;circulo(f.x,f.y,f.r*(1-f.t/.45),f.cor,4);ctx.globalAlpha=1;});
    $('#vida-p').style.width=`${Math.max(0,player.vida/player.vidaMax*100)}%`;$('#energia-p').style.width=`${player.energia}%`;const principal=inimigos.find(e=>e.chefe)||inimigos[0];$('#duelo-info').innerHTML=`<b>${modo==='boss'?'CHEFE':'DUELO '+(aliados?'2v2':'1v1')}</b><br>${principal?.nome||'Inimigo'} · ${Math.ceil(principal?.vida||0)} HP${boss==='beerus'&&modo==='boss'?`<br>🔮 ${esferasBills}/7${whisUsado?' · Whis já voltou no tempo':''}`:''}${boss==='superman-black'&&ouroTempo>0?'<br>✨ MODO DOURADO':''}${boss==='thanos'&&estaloAviso>0?'<br>⚠️ ESTALO EM BREVE':''}`;
    raiz.querySelectorAll('[data-poder]').forEach((b,i)=>{b.lastElementChild.textContent=player.recarga[i]>0?Math.ceil(player.recarga[i]):'';b.style.opacity=player.energia<poderes[i].custo?.45:1;});
  }
  const imagemCache=new Map();imagemCache.set(inimigo.id,inimigos[0].img);inimigos.slice(1).forEach(e=>imagemCache.set(e.id,e.img));
  function loop(agora){if(fim)return;const dt=Math.min(.05,Math.max(0,(agora-ultimo)/1000));ultimo=agora;atualizar(dt);desenhar();quadro=requestAnimationFrame(loop);}
  msg(modo==='boss'?'Prepare-se para o chefe!':modo==='story-mob'?'Inimigo à vista!':'Batalha iniciada!');quadro=requestAnimationFrame(loop);
}

export function escolherAdversario(excluir){return aleatorio(PERSONAGENS.filter(p=>p.id!==excluir));}
