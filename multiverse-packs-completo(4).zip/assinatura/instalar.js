// Instala a chave de debug no ambiente CI (compatível com package.json type=module).
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { fileURLToPath } from 'node:url';
const aqui = path.dirname(fileURLToPath(import.meta.url));
if (process.env.CI) {
  const pasta = path.join(os.homedir(), '.android');
  fs.mkdirSync(pasta, { recursive: true });
  fs.copyFileSync(path.join(aqui, 'debug.keystore'), path.join(pasta, 'debug.keystore'));
  console.log('Chave de assinatura de debug instalada');
}
