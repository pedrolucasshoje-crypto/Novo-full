// Efeitos sonoros sintetizados localmente: não depende de internet nem de arquivos externos.
let contexto;
let volume = Number(localStorage.getItem('mv_volume') ?? 0.35);
let ativo = localStorage.getItem('mv_som') !== 'off';

function audio() {
  const AC = window.AudioContext || window.webkitAudioContext;
  if (!AC) return null;
  if (!contexto) contexto = new AC();
  if (contexto.state === 'suspended') contexto.resume().catch(() => {});
  return contexto;
}

export function somAtivo() { return ativo; }
export function volumeSom() { return volume; }
export function definirVolume(valor) {
  volume = Math.max(0, Math.min(1, Number(valor) || 0));
  localStorage.setItem('mv_volume', String(volume));
}
export function alternarSom() {
  ativo = !ativo;
  localStorage.setItem('mv_som', ativo ? 'on' : 'off');
  if (ativo) audio();
  return ativo;
}

function tom(freq, duracao, forma = 'sine', fim = freq * 0.65, atraso = 0) {
  if (!ativo || volume <= 0) return;
  const a = audio(); if (!a) return;
  const inicio = a.currentTime + atraso;
  const osc = a.createOscillator(), ganho = a.createGain();
  osc.type = forma; osc.frequency.setValueAtTime(freq, inicio);
  osc.frequency.exponentialRampToValueAtTime(Math.max(25, fim), inicio + duracao);
  ganho.gain.setValueAtTime(0.0001, inicio);
  ganho.gain.exponentialRampToValueAtTime(Math.max(0.0002, volume * 0.22), inicio + 0.012);
  ganho.gain.exponentialRampToValueAtTime(0.0001, inicio + duracao);
  osc.connect(ganho); ganho.connect(a.destination);
  osc.start(inicio); osc.stop(inicio + duracao + 0.02);
}

function ruido(duracao = 0.12, corte = 900) {
  if (!ativo || volume <= 0) return;
  const a = audio(); if (!a) return;
  const tamanho = Math.max(1, Math.floor(a.sampleRate * duracao));
  const buffer = a.createBuffer(1, tamanho, a.sampleRate), dados = buffer.getChannelData(0);
  for (let i = 0; i < tamanho; i++) dados[i] = (Math.random() * 2 - 1) * (1 - i / tamanho);
  const fonte = a.createBufferSource(), filtro = a.createBiquadFilter(), ganho = a.createGain();
  fonte.buffer = buffer; filtro.type = 'lowpass'; filtro.frequency.value = corte;
  ganho.gain.value = volume * 0.28;
  fonte.connect(filtro); filtro.connect(ganho); ganho.connect(a.destination); fonte.start();
}

export const som = {
  ataque() { tom(240, 0.09, 'triangle', 95); },
  disparo() { tom(520, 0.07, 'square', 180); },
  impacto() { ruido(0.09, 700); tom(105, 0.12, 'sawtooth', 48); },
  abate() { tom(360, 0.1, 'triangle', 110); tom(620, 0.13, 'sine', 250, 0.06); },
  dano() { tom(150, 0.2, 'sawtooth', 55); ruido(0.1, 500); },
  poder() { tom(280, 0.22, 'sawtooth', 850); tom(620, 0.18, 'sine', 1200, 0.07); },
  explosao() { ruido(0.28, 420); tom(90, 0.3, 'sawtooth', 35); },
  chefe() { tom(110, 0.45, 'sawtooth', 48); tom(165, 0.38, 'triangle', 70, 0.18); },
  onda() { tom(440, 0.12, 'sine', 660); tom(660, 0.16, 'sine', 880, 0.12); },
  vitoria() { [523, 659, 784].forEach((f, i) => tom(f, 0.24, 'sine', f, i * 0.13)); },
  derrota() { tom(260, 0.35, 'triangle', 95); tom(180, 0.45, 'sawtooth', 55, 0.2); },
};
