// Comportamento de cada tipo de poder. "j" é a partida.
export const PODERES = {
  projetil: (j) => j.atirar(j.mira(), j.p.ataque * 3, { raio: 13, perfura: true, cor: '#fbbf24' }),
  leque: (j) => { for (let i = -3; i <= 3; i++) j.atirar(j.mira() + i * 0.18, j.p.ataque * 1.3, { cor: '#6ee7ff' }); },
  area: (j) => { j.explodir(j.p.x, j.p.y, 150, j.p.ataque * 2.6, '#c084fc'); },
  investida: (j) => { const m = j.direcao(); j.p.investida = { t: 0.22, x: m.x, y: m.y, acertados: new Set() }; j.p.invencivel = 0.4; },
  defesa: (j) => { j.p.escudo = 4; },
  teletransporte: (j) => {
    const m = j.direcao();
    j.explodir(j.p.x, j.p.y, 80, j.p.ataque, '#22d3ee');
    j.p.x += m.x * 200; j.p.y += m.y * 200; j.limitar(j.p); j.p.invencivel = 0.6;
    j.explodir(j.p.x, j.p.y, 80, j.p.ataque, '#22d3ee');
  },
  especial: (j) => {
    for (const e of [...j.inimigos]) j.explodir(e.x, e.y, 30, 0, '#f97316');
    for (const e of [...j.inimigos]) j.ferir(e, j.p.ataque * 5);
    j.tremor = 0.5;
  },
  cura: (j) => { j.p.vida = Math.min(j.p.vidaMax, j.p.vida + j.p.vidaMax * 0.35); j.anel(j.p.x, j.p.y, 70, '#4ade80'); },
};
