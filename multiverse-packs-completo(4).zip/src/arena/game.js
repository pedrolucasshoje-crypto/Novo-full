// A partida: loop, física, colisões, desenho e recompensas
import { variante, HABILIDADES } from '../data/characters.js';
import { raridade } from '../data/rarities.js';
import { estado, salvar } from '../systems/state.js';
import { atributos, xpCarta } from '../systems/collection.js';
import { ganhar } from '../systems/economy.js';
import { atualizarPeriodos } from '../systems/missions.js';
import { multiplicadorArena } from '../systems/events.js';
import { vibrar } from '../ui/feedback.js';
import { urlArte } from '../ui/art.js';
import { criarControles } from './input.js';
import { INIMIGOS, ULTIMA_ONDA, montarOnda, forca } from './enemies.js';
import { PODERES } from './abilities.js';
import { som, somAtivo, alternarSom, volumeSom, definirVolume } from '../audio/sounds.js';

export function criarPartida(id, aoSair) {
  atualizarPeriodos();
  const v = variante(id), a = atributos(id);
  const poderes = v.habilidades.map((h) => HABILIDADES[h]);
  const boneco = new Image(); boneco.src = urlArte(v.personagem, v.skin);
  const raiz = document.createElement('div');
  raiz.className = 'arena';
  raiz.innerHTML = `<canvas></canvas><div class="zona"></div><div class="joy" style="pointer-events:none"><i></i></div>
    <div class="hud"><div class="barras">VIDA<div class="barra vida"><i></i></div>ENERGIA<div class="barra energia"><i></i></div></div>
      <div class="info"></div><button class="pilula" id="som" aria-label="Ativar ou desativar sons">🔊</button><button class="pilula" id="pausa" aria-label="Pausar">⏸</button></div>
    <div class="anuncio"></div>
    <div class="acoes"><button class="atq" aria-label="Atacar">👊</button>${poderes.map((p, i) => `<button class="p${i + 1}" data-poder="${i}" aria-label="${p.nome}">${p.icone}<span></span></button>`).join('')}</div>`;
  document.body.append(raiz);
  const $ = (s) => raiz.querySelector(s);
  const canvas = $('canvas'), ctx = canvas.getContext('2d');

  let L = 0, A = 0, escala = 1;
  function ajustar() {
    const dpr = Math.min(devicePixelRatio || 1, 2);
    canvas.width = innerWidth * dpr; canvas.height = innerHeight * dpr;
    // a menor dimensão da tela sempre mostra 480 unidades do mundo
    const e = Math.min(innerWidth, innerHeight) / 480;
    escala = e * dpr; L = innerWidth / e; A = innerHeight / e;
  }
  addEventListener('resize', ajustar); ajustar();

  const j = {
    p: { x: L / 2, y: A / 2, raio: 18, vida: a.vida, vidaMax: a.vida, ataque: a.ataque, energia: 100, recarga: [0, 0], atq: 0, escudo: 0, invencivel: 0, olhar: { x: 0, y: -1 }, investida: null },
    inimigos: [], tiros: [], efeitos: [], aSurgir: [], onda: 0, tremor: 0, espera: 1.2, tempoSurgir: 0,
    ganhos: { moedas: 0, xp: 0 }, fim: false,
    limitar(o) { o.x = Math.max(o.raio, Math.min(L - o.raio, o.x)); o.y = Math.max(o.raio + 70, Math.min(A - o.raio, o.y)); },
    maisProximo() { let m, d = Infinity; for (const e of j.inimigos) { const n = Math.hypot(e.x - j.p.x, e.y - j.p.y); if (n < d) { d = n; m = e; } } return m; },
    mira() { const m = j.maisProximo(); return m ? Math.atan2(m.y - j.p.y, m.x - j.p.x) : Math.atan2(j.p.olhar.y, j.p.olhar.x); },
    direcao() { return j.p.olhar; },
    atirar(ang, dano, o = {}) { j.tiros.push({ x: j.p.x, y: j.p.y, vx: Math.cos(ang) * 460, vy: Math.sin(ang) * 460, raio: o.raio ?? 7, dano, meu: true, perfura: o.perfura, cor: o.cor ?? raridade(v.raridade).cor, vida: 1.6, acertados: new Set() }); },
    anel(x, y, r, cor) { j.efeitos.push({ x, y, r, cor, t: 0.4 }); },
    explodir(x, y, r, dano, cor) { j.anel(x, y, r, cor); if (dano) for (const e of [...j.inimigos]) if (Math.hypot(e.x - x, e.y - y) < r + e.raio) j.ferir(e, dano); },
    ferir(e, dano) {
      if (e.morto) return;
      e.vida -= dano; e.piscar = 0.1; som.impacto();
      if (e.vida > 0) return;
      e.morto = true; som.abate(); j.inimigos.splice(j.inimigos.indexOf(e), 1);
      j.anel(e.x, e.y, e.raio * 2, '#ffffff');
      estado.totais.abates++; j.ganhos.moedas += e.moedas;
      premiar(e.moedas, 2);
      if (e.chefe) estado.totais.chefes++;
    },
  };
  // recompensas entram na hora; o save acontece ao fim de cada onda e ao sair
  function premiar(moedas, xp) { const m = multiplicadorArena(); ganhar(moedas * m, xp * m); xpCarta(id, xp * m); }
  function machucar(dano) {
    if (j.p.invencivel > 0 || j.fim) return;
    if (j.p.escudo > 0) { dano *= 0.2; }
    j.p.vida -= dano; som.dano(); j.p.invencivel = 0.5; j.tremor = 0.2; vibrar(30);
    if (j.p.vida <= 0) { j.p.vida = 0; terminar(false); }
  }
  let relogioAnuncio = 0;
  function anunciar(t) { $('.anuncio').textContent = t; relogioAnuncio = 1.6; }
  function novaOnda() {
    j.onda++; j.aSurgir = montarOnda(j.onda); j.tempoSurgir = 0;
    const temChefe = j.aSurgir.includes('chefe'); anunciar(temChefe ? `⚠️ CHEFE · Onda ${j.onda}` : j.aSurgir.includes('mini') ? `Mini-chefe · Onda ${j.onda}` : `Onda ${j.onda}`); temChefe ? som.chefe() : som.onda();
  }
  function surgir(tipo) {
    const b = INIMIGOS[tipo], f = forca(j.onda), lado = Math.floor(Math.random() * 4);
    const e = { ...b, vida: b.vida * f, vidaMax: b.vida * f, dano: b.dano * f, recarga: 1.5, piscar: 0,
      x: lado < 2 ? Math.random() * L : lado === 2 ? 0 : L, y: lado > 1 ? Math.random() * A : lado === 0 ? 0 : A };
    j.limitar(e); // nunca nasce em cima do jogador
    if (Math.hypot(e.x - j.p.x, e.y - j.p.y) < 150) { e.x = j.p.x < L / 2 ? L - e.raio : e.raio; e.y = j.p.y < A / 2 ? A - e.raio : 80; }
    j.inimigos.push(e);
  }
  function completarOnda() {
    const premio = 5;
    j.ganhos.moedas += premio; premiar(premio, 15 + j.onda * 3);
    estado.totais.ondas++; estado.melhorOnda = Math.max(estado.melhorOnda, j.onda);
    salvar();
    if (j.onda >= ULTIMA_ONDA) return terminar(true);
    j.p.vida = Math.min(j.p.vidaMax, j.p.vida + j.p.vidaMax * 0.2);
    anunciar(`Onda completa! +${premio * multiplicadorArena()} 🪙`); j.espera = 2;
  }

  function atualizar(dt) {
    const c = controles.ler(), p = j.p;
    p.energia = Math.min(100, p.energia + 12 * dt);
    p.atq -= dt; p.escudo -= dt; p.invencivel -= dt; j.tremor -= dt;
    p.recarga = p.recarga.map((r) => Math.max(0, r - dt));
    if (c.x || c.y) { const d = Math.hypot(c.x, c.y); p.olhar = { x: c.x / d, y: c.y / d }; }
    if (p.investida) {
      p.x += p.investida.x * 850 * dt; p.y += p.investida.y * 850 * dt;
      for (const e of [...j.inimigos]) if (!p.investida.acertados.has(e) && Math.hypot(e.x - p.x, e.y - p.y) < e.raio + 40) { p.investida.acertados.add(e); j.ferir(e, p.ataque * 3); }
      j.anel(p.x, p.y, 20, '#fbbf24');
      if ((p.investida.t -= dt) <= 0) p.investida = null;
    } else { p.x += c.x * a.velocidade * dt; p.y += c.y * a.velocidade * dt; }
    j.limitar(p);
    if (c.atacar && p.atq <= 0) { p.atq = 0.28; som.ataque(); j.atirar(j.mira(), p.ataque); }
    for (const i of c.poderes) {
      const h = poderes[i];
      if (p.recarga[i] > 0 || p.energia < h.custo) continue;
      p.energia -= h.custo; p.recarga[i] = h.recarga; som.poder(); PODERES[h.tipo](j);
    }
    if (j.aSurgir.length) { if ((j.tempoSurgir -= dt) <= 0) { surgir(j.aSurgir.shift()); j.tempoSurgir = Math.max(0.25, 0.8 - j.onda * 0.05); } }
    else if (!j.inimigos.length) {
      if (j.espera > 0) { if ((j.espera -= dt) <= 0) novaOnda(); }
      else completarOnda();
    }
    if (j.fim) return;
    for (const e of j.inimigos) {
      const dx = p.x - e.x, dy = p.y - e.y, d = Math.hypot(dx, dy) || 1;
      const sentido = e.tiro && !e.leque && d < 190 ? -0.4 : 1; // atirador mantém distância
      e.x += (dx / d) * e.vel * sentido * dt; e.y += (dy / d) * e.vel * sentido * dt;
      j.limitar(e); e.piscar -= dt;
      if (d < e.raio + p.raio) machucar(e.dano);
      if (e.tiro && (e.recarga -= dt) <= 0) {
        e.recarga = e.tiro; som.disparo();
        const base = Math.atan2(dy, dx), n = e.leque ?? 1;
        for (let k = 0; k < n; k++) {
          const ang = e.chefe ? base + (k / n) * Math.PI * 2 : base + (k - (n - 1) / 2) * 0.25;
          j.tiros.push({ x: e.x, y: e.y, vx: Math.cos(ang) * 200, vy: Math.sin(ang) * 200, raio: 7, dano: e.dano * 0.8, meu: false, cor: '#fb7185', vida: 5 });
        }
      }
    }
    // empurra inimigos para não ficarem empilhados
    for (let i = 0; i < j.inimigos.length; i++) for (let k = i + 1; k < j.inimigos.length; k++) {
      const m = j.inimigos[i], n = j.inimigos[k], dx = n.x - m.x, dy = n.y - m.y, d = Math.hypot(dx, dy) || 1, s = m.raio + n.raio - d;
      if (s > 0) { m.x -= dx / d * s / 2; m.y -= dy / d * s / 2; n.x += dx / d * s / 2; n.y += dy / d * s / 2; }
    }
    for (const t of j.tiros) {
      t.x += t.vx * dt; t.y += t.vy * dt; t.vida -= dt;
      if (t.meu) {
        for (const e of [...j.inimigos]) if (t.vida > 0 && !t.acertados.has(e) && Math.hypot(e.x - t.x, e.y - t.y) < e.raio + t.raio) { t.acertados.add(e); j.ferir(e, t.dano); if (!t.perfura) t.vida = 0; }
      } else if (Math.hypot(p.x - t.x, p.y - t.y) < p.raio + t.raio) { t.vida = 0; machucar(t.dano); }
    }
    j.tiros = j.tiros.filter((t) => t.vida > 0 && t.x > -30 && t.y > -30 && t.x < L + 30 && t.y < A + 30);
  }

  function emoji(txt, x, y, tam) { ctx.font = `${tam}px system-ui`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#fff'; ctx.fillText(txt, x, y); }
  function circulo(x, y, r, cor, linha) { ctx.beginPath(); ctx.arc(x, y, r, 0, 7); if (linha) { ctx.strokeStyle = cor; ctx.lineWidth = linha; ctx.stroke(); } else { ctx.fillStyle = cor; ctx.fill(); } }
  function desenhar() {
    ctx.setTransform(escala, 0, 0, escala, 0, 0);
    ctx.clearRect(0, 0, L, A);
    if (j.tremor > 0) ctx.translate((Math.random() - .5) * 8, (Math.random() - .5) * 8);
    ctx.strokeStyle = '#1b2248'; ctx.lineWidth = 1; ctx.beginPath();
    for (let x = 0; x < L; x += 48) { ctx.moveTo(x, 0); ctx.lineTo(x, A); }
    for (let y = 0; y < A; y += 48) { ctx.moveTo(0, y); ctx.lineTo(L, y); }
    ctx.stroke();
    for (const e of j.inimigos) {
      circulo(e.x, e.y, e.raio, e.piscar > 0 ? '#ffffffaa' : '#ef444433');
      emoji(e.emoji, e.x, e.y, e.raio * 1.6);
      ctx.fillStyle = '#000a'; ctx.fillRect(e.x - e.raio, e.y - e.raio - 9, e.raio * 2, 5);
      ctx.fillStyle = '#ef4444'; ctx.fillRect(e.x - e.raio, e.y - e.raio - 9, e.raio * 2 * Math.max(0, e.vida / e.vidaMax), 5);
    }
    const p = j.p;
    ctx.beginPath(); ctx.ellipse(p.x, p.y + 17, 25, 10, 0, 0, 7); ctx.fillStyle = raridade(v.raridade).cor + '55'; ctx.fill();
    ctx.strokeStyle = raridade(v.raridade).cor; ctx.lineWidth = 2; ctx.stroke();
    ctx.globalAlpha = p.invencivel > 0 && Math.floor(p.invencivel * 12) % 2 ? 0.4 : 1;
    if (boneco.complete) ctx.drawImage(boneco, p.x - 32, p.y - 59, 64, 82); // 64x82 no mundo do jogo
    ctx.globalAlpha = 1;
    if (p.escudo > 0) circulo(p.x, p.y - 10, p.raio + 26, '#6ee7ff', 4);
    for (const t of j.tiros) { circulo(t.x, t.y, t.raio + 3, t.cor + '44'); circulo(t.x, t.y, t.raio, t.cor); }
    for (const f of j.efeitos) { ctx.globalAlpha = Math.max(0, f.t / 0.4); circulo(f.x, f.y, f.r * (1 - f.t), f.cor, 4); ctx.globalAlpha = 1; }
  }
  function hud() {
    $('.vida i').style.width = `${(j.p.vida / j.p.vidaMax) * 100}%`;
    $('.energia i').style.width = `${j.p.energia}%`;
    $('.info').innerHTML = `<b>Onda ${j.onda}/${ULTIMA_ONDA}</b><br>Inimigos: ${j.inimigos.length + j.aSurgir.length}<br>🪙 ${j.ganhos.moedas * multiplicadorArena()}`;
    raiz.querySelectorAll('[data-poder]').forEach((b, i) => {
      const s = j.p.recarga[i], txt = s > 0 ? Math.ceil(s) : '';
      b.lastElementChild.textContent = txt;
      b.style.opacity = j.p.energia < poderes[i].custo ? 0.45 : 1;
    });
  }

  let pausado = false, quadro, antes = performance.now();
  function janela(html) {
    const m = document.createElement('div'); m.className = 'modal'; m.innerHTML = `<div class="painel">${html}</div>`; raiz.append(m); return m;
  }
  function pausar() {
    if (j.fim) return;
    if (pausado) { raiz.querySelector('.modal')?.remove(); pausado = false; antes = performance.now(); return; }
    pausado = true; controles.zerar(); salvar();
    const m = janela(`<h2>Pausado</h2><button class="btn" id="voltar">Continuar</button> <button class="btn sec" id="sair">Sair</button><p><button class="btn sec" id="som-toggle">${somAtivo() ? '🔊 Sons ligados' : '🔇 Sons desligados'}</button></p><label class="suave" for="volume-som">Volume dos efeitos</label><input id="volume-som" type="range" min="0" max="1" step="0.05" value="${volumeSom()}" style="width:100%">`);
    m.querySelector('#voltar').onclick = pausar;
    m.querySelector('#som-toggle').onclick = () => { const ligado = alternarSom(); m.querySelector('#som-toggle').textContent = ligado ? '🔊 Sons ligados' : '🔇 Sons desligados'; $('#som').textContent = ligado ? '🔊' : '🔇'; };
    m.querySelector('#volume-som').oninput = (ev) => definirVolume(ev.target.value);
    m.querySelector('#sair').onclick = aoSair;
  }
  function terminar(venceu) {
    j.fim = true; controles.zerar();
    if (venceu) { som.vitoria(); estado.totais.vitorias++; premiar(40, 35); j.ganhos.moedas += 40; }
    if (!venceu) som.derrota();
    salvar(); hud();
    const m = janela(`<h1>${venceu ? '🏆 VITÓRIA' : '💀 DERROTA'}</h1><p>Ondas completas: ${venceu ? j.onda : j.onda - 1}</p>
      <p>Coins recebidos: <b>${j.ganhos.moedas * multiplicadorArena()}</b></p><br><button class="btn" id="sair">Continuar</button>`);
    m.querySelector('#sair').onclick = aoSair;
  }
  const controles = criarControles(raiz, pausar);
  $('#pausa').onclick = pausar;
  $('#som').textContent = somAtivo() ? '🔊' : '🔇';
  $('#som').onclick = () => { const ligado = alternarSom(); $('#som').textContent = ligado ? '🔊' : '🔇'; if (ligado) som.onda(); };
  const escondeu = () => { if (document.hidden) { if (!pausado) pausar(); salvar(); } };
  document.addEventListener('visibilitychange', escondeu);

  function loop(agora) {
    const dt = Math.min(0.05, Math.max(0, (agora - antes) / 1000)); antes = agora;
    if (!pausado && !j.fim) {
      atualizar(dt);
      for (const f of j.efeitos) f.t -= dt;
      j.efeitos = j.efeitos.filter((f) => f.t > 0);
      if ((relogioAnuncio -= dt) <= 0) $('.anuncio').textContent = '';
      desenhar(); hud();
    }
    quadro = requestAnimationFrame(loop);
  }
  quadro = requestAnimationFrame(loop);

  return () => {
    cancelAnimationFrame(quadro); controles.destruir();
    removeEventListener('resize', ajustar); document.removeEventListener('visibilitychange', escondeu);
    raiz.remove(); salvar();
  };
}
