// Tela da arena: escolha do personagem e partida
import { variante, HABILIDADES } from '../data/characters.js';
import { estado, salvar } from '../systems/state.js';
import { atributos } from '../systems/collection.js';
import { carta } from '../ui/dom.js';
import { criarPartida } from './game.js';

export function arena(app) {
  let parar = null;
  const escolher = () => {
    parar?.(); parar = null;
    const meus = Object.keys(estado.cartas).filter(variante).sort((a, b) => atributos(b).ataque - atributos(a).ataque);
    const sel = variante(estado.selecionado) ?? variante(meus[0]), a = atributos(sel.id);
    app.innerHTML = `<h2>⚔️ Arena 2D</h2><div class="painel"><b>${sel.nome} (${sel.skinNome})</b>
      <p class="suave">❤️ ${a.vida} · ⚔️ ${a.ataque} · ${sel.habilidades.map((h) => `${HABILIDADES[h].icone} ${HABILIDADES[h].nome}`).join(' · ')}</p>
      <p class="suave">Vença 10 ondas. Mini-chefe na onda 3 e 7, chefe na 5 e 10. Melhor onda: ${estado.melhorOnda}.<br>
      Celular: joystick e botões. PC: WASD/setas, Espaço, J e K, P para pausar.</p><br><button class="btn" id="jogar">Entrar na arena</button></div>
      <h3>Escolha seu personagem</h3><div class="grade">${meus.map((id) => `<button data-id="${id}">${carta(variante(id), id === sel.id ? '<span class="selo">✔</span>' : '')}</button>`).join('')}</div>`;
    app.querySelectorAll('[data-id]').forEach((b) => b.onclick = () => { estado.selecionado = b.dataset.id; salvar(); escolher(); });
    app.querySelector('#jogar').onclick = () => { parar = criarPartida(sel.id, escolher); };
  };
  escolher();
  return () => { parar?.(); salvar(); };
}
