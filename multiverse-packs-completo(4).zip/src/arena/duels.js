import { estado, salvar } from '../systems/state.js';
import { variante } from '../data/characters.js';
import { iniciarBatalha2D, escolherAdversario } from './battle2d.js';
import { carta } from '../ui/dom.js';

export function duelos(app){
  let parar=null;
  const render=()=>{
    parar?.();parar=null;
    const meus=Object.keys(estado.cartas).filter(id=>variante(id));
    const sel=variante(estado.selecionado)||variante(meus[0]);
    if(!sel){app.innerHTML='<h2>Duelos</h2><p>Você precisa ter um personagem na coleção.</p><a class="btn" href="#pacotes">Abrir pacotes</a>';return;}
    app.innerHTML=`<h2>⚔️ Duelos 2D</h2><div class="painel"><b>Personagem escolhido: ${sel.nome} · ${sel.skinNome}</b><p class="suave">1v1: vitória +15 Coins, derrota +3. 2v2: vitória +25 Coins, derrota +3. Os adversários são sorteados entre todos os universos.</p><select id="duelo-char" class="campo">${meus.map(id=>{const v=variante(id);return `<option value="${id}" ${id===sel.id?'selected':''}>${v.nome} (${v.skinNome})</option>`}).join('')}</select><div class="grade"><button class="btn" id="um">Entrar no 1v1</button><button class="btn" id="dois">Entrar no 2v2</button></div></div><p class="suave">Controles: setas ou WASD para andar, Espaço para atacar, Q para especial. No celular, use os botões na tela.</p><a href="#menu">← Voltar</a>`;
    app.querySelector('#duelo-char').onchange=e=>{estado.selecionado=e.target.value;salvar();render();};
    const iniciar=(aliados)=>{const p=variante(app.querySelector('#duelo-char').value);const adversario=escolherAdversario(p.personagem);parar=()=>{};iniciarBatalha2D({jogadorId:p.id,inimigoId:adversario.id,modo:'duelo',aliados,aoTerminar:()=>render()});};
    app.querySelector('#um').onclick=()=>iniciar(0);app.querySelector('#dois').onclick=()=>iniciar(1);
  };
  render();return()=>{parar?.();};
}
