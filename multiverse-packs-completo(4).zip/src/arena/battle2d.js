// Combate lateral 2D reutilizado pelo modo História e pelos duelos.
import { variante, PERSONAGENS } from '../data/characters.js';
import { urlArte } from '../ui/art.js';
import { estado, salvar } from '../systems/state.js';
import { ganhar } from '../systems/economy.js';

const aleatorio = (lista) => lista[Math.floor(Math.random() * lista.length)];
export function iniciarBatalha2D({ jogadorId, inimigoId, modo='boss', boss='', aliados=0, recompensa=0, xp=0, aoTerminar=()=>{} }) {
  const jogador = variante(jogadorId), inimigo = PERSONAGENS.find(p=>p.id===inimigoId) || PERSONAGENS.find(p=>p.id==='thanos');
  const pool = PERSONAGENS.filter(p=>p.id!==inimigo.id && p.id!==jogador.personagem);
  const aliado = aliados ? aleatorio(pool) : null;
  const rival2 = aliados ? aleatorio(pool.filter(p=>p.id!==aliado?.id)) : null;
  const raiz=document.createElement('section'); raiz.className='arena duelo2d';
  raiz.innerHTML=`<header class="duelo-hud"><div><b>${jogador.nome}</b><div class="duelo-barra"><i id="vida-p"></i></div></div><b id="duelo-titulo">${modo==='boss'?'CHEFE':'DUELO '+(aliados?'2v2':'1v1')}</b><div><b>${inimigo.nome}</b><div class="duelo-barra inimiga"><i id="vida-e"></i></div></div></header><canvas></canvas><div class="duelo-msg" id="msg"></div><div class="duelo-controles"><button data-key="left">◀</button><button data-key="right">▶</button><button data-key="jump">⬆</button><button data-key="hit">ATACAR</button><button data-key="special">ESPECIAL</button><button id="sair-duelo">SAIR</button></div>`;
  document.body.append(raiz); const canvas=raiz.querySelector('canvas'),ctx=canvas.getContext('2d');
  const W=900,H=480, floor=390; canvas.width=W;canvas.height=H;
  const img=(id,skin='base')=>{const a=new Image();a.src=urlArte(id,skin);return a};
  const pi=img(jogador.personagem,jogador.skin), ei=img(inimigo.id), ai=aliado?img(aliado.id):null, ri=rival2?img(rival2.id):null;
  const p={x:130,y:floor-90,vx:0,vy:0,hp:100,max:100,face:1,freeze:0,atk:0,inv:0};
  const e={x:730,y:floor-90,hp:modo==='boss'?220:100,max:modo==='boss'?220:100,face:-1,atk:1.2,phase:1};
  const friend=aliado?{x:230,y:floor-82,hp:100,atk:0.4}:null, foe= rival2?{x:810,y:floor-82,hp:100,atk:1.6}:null;
  let keys={},shots=[],hazards=[],items=[],running=true,won=false,lost=false,t=0,attackCd=0,specialCd=0,teleportCd=0,dashCd=2.5,cloneHits=0,choice=null;
  const msg=(s)=>{raiz.querySelector('#msg').textContent=s};
  function resize(){const d=Math.min(innerWidth/W,innerHeight/H);canvas.style.width=`${W*d}px`;canvas.style.height=`${H*d}px`;} resize();addEventListener('resize',resize);
  const keydown=(ev)=>{const k=ev.key.toLowerCase();if(['arrowleft','arrowright',' ','arrowup'].includes(k))ev.preventDefault();keys[k]=true;};
  const keyup=(ev)=>keys[ev.key.toLowerCase()]=false;addEventListener('keydown',keydown);addEventListener('keyup',keyup);
  raiz.querySelectorAll('[data-key]').forEach(b=>{const k=b.dataset.key;b.addEventListener('pointerdown',ev=>{ev.preventDefault();keys[k]=true});['pointerup','pointerleave','pointercancel'].forEach(n=>b.addEventListener(n,()=>keys[k]=false));});
  raiz.querySelector('#sair-duelo').onclick=()=>finish(false,true);
  function projectile(x,y,vx,damage,team='p',color='#67e8f9'){shots.push({x,y,vx,damage,team,color});}
  function hitEnemy(target,damage){target.hp=Math.max(0,target.hp-damage);}
  function finish(win,quit=false){if(!running)return;running=false;won=win; if(!quit){if(modo==='boss'){if(win){ganhar(recompensa,xp);msg('CHEFE DERROTADO! +'+recompensa+' Coins');}else msg('Você foi derrotado. Tente novamente.');}else if(modo==='story-mob'){if(win){ganhar(recompensa,xp);msg('Inimigo derrotado! +'+recompensa+' Coins');}else msg('Você foi derrotado. Tente novamente.');}else{const premio=win?(aliados?25:15):3;ganhar(premio,win?25:5);msg((win?'VITÓRIA':'DERROTA')+' · '+premio+' Coins');}}salvar();setTimeout(()=>{limpar();aoTerminar(win,quit)},quit?0:1100);}
  function limpar(){cancelAnimationFrame(frame);removeEventListener('resize',resize);removeEventListener('keydown',keydown);removeEventListener('keyup',keyup);raiz.remove();}
  function bossAI(dt){
    if(boss==='thanos'){
      if(teleportCd<=0){e.x=Math.random()<.5?610:790;teleportCd=7;msg('Thanos se teletransportou!');}
      if(Math.random()<dt*.16){for(let i=0;i<3;i++)hazards.push({x:180+Math.random()*550,y:floor-5,r:42,t:1.2,kind:'meteor'});msg('Meteoros chegando! Saia das áreas marcadas!');}
      if(Math.random()<dt*.09)items.push({x:500+Math.random()*250,y:floor-55,t:6,kind:'alien'});
      if(Math.random()<dt*.07)hazards.push({x:250+Math.random()*400,y:floor-100,w:260,t:1.1,kind:'laser'});
    } else if(boss==='superman-black'){
      if(teleportCd<=0){hazards.push({x:e.x-170,y:floor-100,w:340,t:1.0,kind:'laser'});teleportCd=4;msg('Raio laser! Pule ou se afaste!');}
      if(Math.random()<dt*.1)hazards.push({x:220+Math.random()*480,y:floor-6,r:55,t:1.6,kind:'ice'});
      if(Math.random()<dt*.06)items.push({x:150+Math.random()*600,y:floor-35,t:7,kind:'kryptonite'});
      if(dashCd<=0){e.x=p.x<450?690:250;dashCd=4.5;msg('Superman Black avançou em alta velocidade!');}
    } else if(boss==='beerus'){
      if(e.phase===1 && e.hp<e.max*.5){e.phase=2;e.hp=e.max*.5;msg('Bills voltou com aura roxa! Segunda fase!');}
      if(Math.random()<dt*.11)hazards.push({x:p.x,y:floor-8,r:105,t:3,kind:'purple'});
      if(e.phase===1 && Math.random()<dt*.045){e.clones=4;cloneHits=0;msg('Bills se dividiu em quatro! Acerte as cópias!');}
      if(e.phase===2 && Math.random()<dt*.13)projectile(e.x,floor-70,-(300+Math.random()*100),50,'e','#a855f7');
    }
  }
  function drawFighter(image,x,y,flip,alpha=1){ctx.save();ctx.globalAlpha=alpha;ctx.translate(x,y);ctx.scale(flip?-1:1,1);if(image.complete)ctx.drawImage(image,-43,-88,86,88);else{ctx.fillStyle='#8b5cf6';ctx.fillRect(-25,-70,50,70);}ctx.restore();}
  function update(dt){t+=dt;attackCd-=dt;specialCd-=dt;teleportCd-=dt;dashCd-=dt;p.inv-=dt;p.freeze=Math.max(0,p.freeze-dt);e.atk-=dt;
    if(p.freeze<=0){p.vx=(keys.left||keys.arrowleft?-1:0)+(keys.right||keys.arrowright?1:0);if(p.vx)p.face=Math.sign(p.vx);p.x+=p.vx*240*dt;if((keys.jump||keys.arrowup||keys[' '])&&p.y>=floor-90)p.vy=-470;}else p.vx=0;
    p.vy+=1000*dt;p.y+=p.vy*dt;if(p.y>floor-90){p.y=floor-90;p.vy=0;}p.x=Math.max(45,Math.min(W-45,p.x));
    if((keys.hit||keys[' '])&&attackCd<=0){attackCd=.42;projectile(p.x+p.face*35,p.y-48,p.face*540,12,'p');keys.hit=false;}
    if(keys.special&&specialCd<=0){specialCd=4;projectile(p.x+p.face*40,p.y-48,p.face*690,30,'p','#fbbf24');keys.special=false;}
    if(friend){friend.x+=Math.sign(e.x-friend.x)*75*dt;if(Math.random()<dt*.6)projectile(friend.x+30,floor-120,330,5,'p','#34d399');}
    if(foe){foe.x-=85*dt;if(Math.random()<dt*.7)projectile(foe.x-20,floor-120,-320,8,'e','#fb7185');}
    if(modo==='boss')bossAI(dt);else if(e.atk<=0){e.atk=1.5;projectile(e.x-40,floor-125,-300,9,'e','#fb7185');}
    e.x += Math.sign(p.x-e.x)*((boss==='beerus'&&e.phase===2)?125:75)*dt;e.x=Math.max(boss==='superman-black'?130:500,Math.min(820,e.x));e.face=p.x<e.x?-1:1;
    for(const h of hazards){h.t-=dt;if(h.kind==='purple'&&h.t<.8)msg('PERIGO ROXO! FUJA AGORA!');if(h.t<=0){if(h.kind==='meteor'&&Math.abs(p.x-h.x)<h.r)p.hp-=24;if(h.kind==='purple'&&Math.abs(p.x-h.x)<h.r)p.hp=0;if(h.kind==='ice'&&Math.abs(p.x-h.x)<h.r){p.freeze=2;msg('Congelado por 2 segundos!');}if(h.kind==='laser'&&p.y>floor-150&&Math.abs(p.x-h.x)<h.w/2)p.hp-=30;}}
    hazards=hazards.filter(h=>h.t>0);
    for(const it of items){it.t-=dt;if(Math.abs(p.x-it.x)<40&&it.kind==='kryptonite'){it.t=0;choice='kryptonite';msg('Criptonita coletada! Use ESPECIAL perto do Superman!');}if(it.kind==='alien'&&it.t>0&&Math.random()<dt*.8)projectile(it.x,floor-50,-200,5,'e','#a78bfa');}
    items=items.filter(i=>i.t>0);
    for(const s of shots){s.x+=s.vx*dt;if(s.team==='p'&&Math.abs(p.y-floor)<120){if(Math.abs(s.x-e.x)<42){if(boss==='beerus'&&e.clones){cloneHits++;if(cloneHits>=4){e.clones=0;e.hp-=25;msg('Cópias derrotadas! Bills ficou vulnerável.');}}else if(boss==='superman-black'&&choice==='kryptonite'){e.hp-=50;choice=null;msg('Criptonita acertou!');}else hitEnemy(e,s.damage);s.x=-100;}else if(foe&&foe.hp>0&&Math.abs(s.x-foe.x)<42){foe.hp=Math.max(0,foe.hp-s.damage);s.x=-100;}}else if(s.team==='e'&&Math.abs(s.x-p.x)<35&&p.inv<=0){p.hp-=s.damage;p.inv=.35;s.x=-100;}}
    shots=shots.filter(s=>s.x>-40&&s.x<W+40);
    if(p.hp<=0)finish(false);if(e.hp<=0&&(!foe||foe.hp<=0))finish(true);
    raiz.querySelector('#vida-p').style.width=Math.max(0,p.hp)+'%';raiz.querySelector('#vida-e').style.width=Math.max(0,e.hp/e.max*100)+'%';
  }
  function draw(){ctx.clearRect(0,0,W,H);const g=ctx.createLinearGradient(0,0,0,H);g.addColorStop(0,'#111a3b');g.addColorStop(1,'#080b18');ctx.fillStyle=g;ctx.fillRect(0,0,W,H);ctx.fillStyle='#25324b';ctx.fillRect(0,floor,W,H-floor);ctx.fillStyle='#475569';ctx.fillRect(0,floor,W,5);
    hazards.forEach(h=>{ctx.save();ctx.globalAlpha=.45;ctx.fillStyle=h.kind==='purple'?'#a855f7':h.kind==='ice'?'#67e8f9':h.kind==='laser'?'#ef4444':'#f97316';if(h.kind==='laser')ctx.fillRect(h.x-h.w/2,floor-180,h.w,180);else{ctx.beginPath();ctx.arc(h.x,floor-10,h.r,0,7);ctx.fill();}ctx.restore();});
    items.forEach(i=>{ctx.fillStyle=i.kind==='kryptonite'?'#84cc16':'#a78bfa';ctx.fillRect(i.x-12,floor-70,24,24);ctx.fillStyle='#fff';ctx.font='11px system-ui';ctx.fillText(i.kind==='kryptonite'?'K':'ALIEN',i.x-16,floor-78);});
    drawFighter(pi,p.x,p.y,false,p.inv>0?.55:1);drawFighter(ei,e.x,e.y,true);if(boss==='thanos'){const cores=['#f43f5e','#3b82f6','#22c55e','#eab308','#a855f7','#f97316'];cores.forEach((c,i)=>{const a=t*1.4+i*Math.PI/3;ctx.fillStyle=c;ctx.beginPath();ctx.arc(e.x+Math.cos(a)*57,floor-125+Math.sin(a)*34,7,0,7);ctx.fill();});}if(boss==='beerus'&&e.phase===2){ctx.strokeStyle='#a855f7';ctx.lineWidth=8;ctx.globalAlpha=.5;ctx.beginPath();ctx.arc(e.x,floor-115,60,0,7);ctx.stroke();ctx.globalAlpha=1;}if(friend)drawFighter(ai,friend.x,friend.y,false,.85);if(foe&&foe.hp>0)drawFighter(ri,foe.x,foe.y,true,.85);if(foe&&foe.hp>0){ctx.fillStyle='#fff';ctx.font='13px system-ui';ctx.fillText('Rival 2: '+Math.ceil(foe.hp)+' HP',W-160,55);}
    shots.forEach(s=>{ctx.fillStyle=s.color;ctx.beginPath();ctx.arc(s.x,floor-115,8,0,7);ctx.fill();});
    if(boss==='beerus'&&e.clones){for(let i=0;i<3;i++)drawFighter(ei,570+i*95,floor-90,true,.55);}
    ctx.fillStyle='#fff';ctx.font='18px system-ui';ctx.fillText('WASD/setas: mover · Espaço: atacar · Q: especial',20,30);
  }
  let last=performance.now(),frame;function loop(now){if(!running)return;const dt=Math.min(.04,(now-last)/1000);last=now;update(dt);draw();frame=requestAnimationFrame(loop);}frame=requestAnimationFrame(loop);
}
export function escolherAdversario(excluir){return aleatorio(PERSONAGENS.filter(p=>p.id!==excluir));}
