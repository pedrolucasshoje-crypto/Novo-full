// Controles: teclado, joystick virtual e botões de toque
export function criarControles(raiz, aoPausar) {
  const teclas = new Set(), toque = { x: 0, y: 0, atacando: false }, fila = [];
  let atacandoDedos = new Set();
  const baixo = (e) => {
    if (e.repeat) return;
    const k = e.code;
    if (k === 'KeyP' || k === 'Escape') return aoPausar();
    if (k === 'KeyJ' || k === 'Digit1') fila.push(0);
    if (k === 'KeyK' || k === 'Digit2') fila.push(1);
    if (k === 'Space' || k.startsWith('Arrow')) e.preventDefault();
    teclas.add(k);
  };
  const cima = (e) => teclas.delete(e.code);
  addEventListener('keydown', baixo); addEventListener('keyup', cima);

  const zona = raiz.querySelector('.zona'), joy = raiz.querySelector('.joy'), pino = joy.firstElementChild;
  let dedo = null;
  const mover = (e) => {
    if (e.pointerId !== dedo) return;
    const r = joy.getBoundingClientRect();
    let x = (e.clientX - r.left - r.width / 2) / 50, y = (e.clientY - r.top - r.height / 2) / 50;
    const d = Math.hypot(x, y); if (d > 1) { x /= d; y /= d; }
    toque.x = x; toque.y = y; pino.style.transform = `translate(${x * 38}px,${y * 38}px)`;
  };
  const soltar = (e) => { if (e && e.pointerId !== dedo) return; dedo = null; toque.x = toque.y = 0; pino.style.transform = ''; };
  zona.onpointerdown = (e) => { if (dedo !== null) return; dedo = e.pointerId; zona.setPointerCapture(dedo); mover(e); };
  zona.onpointermove = mover; zona.onpointerup = zona.onpointercancel = soltar;

  const atq = raiz.querySelector('.atq');
  atq.onpointerdown = (e) => { atq.setPointerCapture(e.pointerId); atacandoDedos.add(e.pointerId); };
  atq.onpointerup = atq.onpointercancel = (e) => atacandoDedos.delete(e.pointerId);
  raiz.querySelectorAll('[data-poder]').forEach((b) => b.onpointerdown = () => fila.push(Number(b.dataset.poder)));
  raiz.oncontextmenu = (e) => e.preventDefault();

  return {
    ler() {
      const t = (a, b) => (teclas.has(a) || teclas.has(b) ? 1 : 0);
      let x = toque.x + t('KeyD', 'ArrowRight') - t('KeyA', 'ArrowLeft');
      let y = toque.y + t('KeyS', 'ArrowDown') - t('KeyW', 'ArrowUp');
      const d = Math.hypot(x, y); if (d > 1) { x /= d; y /= d; }
      return { x, y, atacar: teclas.has('Space') || atacandoDedos.size > 0, poderes: fila.splice(0) };
    },
    zerar() { teclas.clear(); atacandoDedos.clear(); fila.length = 0; soltar(); },
    destruir() { removeEventListener('keydown', baixo); removeEventListener('keyup', cima); },
  };
}
