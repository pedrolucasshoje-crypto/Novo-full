import { VARIANTES, UNIVERSOS, HABILIDADES, variante } from '../../data/characters.js';
import { RARIDADES, raridade } from '../../data/rarities.js';
import { CONFIG } from '../../config.js';
import { estado, salvar } from '../../systems/state.js';
import { quantidade, progressoUniversos, converter, converterTodos, valorDuplicados, atributos } from '../../systems/collection.js';
import { carta, barra, modal, avisar } from '../dom.js';

const filtro = { busca: '', universo: '', raridade: '', posse: '' }; // lembrado enquanto o app está aberto
const limpo = (t) => t.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();

export function colecao(app) {
  const opcoes = (lista, atual) => lista.map(([v, n]) => `<option value="${v}" ${v === atual ? 'selected' : ''}>${n}</option>`).join('');
  app.innerHTML = `<h2>📚 Minha Coleção</h2>
    <p>${quantidade()} de ${VARIANTES.length} variantes</p>${barra(quantidade(), VARIANTES.length)}
    <details class="painel" style="margin-top:12px"><summary>Progresso por universo</summary>
      ${progressoUniversos().map((u) => `<p class="linha"><span>${u.nome}</span><b>${u.tem}/${u.total}</b></p>${barra(u.tem, u.total)}`).join('')}</details>
    <button class="btn" id="converter" ${valorDuplicados() ? '' : 'disabled'}>Converter repetidas (+${valorDuplicados()} 🪙)</button>
    <div class="filtros"><input id="busca" type="search" placeholder="Buscar nome" value="">
      <select id="universo">${opcoes([['', 'Todos os universos'], ...Object.entries(UNIVERSOS).map(([k, u]) => [k, u.nome])], filtro.universo)}</select>
      <select id="raridade">${opcoes([['', 'Todas as raridades'], ...RARIDADES.map((r) => [r.id, r.nome])], filtro.raridade)}</select>
      <select id="posse">${opcoes([['', 'Todos'], ['tem', 'Desbloqueados'], ['falta', 'Bloqueados']], filtro.posse)}</select></div>
    <div class="grade" id="lista"></div>`;
  const lista = app.querySelector('#lista');
  const desenhar = () => {
    const itens = VARIANTES.filter((v) => (!filtro.universo || v.universo === filtro.universo)
      && (!filtro.raridade || v.raridade === filtro.raridade)
      && (!filtro.posse || (filtro.posse === 'tem') === Boolean(estado.cartas[v.id]))
      && limpo(v.nome).includes(limpo(filtro.busca)));
    lista.innerHTML = itens.map((v) => {
      const c = estado.cartas[v.id];
      return `<button data-id="${v.id}">${carta(v, c ? `<span class="selo">Nv ${c.nivel}${c.duplicados ? ` · x${c.duplicados + 1}` : ''}</span>` : '<span class="selo">🔒</span>', c ? '' : 'bloqueada')}</button>`;
    }).join('') || '<p class="suave">Nada encontrado.</p>';
    lista.querySelectorAll('button').forEach((b) => b.onclick = () => detalhe(b.dataset.id, () => colecao(app)));
  };
  const busca = app.querySelector('#busca');
  busca.value = filtro.busca;
  busca.oninput = () => { filtro.busca = busca.value; desenhar(); };
  for (const k of ['universo', 'raridade', 'posse']) app.querySelector(`#${k}`).onchange = (e) => { filtro[k] = e.target.value; desenhar(); };
  app.querySelector('#converter').onclick = () => { avisar(`+${converterTodos()} Coins`); colecao(app); };
  desenhar();
}
function detalhe(id, redesenhar) {
  const v = variante(id), c = estado.cartas[id], a = atributos(id), r = raridade(v.raridade);
  const skins = VARIANTES.filter((x) => x.personagem === v.personagem);
  const m = modal(`<div class="painel"><div style="max-width:190px;margin:auto">${carta(v, '', c ? '' : 'bloqueada')}</div>
    <p style="margin:10px">${v.descricao}</p><p class="suave">${UNIVERSOS[v.universo].nome} · ID ${v.id}</p>
    ${c ? `<p>Nível ${c.nivel} · XP ${c.xp}/${CONFIG.xpPersonagem(c.nivel)}</p>${barra(c.xp, CONFIG.xpPersonagem(c.nivel))}` : '<p>🔒 Bloqueado: encontre em pacotinhos</p>'}
    <p>❤️ ${a.vida} · ⚔️ ${a.ataque} · 👟 ${a.velocidade}</p>
    <p>${v.habilidades.map((h) => `${HABILIDADES[h].icone} ${HABILIDADES[h].nome}`).join(' · ')}</p>
    <h3>Skins</h3><p>${skins.map((s) => `<button class="btn sec" data-skin="${s.id}" style="margin:3px">${estado.cartas[s.id] ? '' : '🔒 '}${s.skinNome}</button>`).join('')}</p><br>
    ${c ? `<button class="btn" data-acao="usar">${estado.selecionado === id ? 'Em uso ✔' : 'Usar na arena'}</button>` : ''}
    ${c?.duplicados ? `<button class="btn sec" data-acao="converter">Converter ${c.duplicados} (+${c.duplicados * r.duplicado} 🪙)</button>` : ''}
    <button class="btn sec" data-acao="fechar">Fechar</button></div>`);
  m.querySelectorAll('[data-skin]').forEach((b) => b.onclick = () => { m.remove(); detalhe(b.dataset.skin, redesenhar); });
  m.querySelectorAll('[data-acao]').forEach((b) => b.onclick = () => {
    if (b.dataset.acao === 'usar') { estado.selecionado = id; salvar(); avisar(`${v.nome} escolhido`); }
    if (b.dataset.acao === 'converter') avisar(`+${converter(id)} Coins`);
    m.remove(); redesenhar();
  });
}
