import { estado, salvar, apagarProgresso } from '../../systems/state.js';
import { quantidade } from '../../systems/collection.js';
import { CONFIG } from '../../config.js';
import { seguro, barra, modal, avisar } from '../dom.js';

export function perfil(app) {
  const t = estado.totais;
  app.innerHTML = `<h2>👤 Perfil</h2>
    <div class="painel"><label for="nome">Seu nome</label><input id="nome" class="campo" maxlength="20" value="${seguro(estado.nome)}">
      <p style="margin-top:12px">Nível ${estado.nivel} · XP ${estado.xp}/${CONFIG.xpJogador(estado.nivel)}</p>${barra(estado.xp, CONFIG.xpJogador(estado.nivel))}</div>
    <div class="painel">${[['Variantes', quantidade()], ['Pacotes abertos', t.pacotes], ['Cartas repetidas', t.duplicados], ['Inimigos derrotados', t.abates], ['Ondas completas', t.ondas], ['Melhor onda', estado.melhorOnda], ['Chefes vencidos', t.chefes], ['Vitórias', t.vitorias]]
      .map(([n, v]) => `<p class="linha"><span>${n}</span><b>${v}</b></p>`).join('')}</div>
    <h3>Configurações</h3><div class="painel">
      ${[['particulas', 'Partículas no fundo'], ['vibrar', 'Vibração']].map(([k, n]) => `<label class="linha" style="padding:6px 0">${n}<input type="checkbox" data-c="${k}" ${estado.config[k] ? 'checked' : ''}></label>`).join('')}</div>
    <button class="btn sec" id="apagar">Apagar progresso</button><p class="suave centro">Versão ${CONFIG.versao} · Sem dinheiro real</p>`;
  app.querySelector('#nome').onchange = (e) => { estado.nome = e.target.value.trim() || 'Viajante'; salvar(); avisar('Nome salvo'); };
  app.querySelectorAll('[data-c]').forEach((c) => c.onchange = () => { estado.config[c.dataset.c] = c.checked; salvar(); });
  app.querySelector('#apagar').onclick = () => {
    const m = modal('<div class="painel"><h2>Apagar tudo?</h2><p>Essa ação não pode ser desfeita.</p><br><button class="btn sec" id="nao">Cancelar</button> <button class="btn" id="sim">Apagar</button></div>');
    m.querySelector('#nao').onclick = () => m.remove();
    m.querySelector('#sim').onclick = async () => { await apagarProgresso(); m.remove(); perfil(app); avisar('Progresso apagado'); };
  };
}
