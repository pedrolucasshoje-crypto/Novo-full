import { MISSOES } from '../../data/missions.js';
import { atualizarPeriodos, progresso, resgatar } from '../../systems/missions.js';
import { barra, avisar } from '../dom.js';

let aba = 'diarias';
export function missoes(app) {
  atualizarPeriodos();
  const nomes = { diarias: 'Diárias', semanais: 'Semanais', conquistas: 'Conquistas' };
  app.innerHTML = `<h2>🎯 Missões</h2><div class="abas">${Object.entries(nomes).map(([k, n]) => `<button data-aba="${k}" class="${k === aba ? 'ativo' : ''}">${n}</button>`).join('')}</div>
    ${MISSOES[aba].map((m) => { const p = progresso(aba, m); return `<div class="painel linha"><div style="flex:1"><b>${m.texto}</b>
      <p class="suave">${p.atual}/${m.meta} · ${m.moedas} 🪙 · ${m.xp} XP</p>${barra(p.atual, m.meta)}</div>
      <button class="btn" data-id="${m.id}" ${p.pronta ? '' : 'disabled'}>${p.feita ? '✔' : 'Resgatar'}</button></div>`; }).join('')}`;
  app.querySelectorAll('[data-aba]').forEach((b) => b.onclick = () => { aba = b.dataset.aba; missoes(app); });
  app.querySelectorAll('[data-id]').forEach((b) => b.onclick = () => { if (resgatar(aba, b.dataset.id)) avisar('Recompensa recebida!'); missoes(app); });
}
