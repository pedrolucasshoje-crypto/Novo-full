import { eventoAtual, pacoteEvento, presenteDisponivel, coletarPresente, multiplicadorArena } from '../../systems/events.js';
import { cartaoPacote, ligarPacotes } from './packs.js';
import { avisar } from '../dom.js';

export function eventos(app) {
  const e = eventoAtual(), p = pacoteEvento();
  app.innerHTML = `<h2>🎉 Eventos</h2>
    <div class="painel"><h3 style="margin-top:0">${e.icone} ${e.nome}</h3><p class="suave">${e.texto} O evento troca toda segunda-feira.</p></div>
    <div class="painel linha"><div><b>Presente da semana</b><p class="suave">60 Coins</p></div>
      <button class="btn" id="presente" ${presenteDisponivel() ? '' : 'disabled'}>${presenteDisponivel() ? 'Coletar' : 'Coletado'}</button></div>
    <div class="painel"><b>🔥 Bônus de fim de semana</b><p class="suave">${multiplicadorArena() > 1 ? 'Ativo agora!' : 'Sábado e domingo'}: Coins e XP da arena +25%.</p></div>
    <div class="grade">${cartaoPacote(p)}</div>`;
  app.querySelector('#presente').onclick = () => { if (coletarPresente()) avisar('+60 Coins'); eventos(app); };
  ligarPacotes(app, [p], () => eventos(app));
}
