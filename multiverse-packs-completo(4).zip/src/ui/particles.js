// Estrelas flutuando no fundo
import { estado } from '../systems/state.js';
export function iniciarParticulas() {
  const c = document.querySelector('#particulas'), x = c.getContext('2d');
  const calmo = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const ajustar = () => { c.width = innerWidth; c.height = innerHeight; };
  addEventListener('resize', ajustar); ajustar();
  const p = Array.from({ length: 45 }, () => ({ x: Math.random(), y: Math.random(), r: Math.random() * 1.8 + 0.5, v: Math.random() * 0.0006 + 0.0002 }));
  (function quadro() {
    x.clearRect(0, 0, c.width, c.height);
    if (estado.config.particulas && !calmo && !document.querySelector('.arena')) {
      for (const [i, s] of p.entries()) {
        s.y = (s.y - s.v + 1) % 1;
        x.fillStyle = i % 3 ? '#6ee7ff66' : '#c084fc77';
        x.beginPath(); x.arc(s.x * c.width, s.y * c.height, s.r, 0, 7); x.fill();
      }
    }
    requestAnimationFrame(quadro);
  })();
}
