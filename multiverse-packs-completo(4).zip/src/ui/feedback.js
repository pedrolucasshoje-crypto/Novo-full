import { estado } from '../systems/state.js';
export const vibrar = (ms) => { if (estado.config.vibrar) navigator.vibrate?.(ms); };
