import { UNIVERSOS } from '../data/characters.js';
import { raridade, ordemRaridade } from '../data/rarities.js';
import { urlArte } from './art.js';

// protege textos digitados pelo jogador antes de colocar no HTML
export const seguro = (t) => String(t).replace(/[&<>"']/g, (c) => `&#${c.charCodeAt(0)};`);
let relogio;
export function avisar(texto) {
  const a = document.querySelector('#aviso');
  a.textContent = texto; a.classList.add('visivel');
  clearTimeout(relogio); relogio = setTimeout(() => a.classList.remove('visivel'), 2200);
}
export const barra = (valor, max) => `<div class="barra"><i style="width:${Math.min(100, (valor / max) * 100)}%"></i></div>`;
export function carta(v, extra = '', classes = '') {
  const r = raridade(v.raridade);
  return `<div class="carta skin-${v.skin} ${ordemRaridade(r.id) >= 4 ? 'brilho' : ''} ${classes}" style="--c:${r.cor};--u:${UNIVERSOS[v.universo].cor}">
    <div class="arte"><img src="${urlArte(v.personagem, v.skin)}" alt="" draggable="false"></div><strong>${v.nome}</strong><small>${r.nome}</small><span class="suave">${v.skinNome}</span>${extra}</div>`;
}
export function modal(html) {
  const m = document.createElement('div');
  m.className = 'modal'; m.innerHTML = `<div>${html}</div>`;
  document.body.append(m);
  return m;
}
