// Configurações gerais: mude os valores aqui para ajustar o jogo
export const CONFIG = {
  versao: '1.5.0',
  moedasIniciais: 250,
  cartasPorPacote: 1,
  loginDiario: [10, 12, 15, 18, 20, 24, 30], // bônus modesto por sequência diária
  xpJogador: (nivel) => nivel * 100,    // XP para passar de nível
  xpPersonagem: (nivel) => nivel * 60,
  nivelMaximoPersonagem: 30,
};
