// filtro = quais variantes podem sair | bonus multiplica o peso das raridades a partir de "raro"
const universo = (u) => (v) => v.universo === u;
export const PACOTES = [
  { id: 'doomsday', nome: 'Doomsday', icone: '☄️', cor: '#ef4444', preco: 300, bonus: 1, filtro: universo('apocalipse') },
  { id: 'dc', nome: 'DC Universe', icone: '🦇', cor: '#2563eb', preco: 350, bonus: 1, filtro: universo('aurora') },
  { id: 'dragonball', nome: 'Dragon Ball', icone: '🐉', cor: '#f97316', preco: 350, bonus: 1, filtro: universo('astral') },
  { id: 'marvel', nome: 'Marvel', icone: '🕷️', cor: '#dc2626', preco: 350, bonus: 1, filtro: universo('vigilantes') },
  { id: 'attackontitan', nome: 'Attack on Titan', icone: '⚔️', cor: '#64748b', preco: 350, bonus: 1, filtro: universo('titas') },
  { id: 'naruto', nome: 'Naruto', icone: '🍥', cor: '#f97316', preco: 350, bonus: 1, filtro: universo('konoha') },
  { id: 'onepiece', nome: 'One Piece', icone: '🏴‍☠️', cor: '#0ea5e9', preco: 350, bonus: 1, filtro: universo('grandline') },
  { id: 'jujutsu', nome: 'Jujutsu Kaisen', icone: '🌀', cor: '#7c3aed', preco: 350, bonus: 1, filtro: universo('feiticeiros') },
  { id: 'demonslayer', nome: 'Demon Slayer', icone: '🔥', cor: '#16a34a', preco: 350, bonus: 1, filtro: universo('cacadores') },
  { id: 'pokemon', nome: 'Pokémon', icone: '⚡', cor: '#eab308', preco: 350, bonus: 1, filtro: universo('pokemon') },
  { id: 'transformers', nome: 'Transformers', icone: '🤖', cor: '#64748b', preco: 350, bonus: 1, filtro: universo('cybertron') },
  { id: 'sonic', nome: 'Sonic', icone: '💨', cor: '#2563eb', preco: 350, bonus: 1, filtro: universo('sonic') },
  { id: 'starwars', nome: 'Star Wars', icone: '🌌', cor: '#a3a3a3', preco: 350, bonus: 1, filtro: universo('starwars') },
  { id: 'herois', nome: 'Heróis', icone: '🛡️', cor: '#38bdf8', preco: 450, bonus: 1, filtro: (v) => v.lado === 'heroi' },
  { id: 'viloes', nome: 'Vilões', icone: '😈', cor: '#a855f7', preco: 450, bonus: 1, filtro: (v) => v.lado === 'vilao' },
  { id: 'multiverso', nome: 'Multiverso', icone: '🌌', cor: '#6ee7ff', preco: 750, bonus: 1, filtro: () => true },
];

// Eventos: um por semana, em rodízio
export const EVENTOS = [
  { id: 'eclipse', nome: 'Eclipse Sombrio', icone: '🌑', cor: '#8b5cf6', texto: 'Skins Sombrias em destaque.', filtro: (v) => v.skin === 'sombra' },
  { id: 'luzes', nome: 'Festival Neon', icone: '🎆', cor: '#22d3ee', texto: 'Só skins Neon no pacote.', filtro: (v) => v.skin === 'neon' },
  { id: 'cacada', nome: 'Caçada aos Vilões', icone: '🎯', cor: '#f43f5e', texto: 'Vilões com mais chance de raridade.', filtro: (v) => v.lado === 'vilao' },
];
export const PRECO_EVENTO = 650;
