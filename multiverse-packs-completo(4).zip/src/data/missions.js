import { VARIANTES } from './characters.js';
// metrica = contador acompanhado | meta = objetivo | moedas/xp = recompensa
const m = (id, texto, metrica, meta, moedas, xp) => ({ id, texto, metrica, meta, moedas, xp });
export const MISSOES = {
  diarias: [
    m('d1', 'Abra 1 pacotinho', 'pacotes', 1, 20, 12),
    m('d2', 'Derrote 20 inimigos', 'abates', 20, 25, 15),
    m('d3', 'Complete 3 ondas', 'ondas', 3, 30, 18),
  ],
  semanais: [
    m('s1', 'Abra 10 pacotinhos', 'pacotes', 10, 80, 45),
    m('s2', 'Derrote 150 inimigos', 'abates', 150, 100, 55),
    m('s3', 'Vença 3 chefes', 'chefes', 3, 120, 70),
    m('s4', 'Consiga 3 cartas raras ou melhores', 'raros', 3, 70, 40),
  ],
  conquistas: [
    m('c1', 'Primeiro pacote', 'pacotes', 1, 35, 20),
    m('c2', 'Consiga um personagem raro', 'raros', 1, 35, 20),
    m('c3', 'Colecione 10 variantes', 'colecao', 10, 60, 35),
    m('c4', 'Colecione 40 variantes', 'colecao', 40, 180, 90),
    m('c5', 'Colecione todas as variantes', 'colecao', VARIANTES.length, 1200, 500),
    m('c6', 'Complete a coleção de um universo', 'universos', 1, 300, 120),
    m('c7', 'Derrote 500 inimigos', 'abates', 500, 180, 90),
    m('c8', 'Chegue à onda 10', 'melhorOnda', 10, 150, 75),
  ],
};
