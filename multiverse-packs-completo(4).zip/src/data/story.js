// Campanha original: 3 ilhas, 5 fases em cada uma.
export const ILHAS = [
  { id: 'aurora', nome: 'Ilha da Aurora', emoji: '🌅', descricao: 'O primeiro rasgo entre universos apareceu aqui.' },
  { id: 'sombras', nome: 'Arquipélago das Sombras', emoji: '🌑', descricao: 'As realidades estão se misturando e os rivais ficaram mais fortes.' },
  { id: 'nexus', nome: 'Núcleo do Multiverso', emoji: '🌌', descricao: 'Chegue ao centro da ruptura e enfrente sua origem.' },
];
const fases = [
  ['O portal desperta', 'joker', 'O Coringa tomou a praça próxima ao portal.', 80, 12, 28, 21, false],
  ['A ameaça gelada', 'frieza', 'Uma força cósmica bloqueia a passagem.', 105, 14, 35, 27, false],
  ['O tirano roxo', 'thanos', 'Um conquistador quer controlar a primeira ilha.', 125, 16, 42, 33, false],
  ['O teste dos guerreiros', 'madara', 'Um estrategista lendário protege a ponte.', 145, 18, 49, 39, false],
  ['Guardião da Aurora', 'beerus', 'O guardião da ilha decidiu testar seu poder.', 190, 21, 77, 60, true],
  ['A cidade amaldiçoada', 'sukuna', 'Uma energia sombria tomou as ruas.', 210, 22, 56, 42, false],
  ['A fortaleza demoníaca', 'muzan', 'A fortaleza está protegida por um inimigo perigoso.', 235, 24, 61, 45, false],
  ['O sinal de Cybertron', 'megatron', 'Uma máquina colossal bloqueia o caminho.', 260, 26, 66, 48, false],
  ['O lado sombrio', 'vader', 'Um mestre do lado sombrio guarda o portal.', 285, 28, 74, 54, false],
  ['Senhor das Sombras', 'magneto', 'O líder da ilha desafia sua equipe.', 340, 31, 105, 84, true],
  ['A última travessia', 'shadow', 'Uma presença veloz protege a entrada do núcleo.', 365, 33, 80, 60, false],
  ['O guerreiro implacável', 'eren', 'O poder dos titãs ameaça o equilíbrio.', 390, 35, 88, 66, false],
  ['O imperador', 'palpatine', 'O imperador prepara a ruptura final.', 420, 38, 96, 72, false],
  ['O destruidor de mundos', 'broly', 'Uma força quase imparável guarda o caminho.', 460, 41, 105, 78, false],
  ['O Doutor do Multiverso', 'doctor-doom', 'Enfrente a mente por trás da crise e conclua a campanha.', 560, 46, 175, 150, true],
];
export const FASES = fases.map(([nome, inimigo, historia, vida, ataque, moedas, xp, chefe], i) => ({
  id: `fase-${i + 1}`, numero: i + 1, ilha: Math.floor(i / 5), nome, inimigo, historia, vida, ataque, moedas, xp, chefe,
}));
