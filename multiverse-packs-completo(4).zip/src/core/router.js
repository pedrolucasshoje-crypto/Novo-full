// Navegação por "hash" (#pacotes, #colecao...): troca de tela sem recarregar.
// O botão voltar do celular também funciona.
let rotas = {}, limpar = null;
export function iniciarRotas(mapa, aoTrocar) {
  rotas = mapa;
  const mostrar = () => {
    const nome = location.hash.slice(1) in rotas ? location.hash.slice(1) : 'menu';
    limpar?.(); limpar = null;
    document.querySelectorAll('.modal').forEach((m) => m.remove());
    const app = document.querySelector('#app');
    app.style.animation = 'none'; void app.offsetWidth; app.style.animation = '';
    aoTrocar(nome);
    limpar = rotas[nome](app) ?? null; // uma tela pode devolver uma função de limpeza
    scrollTo(0, 0);
  };
  addEventListener('hashchange', mostrar);
  mostrar();
}
