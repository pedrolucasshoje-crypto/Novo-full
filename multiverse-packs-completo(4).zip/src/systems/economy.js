// Moedas, XP e login diário
import { CONFIG } from '../config.js';
import { estado, salvar } from './state.js';
import { chaveDia } from './time.js';

export function ganhar(moedas, xp = 0) {
  estado.moedas += Math.round(moedas);
  estado.xp += Math.round(xp);
  while (estado.xp >= CONFIG.xpJogador(estado.nivel)) {
    estado.xp -= CONFIG.xpJogador(estado.nivel);
    estado.nivel++;
    estado.moedas += 15; // bônus pequeno por subir de nível
  }
}
export function gastar(valor) {
  if (estado.moedas < valor) return false;
  estado.moedas -= valor;
  return true;
}
export function statusLogin() {
  const hoje = chaveDia(), ontem = chaveDia(-1);
  const { ultimo, sequencia } = estado.login;
  const disponivel = hoje > ultimo; // atrasar o relógio não libera de novo
  const dia = ultimo === ontem ? (sequencia % 7) + 1 : disponivel ? 1 : sequencia;
  return { disponivel, dia, valor: CONFIG.loginDiario[dia - 1] };
}
export function coletarLogin() {
  const s = statusLogin();
  if (!s.disponivel) return null;
  estado.login = { ultimo: chaveDia(), sequencia: s.dia };
  ganhar(s.valor, 15);
  salvar();
  return s;
}
