import { MISSOES } from '../data/missions.js';
import { estado, salvar } from './state.js';
import { chaveDia, chaveSemana } from './time.js';
import { ganhar } from './economy.js';
import { quantidade, progressoUniversos } from './collection.js';

// Em um novo dia/semana, guarda os totais atuais como ponto de partida
export function atualizarPeriodos() {
  let mudou = false;
  for (const [grupo, periodo] of [['diarias', chaveDia()], ['semanais', chaveSemana()]]) {
    if (periodo > estado.missoes[grupo].periodo) {
      estado.missoes[grupo] = { periodo, base: { ...estado.totais }, feitas: {} }; mudou = true;
    }
  }
  if (mudou) salvar();
}
export function progresso(grupo, missao) {
  let atual;
  if (missao.metrica === 'colecao') atual = quantidade();
  else if (missao.metrica === 'universos') atual = progressoUniversos().filter((u) => u.tem === u.total).length;
  else if (missao.metrica === 'melhorOnda') atual = estado.melhorOnda;
  else atual = estado.totais[missao.metrica] - (estado.missoes[grupo].base?.[missao.metrica] ?? 0);
  const feita = Boolean(estado.missoes[grupo].feitas[missao.id]);
  return { atual: Math.min(atual, missao.meta), feita, pronta: !feita && atual >= missao.meta };
}
export function resgatar(grupo, id) {
  atualizarPeriodos();
  const m = MISSOES[grupo].find((x) => x.id === id);
  if (!m || !progresso(grupo, m).pronta) return false;
  estado.missoes[grupo].feitas[id] = true;
  ganhar(m.moedas, m.xp); salvar(); return true;
}
export function pendentes() {
  return Object.entries(MISSOES).reduce((s, [g, l]) => s + l.filter((m) => progresso(g, m).pronta).length, 0);
}
