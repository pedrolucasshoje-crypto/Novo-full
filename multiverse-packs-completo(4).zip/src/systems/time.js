// Datas no horário do aparelho
const formato = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
export function chaveDia(deslocamento = 0) {
  const d = new Date(); d.setDate(d.getDate() + deslocamento); return formato(d);
}
// a semana é identificada pela data da segunda-feira
export function chaveSemana() { return chaveDia(-((new Date().getDay() + 6) % 7)); }
export function numeroSemana() { return Math.round(Date.parse(chaveSemana()) / 604800000); }
export const fimDeSemana = () => [0, 6].includes(new Date().getDay());
