import { CONFIG } from '../config.js';
import { VARIANTES, UNIVERSOS, variante } from '../data/characters.js';
import { raridade } from '../data/rarities.js';
import { estado, salvar } from './state.js';
import { ganhar } from './economy.js';

export const quantidade = () => Object.keys(estado.cartas).filter(variante).length;
export function progressoUniversos() {
  return Object.entries(UNIVERSOS).map(([id, u]) => {
    const todas = VARIANTES.filter((v) => v.universo === id);
    return { id, ...u, tem: todas.filter((v) => estado.cartas[v.id]).length, total: todas.length };
  });
}
export function converter(id) {
  const c = estado.cartas[id];
  if (!c?.duplicados) return 0;
  const valor = c.duplicados * raridade(variante(id).raridade).duplicado;
  c.duplicados = 0; ganhar(valor); salvar(); return valor;
}
export const valorDuplicados = () => Object.entries(estado.cartas)
  .reduce((s, [id, c]) => s + (variante(id) ? c.duplicados * raridade(variante(id).raridade).duplicado : 0), 0);
export const converterTodos = () => Object.keys(estado.cartas).reduce((s, id) => s + converter(id), 0);

export function atributos(id) {
  const v = variante(id), nivel = estado.cartas[id]?.nivel ?? 1, f = 1 + (nivel - 1) * 0.04;
  return { vida: Math.round(v.stats.vida * f), ataque: Math.round(v.stats.ataque * f), velocidade: v.stats.velocidade };
}
export function xpCarta(id, xp) {
  const c = estado.cartas[id];
  c.xp += xp;
  while (c.nivel < CONFIG.nivelMaximoPersonagem && c.xp >= CONFIG.xpPersonagem(c.nivel)) { c.xp -= CONFIG.xpPersonagem(c.nivel); c.nivel++; }
  if (c.nivel >= CONFIG.nivelMaximoPersonagem) c.xp = 0;
}
