// Estado do jogador: o que é salvo
import { CONFIG } from '../config.js';
import { carregarSave, gravarSave } from '../storage/db.js';

const novoJogador = () => ({
  versaoSave: 1, nome: 'Viajante', moedas: CONFIG.moedasIniciais, nivel: 1, xp: 0,
  // chave = id da variante
  cartas: { 'superman:base': { nivel: 1, xp: 0, duplicados: 0 } },
  selecionado: 'superman:base',
  totais: { pacotes: 0, abates: 0, ondas: 0, chefes: 0, raros: 0, duplicados: 0, vitorias: 0 },
  melhorOnda: 0,
  historia: { concluidas: [] },
  missoes: { diarias: { periodo: '', base: {}, feitas: {} }, semanais: { periodo: '', base: {}, feitas: {} }, conquistas: { feitas: {} } },
  login: { ultimo: '', sequencia: 0 },
  eventos: {},
  config: { particulas: true, vibrar: true },
});

export let estado;
let fila = Promise.resolve();
export let erroSave = false;

export async function iniciarEstado() {
  try {
    const salvo = await carregarSave();
    const base = novoJogador();
    estado = salvo ? { ...base, ...salvo, totais: { ...base.totais, ...salvo.totais }, config: { ...base.config, ...salvo.config }, historia: { ...base.historia, ...(salvo.historia || {}), concluidas: Array.isArray(salvo.historia?.concluidas) ? salvo.historia.concluidas : [] } } : base;
  } catch (e) {
    // se não deu para LER, não gravamos nada, para não apagar um save existente
    console.warn('Falha ao ler o save', e);
    erroSave = true; estado = novoJogador();
  }
}
const ouvintes = new Set();
export const aoMudar = (f) => ouvintes.add(f);
export function salvar() {
  ouvintes.forEach((f) => f());
  if (erroSave) return fila;
  const copia = structuredClone(estado);
  fila = fila.then(() => gravarSave(copia)).catch((e) => console.warn('Falha ao salvar', e));
  return fila;
}
export async function apagarProgresso() { estado = novoJogador(); erroSave = false; await salvar(); }
