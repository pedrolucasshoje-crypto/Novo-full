import { FASES } from '../data/story.js';
import { estado, salvar } from './state.js';
import { ganhar } from './economy.js';

export const faseLiberada = (fase) => fase.numero === 1 || estado.historia.concluidas.includes(`fase-${fase.numero - 1}`);
export const faseConcluida = (fase) => estado.historia.concluidas.includes(fase.id);
export function concluirFase(fase) {
  if (!faseLiberada(fase)) return false;
  const primeiraVez = !faseConcluida(fase);
  if (primeiraVez) {
    estado.historia.concluidas.push(fase.id);
    estado.totais.vitorias = (estado.totais.vitorias || 0) + 1;
    if (fase.chefe) estado.totais.chefes = (estado.totais.chefes || 0) + 1;
    ganhar(fase.moedas, fase.xp);
    salvar();
  }
  return primeiraVez;
}
export const progressoHistoria = () => estado.historia.concluidas.length;
export const ultimaFase = () => FASES.find((f) => !faseConcluida(f)) || FASES[FASES.length - 1];
