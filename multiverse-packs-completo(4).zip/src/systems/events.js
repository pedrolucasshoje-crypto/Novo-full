import { EVENTOS, PRECO_EVENTO } from '../data/packs.js';
import { estado, salvar } from './state.js';
import { numeroSemana, chaveSemana, fimDeSemana } from './time.js';
import { ganhar } from './economy.js';

export const eventoAtual = () => EVENTOS[numeroSemana() % EVENTOS.length];
export const pacoteEvento = () => {
  const e = eventoAtual();
  return { id: 'evento', nome: e.nome, icone: e.icone, cor: e.cor, preco: PRECO_EVENTO, bonus: 2, filtro: e.filtro };
};
export const multiplicadorArena = () => (fimDeSemana() ? 1.25 : 1);
export const presenteDisponivel = () => estado.eventos.presente !== chaveSemana() && chaveSemana() > (estado.eventos.presente ?? '');
export function coletarPresente() {
  if (!presenteDisponivel()) return false;
  estado.eventos.presente = chaveSemana();
  ganhar(60, 25); salvar(); return true;
}
