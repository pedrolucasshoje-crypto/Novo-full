// Único arquivo que conversa com o IndexedDB. Para usar um banco remoto, troque só este.
const BANCO = 'multiverse-packs', LOJA = 'saves', CHAVE = 'jogador';

function abrir() {
  return new Promise((ok, erro) => {
    const req = indexedDB.open(BANCO, 1);
    req.onupgradeneeded = () => req.result.createObjectStore(LOJA);
    req.onsuccess = () => ok(req.result);
    req.onerror = () => erro(req.error);
  });
}
let conexao;
async function transacao(modo, acao) {
  conexao ??= await abrir();
  return new Promise((ok, erro) => {
    const t = conexao.transaction(LOJA, modo);
    const req = acao(t.objectStore(LOJA));
    t.oncomplete = () => ok(req.result);
    t.onerror = t.onabort = () => erro(t.error);
  });
}
export const carregarSave = () => transacao('readonly', (l) => l.get(CHAVE));
export const gravarSave = (dados) => transacao('readwrite', (l) => l.put(dados, CHAVE));
