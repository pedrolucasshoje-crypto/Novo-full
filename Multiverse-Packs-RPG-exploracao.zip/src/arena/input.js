// Controles robustos para teclado e touch (Pointer Events), evitando ponteiros presos.
export function criarControles(raiz, aoPausar) {
  const teclas = new Set(), toque = { x: 0, y: 0 }, fila = [];
  const atacandoDedos = new Set();
  const poderesDedos = new Set();
  const baixo = (e) => {
    if (e.repeat) return;
    if (e.code === 'KeyP' || e.code === 'Escape') { aoPausar(); return; }
    if (e.code === 'KeyJ' || e.code === 'Digit1') fila.push(0);
    if (e.code === 'KeyK' || e.code === 'Digit2') fila.push(1);
    if (e.code === 'Space' || e.code.startsWith('Arrow')) e.preventDefault();
    teclas.add(e.code);
  };
  const cima = (e) => teclas.delete(e.code);
  addEventListener('keydown', baixo); addEventListener('keyup', cima);

  const zona = raiz.querySelector('.zona'), joy = raiz.querySelector('.joy'), pino = joy.firstElementChild;
  let dedo = null;
  function mover(e) {
    if (dedo === null || e.pointerId !== dedo) return;
    const r = joy.getBoundingClientRect();
    let x = (e.clientX - r.left - r.width / 2) / (r.width * .42);
    let y = (e.clientY - r.top - r.height / 2) / (r.height * .42);
    const d = Math.hypot(x, y); if (d > 1) { x /= d; y /= d; }
    toque.x = x; toque.y = y; pino.style.transform = `translate(${x * 38}px,${y * 38}px)`;
  }
  function soltar(e) {
    if (e && dedo !== null && e.pointerId !== dedo) return;
    if (dedo !== null) { try { zona.releasePointerCapture(dedo); } catch {} }
    dedo = null; toque.x = toque.y = 0; pino.style.transform = '';
  }
  zona.onpointerdown = (e) => { if (dedo !== null) return; e.preventDefault(); dedo = e.pointerId; try { zona.setPointerCapture(dedo); } catch {} mover(e); };
  zona.onpointermove = mover; zona.onpointerup = soltar; zona.onpointercancel = soltar; zona.onlostpointercapture = soltar;
  window.addEventListener('pointermove', mover); window.addEventListener('pointerup', soltar); window.addEventListener('pointercancel', soltar);

  const atq = raiz.querySelector('.atq');
  atq.onpointerdown = (e) => { e.preventDefault(); atacandoDedos.add(e.pointerId); try { atq.setPointerCapture(e.pointerId); } catch {} };
  const soltarAtaque = (e) => atacandoDedos.delete(e.pointerId);
  atq.onpointerup = atq.onpointercancel = atq.onlostpointercapture = soltarAtaque;
  raiz.querySelectorAll('[data-poder]').forEach((b) => {
    const acionar = (e) => { e.preventDefault(); if (!poderesDedos.has(e.pointerId)) { poderesDedos.add(e.pointerId); fila.push(Number(b.dataset.poder)); } };
    const liberar = (e) => poderesDedos.delete(e.pointerId);
    b.onpointerdown = acionar; b.onpointerup = b.onpointercancel = b.onlostpointercapture = liberar;
  });
  raiz.oncontextmenu = (e) => e.preventDefault();
  const perderFoco = () => { teclas.clear(); atacandoDedos.clear(); poderesDedos.clear(); soltar(); };
  window.addEventListener('blur', perderFoco);

  return {
    ler() {
      const t = (a, b) => (teclas.has(a) || teclas.has(b) ? 1 : 0);
      let x = toque.x + t('KeyD', 'ArrowRight') - t('KeyA', 'ArrowLeft');
      let y = toque.y + t('KeyS', 'ArrowDown') - t('KeyW', 'ArrowUp');
      const d = Math.hypot(x, y); if (d > 1) { x /= d; y /= d; }
      return { x, y, atacar: teclas.has('Space') || atacandoDedos.size > 0, poderes: fila.splice(0) };
    },
    zerar() { teclas.clear(); atacandoDedos.clear(); poderesDedos.clear(); fila.length = 0; soltar(); },
    destruir() {
      removeEventListener('keydown', baixo); removeEventListener('keyup', cima);
      window.removeEventListener('pointermove', mover); window.removeEventListener('pointerup', soltar); window.removeEventListener('pointercancel', soltar);
      window.removeEventListener('blur', perderFoco); raiz.oncontextmenu = null; soltar();
    },
  };
}
