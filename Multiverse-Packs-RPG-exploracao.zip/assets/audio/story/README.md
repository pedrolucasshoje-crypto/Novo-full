# Áudio do modo história
Coloque arquivos de música autorizados nestas pastas (arquivos opcionais):
- `aurora.ogg`, `sombras.ogg`, `nexus.ogg`: ambiente regional
- `battle.ogg`: música de batalha
- `boss.ogg`: música de chefe
- `bills-original.ogg`: trilha original/autorizada para Bills

O modo história atual não inicia música automaticamente ainda; estes nomes são um padrão de organização para integração posterior. Não inclua faixas protegidas sem autorização.
