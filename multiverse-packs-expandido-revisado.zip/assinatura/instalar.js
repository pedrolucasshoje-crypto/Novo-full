// Roda depois do "npm install": usa sempre a mesma chave para assinar o APK de teste.
const fs = require('fs'), path = require('path'), os = require('os');
if (process.env.CI) { // só no computador do GitHub, para não mexer no seu
  const pasta = path.join(os.homedir(), '.android');
  fs.mkdirSync(pasta, { recursive: true });
  fs.copyFileSync(path.join(__dirname, 'debug.keystore'), path.join(pasta, 'debug.keystore'));
  console.log('Chave de assinatura instalada');
}
