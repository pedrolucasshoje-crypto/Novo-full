# Multiverse Packs 1.0

Jogo de coleção com pacotinhos, missões, eventos e arena 2D. Sem dinheiro real. Personagens originais.

## Rodar no PC
    python -m http.server 8000
Abra http://localhost:8000 (ou use a extensão Live Server do VS Code).

## Gerar o APK
Envie o arquivo multiverse-packs-fase1-apk.zip (com esse mesmo nome) para o repositório no GitHub.
A aba Actions compila e entrega o APK em Artifacts. A chave em assinatura/ é de TESTE (mantenha o
repositório privado); para publicar na Play Store é preciso criar uma chave própria e secreta.

## Onde mudar cada coisa
| Quero mudar | Arquivo |
|---|---|
| Moedas iniciais, login, XP | src/config.js |
| Chances e valor de repetidas | src/data/rarities.js |
| Personagens, skins, poderes | src/data/characters.js |
| Pacotes, preços, eventos | src/data/packs.js |
| Missões | src/data/missions.js |
| Inimigos e ondas | src/arena/enemies.js |
| Comportamento dos poderes | src/arena/abilities.js |
| Cores e aparência | styles/base.css |
| Salvamento (trocar por banco remoto) | src/storage/db.js |

## Arquitetura
ui (telas) -> systems (regras) -> storage (salvamento). data guarda os catálogos; arena é o jogo 2D.
