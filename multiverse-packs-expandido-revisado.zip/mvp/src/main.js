// Ponto de entrada: carrega o save e liga as telas
import { CONFIG } from './config.js';
import { estado, iniciarEstado, aoMudar, erroSave } from './systems/state.js';
import { atualizarPeriodos, pendentes } from './systems/missions.js';
import { iniciarRotas } from './core/router.js';
import { iniciarParticulas } from './ui/particles.js';
import { barra, avisar } from './ui/dom.js';
import { menu } from './ui/screens/menu.js';
import { pacotes } from './ui/screens/packs.js';
import { colecao } from './ui/screens/collection.js';
import { missoes } from './ui/screens/missions.js';
import { eventos } from './ui/screens/events.js';
import { perfil } from './ui/screens/profile.js';
import { arena } from './arena/screen.js';

let atual = 'menu';
function moldura() {
  const jogo = atual === 'arena' && document.querySelector('.arena');
  if (jogo) return;
  document.querySelector('#topo').innerHTML = `<a href="#perfil" class="pilula" style="text-decoration:none;color:inherit" aria-label="Perfil">👤</a>
    <div class="nivel">Nível ${estado.nivel}${barra(estado.xp, CONFIG.xpJogador(estado.nivel))}</div><span class="pilula">🪙 ${estado.moedas}</span>`;
  const n = pendentes();
  document.querySelector('#barra').innerHTML = [['menu','🏠','Início'],['pacotes','🎴','Pacotes'],['colecao','📚','Coleção'],['arena','⚔️','Arena'],['missoes','🎯','Missões'],['eventos','🎉','Eventos']]
    .map(([r, i, t]) => `<a href="#${r}" class="${r === atual ? 'ativo' : ''}"><b>${i}</b>${t}${r === 'missoes' && n ? '<span class="ponto"></span>' : ''}</a>`).join('');
}
await iniciarEstado();
atualizarPeriodos();
aoMudar(moldura);
iniciarRotas({ menu, pacotes, colecao, arena, missoes, eventos, perfil }, (nome) => { atual = nome; moldura(); });
iniciarParticulas();
if (erroSave) avisar('Não consegui ler o salvamento: o progresso desta sessão não será gravado.');
