// filtro = quais variantes podem sair | bonus multiplica o peso das raridades a partir de "raro"
const universo = (u) => (v) => v.universo === u;
export const PACOTES = [
  { id: 'doomsday', nome: 'Doomsday', icone: '☄️', cor: '#ef4444', preco: 150, bonus: 1, filtro: universo('apocalipse') },
  { id: 'dc', nome: 'DC Universe', icone: '🦇', cor: '#2563eb', preco: 180, bonus: 1, filtro: universo('aurora') },
  { id: 'dragonball', nome: 'Dragon Ball', icone: '🐉', cor: '#f97316', preco: 180, bonus: 1, filtro: universo('astral') },
  { id: 'marvel', nome: 'Marvel', icone: '🕷️', cor: '#dc2626', preco: 180, bonus: 1, filtro: universo('vigilantes') },
  { id: 'herois', nome: 'Heróis', icone: '🛡️', cor: '#38bdf8', preco: 220, bonus: 1.3, filtro: (v) => v.lado === 'heroi' },
  { id: 'viloes', nome: 'Vilões', icone: '😈', cor: '#a855f7', preco: 220, bonus: 1.3, filtro: (v) => v.lado === 'vilao' },
  { id: 'multiverso', nome: 'Multiverso', icone: '🌌', cor: '#6ee7ff', preco: 400, bonus: 2.5, filtro: () => true },
];

// Eventos: um por semana, em rodízio
export const EVENTOS = [
  { id: 'eclipse', nome: 'Eclipse Sombrio', icone: '🌑', cor: '#8b5cf6', texto: 'Skins Sombrias em destaque.', filtro: (v) => v.skin === 'sombra' },
  { id: 'luzes', nome: 'Festival Neon', icone: '🎆', cor: '#22d3ee', texto: 'Só skins Neon no pacote.', filtro: (v) => v.skin === 'neon' },
  { id: 'cacada', nome: 'Caçada aos Vilões', icone: '🎯', cor: '#f43f5e', texto: 'Vilões com mais chance de raridade.', filtro: (v) => v.lado === 'vilao' },
];
export const PRECO_EVENTO = 500;
