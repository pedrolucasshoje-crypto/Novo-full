import { RARIDADES, ordemRaridade } from './rarities.js';

export const UNIVERSOS = {
  apocalipse: { nome: 'Doomsday', cor: '#ef4444' },
  aurora: { nome: 'DC', cor: '#3b82f6' },
  astral: { nome: 'Dragon Ball', cor: '#f97316' },
  vigilantes: { nome: 'Marvel', cor: '#e11d48' },
  anime: { nome: 'Anime', cor: '#9333ea' },
  games: { nome: 'Games', cor: '#16a34a' },
  cinema: { nome: 'Cinema & TV', cor: '#64748b' },
  pokemon: { nome: 'Pokémon', cor: '#f59e0b' },
};

// Habilidades usadas pelos personagens na arena.
export const HABILIDADES = {
  disparo: { nome: 'Rajada', icone: '✴️', tipo: 'projetil', custo: 20, recarga: 2.5 },
  leque: { nome: 'Leque de Tiros', icone: '🔱', tipo: 'leque', custo: 30, recarga: 4 },
  onda: { nome: 'Onda de Choque', icone: '💥', tipo: 'area', custo: 35, recarga: 6 },
  investida: { nome: 'Investida', icone: '⚡', tipo: 'investida', custo: 25, recarga: 4 },
  escudo: { nome: 'Escudo', icone: '🛡️', tipo: 'defesa', custo: 30, recarga: 9 },
  salto: { nome: 'Teletransporte', icone: '🌀', tipo: 'teletransporte', custo: 25, recarga: 5 },
  meteoro: { nome: 'Fúria Cósmica', icone: '☄️', tipo: 'especial', custo: 60, recarga: 14 },
  cura: { nome: 'Regeneração', icone: '💚', tipo: 'cura', custo: 45, recarga: 12 },
};

// [id, nome oficial, universo, raridade inicial, lado, emoji, habilidades, descrição]
// O catálogo contém apenas personagens oficiais; as skins são geradas abaixo para todos.
const LISTA = [
  // Doomsday / DC
  ['doomsday', 'Doomsday', 'apocalipse', 'mitico', 'vilao', '☄️', ['investida', 'onda'], 'O destruidor de mundos.'],
  ['darkseid', 'Darkseid', 'apocalipse', 'celestial', 'vilao', '🪨', ['meteoro', 'onda'], 'Senhor de Apokolips.'],

  // DC
  ['superman', 'Superman', 'aurora', 'lendario', 'heroi', '🦸', ['disparo', 'investida'], 'O Homem de Aço.'],
  ['batman', 'Batman', 'aurora', 'epico', 'heroi', '🦇', ['salto', 'escudo'], 'O Cavaleiro das Trevas.'],
  ['wonder-woman', 'Wonder Woman', 'aurora', 'lendario', 'heroi', '⚔️', ['investida', 'escudo'], 'A guerreira amazona.'],
  ['flash', 'Flash', 'aurora', 'epico', 'heroi', '⚡', ['investida', 'salto'], 'O velocista escarlate.'],
  ['green-lantern', 'Green Lantern', 'aurora', 'raro', 'heroi', '💚', ['escudo', 'disparo'], 'Portador do anel.'],
  ['aquaman', 'Aquaman', 'aurora', 'raro', 'heroi', '🌊', ['onda', 'investida'], 'Rei dos mares.'],
  ['joker', 'Joker', 'aurora', 'epico', 'vilao', '🃏', ['leque', 'onda'], 'O palhaço do crime.'],
  ['harley', 'Harley Quinn', 'aurora', 'raro', 'vilao', '🃏', ['investida', 'leque'], 'Caos imprevisível.'],
  ['lex', 'Lex Luthor', 'aurora', 'raro', 'vilao', '🧠', ['disparo', 'escudo'], 'Gênio e rival do Superman.'],

  // Dragon Ball
  ['goku', 'Goku', 'astral', 'lendario', 'heroi', '🐉', ['disparo', 'investida'], 'Saiyajin defensor da Terra.'],
  ['vegeta', 'Vegeta', 'astral', 'lendario', 'heroi', '👑', ['leque', 'investida'], 'Príncipe dos Saiyajins.'],
  ['gohan', 'Gohan', 'astral', 'epico', 'heroi', '📚', ['disparo', 'onda'], 'Filho de Goku.'],
  ['piccolo', 'Piccolo', 'astral', 'raro', 'heroi', '🟢', ['disparo', 'escudo'], 'Guerreiro namekuseijin.'],
  ['broly', 'Broly', 'astral', 'mitico', 'heroi', '💥', ['investida', 'onda'], 'Saiyajin de enorme poder.'],
  ['frieza', 'Frieza', 'astral', 'lendario', 'vilao', '👾', ['leque', 'meteoro'], 'Tirano galáctico.'],
  ['cell', 'Cell', 'astral', 'epico', 'vilao', '🧬', ['onda', 'cura'], 'Bioandroide.'],
  ['majin-buu', 'Majin Buu', 'astral', 'epico', 'vilao', '🍬', ['cura', 'onda'], 'Criatura mágica.'],
  ['beerus', 'Beerus', 'astral', 'mitico', 'vilao', '🐈', ['meteoro', 'salto'], 'Deus da destruição.'],
  ['whis', 'Whis', 'astral', 'celestial', 'heroi', '🌀', ['salto', 'escudo'], 'Anjo e mentor.'],
  ['trunks', 'Trunks', 'astral', 'raro', 'heroi', '🗡️', ['investida', 'disparo'], 'Guerreiro do futuro.'],
  ['gogeta', 'Gogeta', 'astral', 'mitico', 'heroi', '✨', ['meteoro', 'investida'], 'Fusão de Goku e Vegeta.'],
  ['vegito', 'Vegito', 'astral', 'mitico', 'heroi', '✨', ['meteoro', 'leque'], 'Fusão pela Potara.'],

  // Expansão Multiverso: anime, games, cinema, séries e outros universos
  ['naruto', 'Naruto Uzumaki', 'anime', 'lendario', 'heroi', '🍥', ['investida', 'disparo'], 'Ninja da Vila da Folha.'],
  ['sasuke', 'Sasuke Uchiha', 'anime', 'lendario', 'heroi', '⚡', ['salto', 'disparo'], 'Uchiha em busca de poder.'],
  ['sakura', 'Sakura Haruno', 'anime', 'raro', 'heroi', '🌸', ['cura', 'investida'], 'Ninja médica.'],
  ['kakashi', 'Kakashi Hatake', 'anime', 'epico', 'heroi', '🥷', ['salto', 'disparo'], 'O ninja copiador.'],
  ['luffy', 'Monkey D. Luffy', 'anime', 'lendario', 'heroi', '🏴‍☠️', ['investida', 'onda'], 'Capitão dos Piratas do Chapéu de Palha.'],
  ['zoro', 'Roronoa Zoro', 'anime', 'epico', 'heroi', '⚔️', ['investida', 'leque'], 'Espadachim dos Chapéus de Palha.'],
  ['sanji', 'Sanji', 'anime', 'epico', 'heroi', '🔥', ['investida', 'leque'], 'Cozinheiro e combatente.'],
  ['ichigo', 'Ichigo Kurosaki', 'anime', 'lendario', 'heroi', '🗡️', ['investida', 'meteoro'], 'Shinigami substituto.'],
  ['rukia', 'Rukia Kuchiki', 'anime', 'epico', 'heroi', '❄️', ['disparo', 'onda'], 'Shinigami da Soul Society.'],
  ['gojo', 'Satoru Gojo', 'anime', 'mitico', 'heroi', '🔵', ['escudo', 'meteoro'], 'Feiticeiro de Jujutsu.'],
  ['sukuna', 'Ryomen Sukuna', 'anime', 'mitico', 'vilao', '👹', ['onda', 'meteoro'], 'Rei das Maldições.'],
  ['tanjiro', 'Tanjiro Kamado', 'anime', 'epico', 'heroi', '🌊', ['investida', 'disparo'], 'Caçador de demônios.'],
  ['nezuko', 'Nezuko Kamado', 'anime', 'raro', 'heroi', '🎋', ['cura', 'investida'], 'Demon Slayer.'],
  ['eren', 'Eren Yeager', 'anime', 'lendario', 'heroi', '🧱', ['onda', 'investida'], 'Protagonista de Attack on Titan.'],
  ['mikasa', 'Mikasa Ackerman', 'anime', 'epico', 'heroi', '🧣', ['investida', 'salto'], 'Soldado de elite.'],
  ['killua', 'Killua Zoldyck', 'anime', 'epico', 'heroi', '⚡', ['salto', 'investida'], 'Hunter com habilidades elétricas.'],
  ['gon', 'Gon Freecss', 'anime', 'raro', 'heroi', '🎣', ['investida', 'onda'], 'Jovem Hunter.'],
  ['denji', 'Denji', 'anime', 'epico', 'heroi', '🪚', ['investida', 'cura'], 'Chainsaw Man.'],
  ['makima', 'Makima', 'anime', 'mitico', 'vilao', '👁️', ['escudo', 'meteoro'], 'Figura enigmática.'],
  ['saitama', 'Saitama', 'anime', 'mitico', 'heroi', '👊', ['investida', 'meteoro'], 'Herói de One Punch Man.'],
  ['jotaro', 'Jotaro Kujo', 'anime', 'epico', 'heroi', '⭐', ['investida', 'escudo'], 'Usuário de Stand.'],
  ['akira', 'Akira', 'cinema', 'epico', 'heroi', '🏍️', ['investida', 'onda'], 'Personagem de Akira.'],
  ['optimus-prime', 'Optimus Prime', 'cinema', 'lendario', 'heroi', '🚛', ['escudo', 'investida'], 'Líder dos Autobots.'],
  ['bumblebee', 'Bumblebee', 'cinema', 'epico', 'heroi', '🐝', ['investida', 'salto'], 'Autobot ágil.'],
  ['darth-vader', 'Darth Vader', 'cinema', 'mitico', 'vilao', '🌌', ['onda', 'meteoro'], 'Lorde Sith.'],
  ['luke-skywalker', 'Luke Skywalker', 'cinema', 'lendario', 'heroi', '✨', ['disparo', 'escudo'], 'Jedi.'],
  ['harry-potter', 'Harry Potter', 'cinema', 'lendario', 'heroi', '🪄', ['disparo', 'escudo'], 'Bruxo de Hogwarts.'],
  ['hermione', 'Hermione Granger', 'cinema', 'epico', 'heroi', '📚', ['disparo', 'escudo'], 'Bruxa talentosa.'],
  ['michael-myers', 'Michael Myers', 'cinema', 'mitico', 'vilao', '🎃', ['investida', 'cura'], 'Figura de Halloween.'],
  ['rick-grimes', 'Rick Grimes', 'cinema', 'raro', 'heroi', '🧟', ['disparo', 'escudo'], 'Sobrevivente de The Walking Dead.'],
  ['omni-man', 'Omni-Man', 'cinema', 'mitico', 'vilao', '🦸', ['investida', 'meteoro'], 'Viltrumita de Invincible.'],
  ['invincible', 'Mark Grayson', 'cinema', 'lendario', 'heroi', '💥', ['investida', 'onda'], 'Invincible.'],
  ['sonic', 'Sonic', 'games', 'lendario', 'heroi', '💨', ['investida', 'salto'], 'O ouriço veloz.'],
  ['shadow', 'Shadow', 'games', 'epico', 'heroi', '🖤', ['salto', 'meteoro'], 'O ouriço rival.'],
  ['kratos', 'Kratos', 'games', 'mitico', 'heroi', '🪓', ['investida', 'onda'], 'Guerreiro de God of War.'],
  ['master-chief', 'Master Chief', 'games', 'lendario', 'heroi', '🟢', ['escudo', 'disparo'], 'Soldado Spartan.'],
  ['minecraft-steve', 'Steve', 'games', 'raro', 'heroi', '⛏️', ['escudo', 'investida'], 'Construtor de Minecraft.'],
  ['link', 'Link', 'games', 'lendario', 'heroi', '🗡️', ['disparo', 'escudo'], 'Herói de Hyrule.'],
  ['zelda', 'Zelda', 'games', 'lendario', 'heroi', '👑', ['disparo', 'cura'], 'Princesa de Hyrule.'],
  ['scorpion', 'Scorpion', 'games', 'epico', 'heroi', '🔥', ['investida', 'disparo'], 'Combatente de Mortal Kombat.'],
  ['sub-zero', 'Sub-Zero', 'games', 'epico', 'heroi', '❄️', ['disparo', 'escudo'], 'Mestre do gelo.'],
  ['ryu', 'Ryu', 'games', 'raro', 'heroi', '🥋', ['onda', 'investida'], 'Lutador de Street Fighter.'],
  ['ben-tennyson', 'Ben Tennyson', 'games', 'lendario', 'heroi', '⌚', ['salto', 'meteoro'], 'Herói do Omnitrix.'],
  ['leon-kennedy', 'Leon Kennedy', 'games', 'epico', 'heroi', '🧟', ['disparo', 'escudo'], 'Agente de Resident Evil.'],
  ['pikachu', 'Pikachu', 'pokemon', 'epico', 'heroi', '⚡', ['disparo', 'onda'], 'Pokémon elétrico.'],
  ['charizard', 'Charizard', 'pokemon', 'lendario', 'heroi', '🔥', ['disparo', 'meteoro'], 'Pokémon flamejante.'],
  ['mewtwo', 'Mewtwo', 'pokemon', 'mitico', 'heroi', '🧬', ['salto', 'meteoro'], 'Pokémon psíquico.'],
  ['gengar', 'Gengar', 'pokemon', 'epico', 'vilao', '👻', ['salto', 'onda'], 'Pokémon fantasma.'],

  // Marvel
  ['iron-man', 'Iron Man', 'vigilantes', 'epico', 'heroi', '🤖', ['disparo', 'escudo'], 'Armadura tecnológica.'],
  ['spider-man', 'Spider-Man', 'vigilantes', 'epico', 'heroi', '🕷️', ['salto', 'investida'], 'Herói com sentido aranha.'],
  ['thor', 'Thor', 'vigilantes', 'lendario', 'heroi', '🔨', ['onda', 'investida'], 'Deus do trovão.'],
  ['hulk', 'Hulk', 'vigilantes', 'epico', 'heroi', '💚', ['investida', 'onda'], 'Força extraordinária.'],
  ['captain-america', 'Captain America', 'vigilantes', 'raro', 'heroi', '🛡️', ['escudo', 'investida'], 'Herói com escudo.'],
  ['thanos', 'Thanos', 'vigilantes', 'mitico', 'vilao', '💠', ['meteoro', 'onda'], 'Titã poderoso.'],
  ['loki', 'Loki', 'vigilantes', 'epico', 'vilao', '🐍', ['salto', 'leque'], 'Mestre da ilusão.'],
  ['doctor-strange', 'Doctor Strange', 'vigilantes', 'lendario', 'heroi', '🔮', ['salto', 'onda'], 'Mestre das artes místicas.'],
  ['wolverine', 'Wolverine', 'vigilantes', 'epico', 'heroi', '🐺', ['investida', 'cura'], 'Mutante com fator de cura.'],
  ['deadpool', 'Deadpool', 'vigilantes', 'raro', 'heroi', '🟥', ['investida', 'cura'], 'Mercenário irreverente.'],
  ['venom', 'Venom', 'vigilantes', 'lendario', 'vilao', '🕸️', ['onda', 'cura'], 'Simbionte.'],
  ['scarlet-witch', 'Scarlet Witch', 'vigilantes', 'mitico', 'heroi', '🔴', ['onda', 'meteoro'], 'Poderes místicos.'],
];

// As três skins são mantidas para cada personagem, com IDs próprios.
export const SKINS = [
  { id: 'base', nome: 'Original', bonus: 0 },
  { id: 'neon', nome: 'Neon', bonus: 1 },
  { id: 'sombra', nome: 'Sombria', bonus: 2 },
];

export const PERSONAGENS = LISTA.map(([id, nome, universo, raridade, lado, emoji, habilidades, descricao]) =>
  ({ id, nome, universo, raridade, lado, emoji, habilidades, descricao }));

export const VARIANTES = PERSONAGENS.flatMap((p) => SKINS.map((s) => {
  const r = RARIDADES[Math.min(ordemRaridade(p.raridade) + s.bonus, RARIDADES.length - 1)];
  return {
    ...p,
    id: `${p.id}:${s.id}`,
    personagem: p.id,
    skin: s.id,
    skinNome: s.nome,
    raridade: r.id,
    stats: {
      vida: Math.round(100 * r.poder),
      ataque: Math.round(14 * r.poder),
      velocidade: Math.round(190 + 25 * (r.poder - 1)),
    },
  };
}));

const MAPA = new Map(VARIANTES.map((v) => [v.id, v]));
export const variante = (id) => MAPA.get(id);
