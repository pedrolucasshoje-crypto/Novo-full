// peso = chance relativa no pacote | duplicado = moedas ao converter | poder = multiplicador de atributos
export const RARIDADES = [
  { id: 'comum',    nome: 'Comum',    cor: '#9aa4b8', peso: 48,  duplicado: 10,  poder: 1.00 },
  { id: 'incomum',  nome: 'Incomum',  cor: '#4ade80', peso: 26,  duplicado: 20,  poder: 1.08 },
  { id: 'raro',     nome: 'Raro',     cor: '#38bdf8', peso: 14,  duplicado: 40,  poder: 1.17 },
  { id: 'epico',    nome: 'Épico',    cor: '#c084fc', peso: 7,   duplicado: 90,  poder: 1.28 },
  { id: 'lendario', nome: 'Lendário', cor: '#fbbf24', peso: 3.4, duplicado: 200, poder: 1.42 },
  { id: 'mitico',   nome: 'Mítico',   cor: '#fb7185', peso: 1.3, duplicado: 450, poder: 1.60 },
  { id: 'celestial',nome: 'Celestial',cor: '#e0f2fe', peso: 0.3, duplicado: 1000,poder: 1.85 },
];
export const raridade = (id) => RARIDADES.find((r) => r.id === id);
export const ordemRaridade = (id) => RARIDADES.findIndex((r) => r.id === id);
